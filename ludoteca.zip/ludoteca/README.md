# Ludoteca — gerenciador da coleção de jogos de tabuleiro

App em português para catalogar sua coleção e a dos amigos usando o **BoardGameGeek (BGG)** como fonte: busca de jogos, expansões, importação por fotos com revisão, proprietários com cores, localização e empréstimos, filtros combináveis, exportação e backup.

Funciona de dois jeitos, com o mesmo código:
- **App Android (APK)** — tudo roda no celular: banco no aparelho, BGG e reconhecimento de fotos chamados direto pelo app, sem servidor.
- **Versão para computador** — servidor local acessado pelo navegador.

O app já vem com a **coleção das fotos** (79 itens): seus jogos (incluindo o Azul Mini), os do **Arthur Bunte** (azul-marinho) e os do **André Salim** (verde). Eles entram só com o nome; depois de colocar o token do BGG, toque em **“Vincular ao BGG”** na biblioteca para buscar os dados de todos de uma vez, com revisão antes de salvar.

## App Android

### Gerar o APK (sem instalar nada no computador) — GitHub Actions
1. Crie um repositório (pode ser privado) em github.com e envie esta pasta para ele.
2. Na aba **Actions**, a execução “APK Android” roda sozinha a cada envio (ou clique em *Run workflow*).
3. Quando terminar (~5–8 min), abra a execução e baixe **ludoteca-apk** em *Artifacts*. Dentro do zip está o `app-debug.apk`.
4. Mande o APK para o celular, abra e permita “instalar apps de fontes desconhecidas”.

### Ou com o Android Studio
```bash
npm install
npm run android:sync      # monta o app e copia para o projeto android/
npx cap open android      # abre no Android Studio → Run ▶ ou Build › Build APK(s)
```
(ou `npm run android:apk` com o Android SDK instalado; o APK sai em `android/app/build/outputs/apk/debug/`).

### Primeiro uso no celular
1. **Configurações › BoardGameGeek**: cole o token do BGG (como obter: ver “Ativando o BGG”). Fica guardado só no aparelho.
2. **Biblioteca › Vincular ao BGG**: o app procura cada jogo no BGG (o BGG limita a velocidade, leva alguns minutos para ~80 jogos). Confira as sugestões, toque em *Confirmar* (ou “Confirmar N de alta confiança”) e em **Vincular**. Proprietário, local e notas são mantidos; dados oficiais, capas e expansões chegam do BGG.
3. **Botão +** (canto inferior direito): adicionar novos jogos, buscando no BGG ou cadastrando à mão.
4. **Importar**: *Tirar foto* ou *Escolher da galeria*. Sem chave, a leitura é feita por OCR no próprio celular (offline); com uma chave da API da Anthropic em Configurações, o Claude reconhece estantes e lombadas muito melhor.
5. **Backup**: Configurações › *Backup JSON* abre o menu de compartilhar (Drive, e-mail, WhatsApp). Os dados ficam no aparelho; o backup automático do Android também inclui o app.

Detalhes técnicos do app: Capacitor 8; SQLite em WebAssembly (sql.js) gravado na pasta privada do app; requisições pela camada nativa (sem CORS); OCR com tesseract.js e dados de idioma embutidos (por isso o APK tem ~35 MB).

### Identificação das fotos (para conferir)
Itens que não deu para ler nas fotos ficaram de fora (algumas caixas pequenas, EXIT, expansões de Scythe e de 7 Wonders Duel), assim como a expansão de Catan do André, conforme pedido. As expansões de Wingspan foram identificadas pela cor das caixas (Oceania e European). Para mudar a lista inicial, edite `src/server/services/seed.ts`; ou simplesmente edite/adicione no app.

## Versão para computador

### Como executar

Requisitos: **Node.js 20.11 ou mais novo** (testado com Node 22) e npm.

```bash
cd ludoteca
npm install
cp .env.example .env      # depois edite o .env (veja abaixo)
npm start                 # compila a interface e inicia o servidor
```

Abra **http://127.0.0.1:5174**. Para parar, `Ctrl+C`. Os dados ficam em `data/ludoteca.db` e continuam lá ao reiniciar.

Desenvolvimento com recarga automática: `npm run dev` (interface em http://localhost:5173, API em 5174).

Para acessar pelo celular na mesma rede, use `HOST=0.0.0.0` no `.env` e abra `http://IP-do-computador:5174`. A aplicação não tem login: só exponha na rede de casa.

## Configuração (`.env`)

| Variável | Para quê | Obrigatória? |
|---|---|---|
| `BGG_API_TOKEN` | Token da XML API do BGG | Para buscar/atualizar dados do BGG |
| `BGG_MIN_INTERVAL_MS` | Intervalo mínimo entre requisições ao BGG (padrão 2500) | Não |
| `BGG_CACHE_TTL_HOURS` | Validade do cache local de respostas (padrão 168 h) | Não |
| `DOWNLOAD_IMAGES` | Guarda as capas em `data/images` para funcionar com o BGG fora do ar (padrão 1) | Não |
| `VISION_PROVIDER` | `auto`, `anthropic`, `ocr` ou `none` | Não |
| `ANTHROPIC_API_KEY` | Reconhecimento de fotos com Claude (pago, muito mais preciso) | Não |
| `VISION_MODEL` | Modelo do Claude para as fotos (padrão `claude-sonnet-5-5`) | Não |
| `PORT`, `HOST`, `DATA_DIR` | Servidor e pasta de dados | Não |
| `SEED_COLLECTION` | `0` para não cadastrar a coleção das fotos no primeiro uso | Não |

As chaves ficam só no servidor; nunca são enviadas ao navegador.

### Ativando o BGG (necessário para os dados automáticos)

Desde 2025 o BGG exige que cada aplicação seja registrada e envie um token (`Authorization: Bearer`) em toda chamada da XML API2. Sem token o BGG responde 401.

1. Entre na sua conta do BGG e acesse **https://boardgamegeek.com/applications**.
2. Registre uma aplicação de uso **não comercial** (gratuita). A aprovação pode levar alguns dias.
3. Depois de aprovada, gere um token na aba *Tokens* e coloque no `.env`: `BGG_API_TOKEN=...`
4. Reinicie a aplicação. Em **Configurações** aparece “Token configurado”.

Enquanto o token não chega, tudo funciona com cadastro manual; depois use **“Vincular ao BGG”** na ficha do jogo para puxar os dados oficiais.

## Como usar

- **Adicionar jogo**: botão no topo → *Buscar no BGG* (inglês ou português; títulos alternativos são encontrados) ou *Cadastro manual*. Escolha status, proprietário e onde está.
- **Ficha do jogo**: clique no card. Abas: visão geral, jogadores e tempo (votação da comunidade e estimativas), etiquetas e mecânicas, propriedade e local (empréstimos com histórico), expansões, fontes dos dados.
- **Proprietários**: menu *Proprietários* → nome e cor. A cor pinta o nome dos jogos na biblioteca; o nome do proprietário também aparece no card (não depende só da cor). Jogos fora de casa mostram um aviso como “Com Fulano — não está comigo”.
- **Filtros** (barra lateral, todos combináveis): número de jogadores em três modos distintos — **Suporta** (faixa oficial), **Recomendado** (comunidade) e **Melhor com** (as 2 mais votadas) —, duração, peso, coleção, proprietário, localização, etiquetas (clique = incluir, de novo = excluir), expansões e favoritos. A pesquisa textual cobre nome, nome em português, designer, editora, mecânica, categoria, etiqueta e nome das expansões. Atalhos prontos: *Leves para ensinar*, *Pesados e estratégicos*, *Menos de 1 hora*, *Cooperativos*, *Emprestados*, *Fora de casa*.
- **Expansões**: na aba *Expansões* do jogo-base aparecem todas as expansões listadas no BGG, começando como **“Não verificado”** (nunca se presume posse). *Buscar dados* traz imagem, ano, peso etc. em lotes. Marque cada uma como Possuo / Não possuo / Quero comprar; cada expansão tem proprietário e local próprios (abra-a para editar). O resumo “Possuo X de Y” conta só expansões verificadas — promos, expansões de fãs e jogos independentes ficam fora da conta e são mostrados à parte.

### Importar por fotos

1. Menu **Importar fotos** → arraste ou escolha as fotos (até 30 por vez).
2. Defina os padrões da importação (status, proprietário, onde estão) e clique em **Analisar**.
3. Na **revisão**, cada caixa detectada mostra miniatura da foto com a marcação, recorte, título lido, correspondências do BGG com miniatura, grau de confiança e avisos (duplicata, edições parecidas, expansão × jogo-base, jogo independente listado como expansão).
4. Para cada item: **Confirmar**, escolher outra correspondência, editar o título e **Buscar de novo**, ou **Ignorar**. Faltou algum? Digite o nome em “Faltou algum jogo nesta foto?”.
5. **Adicionar N à coleção**. Só então os jogos são gravados, com os dados completos do BGG. Jogos já cadastrados não são duplicados; uma expansão que estava “Não verificado” passa a “Possuo”.

Reconhecimento disponível:
- **Sem chave**: OCR local (Tesseract, inglês + português, roda offline). Lê bem títulos grandes de capas; lombadas finas e fotos de estante inteira costumam falhar. Por isso tudo passa pela revisão.
- **Com `ANTHROPIC_API_KEY`**: o Claude identifica várias caixas por foto (títulos parciais, lombadas, edições em português, expansões) e devolve a posição de cada caixa para o recorte. Serviço pago por uso; as fotos só saem do seu computador nesse modo.

## Backup e restauração

- **Pela interface** (Configurações): *Backup JSON*, *Planilha CSV* e *Cópia do banco (SQLite)*. Para restaurar, *Restaurar backup JSON* — mescla com a coleção e ignora o que já existe (mesmo ID do BGG, ou mesmo nome e ano).
- **Pela linha de comando**:
  ```bash
  npm run backup                    # cria data/backups/ludoteca-<data>.db e .json
  npm run backup -- /pasta/externa  # em outra pasta
  npm run restore -- data/backups/ludoteca-<data>.db   # com a aplicação parada
  ```
  O `restore` guarda o banco anterior como `ludoteca.db.antes-da-restauracao-<data>`.
- Copiar a pasta `data/` inteira (com a aplicação parada) também é um backup completo, incluindo capas e fotos importadas.

Os backups não dependem do BGG: contêm todos os dados, inclusive os que vieram de lá.

## De onde vêm os dados (e o que não é inventado)

Tudo é obtido pela **XML API2 oficial** (`/xmlapi2/thing?stats=1&versions=1` e `/xmlapi2/search`), no servidor, com fila de uma requisição por vez, intervalo mínimo, repetição com espera em 202/429/5xx, lotes de até 20 IDs e cache local. Não há scraping de páginas nem tentativa de contornar proteções do site. Se o BGG estiver fora do ar, a coleção continua funcionando e as últimas respostas do cache são usadas.

Cada campo guarda **fonte, data e status** (aba *Fontes dos dados*): `BGG` (oficial), `calculado`, `inferido`, `manual` ou `não disponível`.

- **Jogadores oficiais**: `minplayers`/`maxplayers`.
- **Melhor com (comunidade)**: a enquete *User Suggested Number of Players* da própria API — é a mesma votação exibida em *Community › Best* na página do jogo. As duas melhores quantidades são as com mais votos **Best** (empate: Best + Recommended); contagens “N+” (acima do máximo) são ignoradas. **Recomendado** segue a regra do BGG: Best + Recommended > Not Recommended. Os votos ficam salvos e a ficha mostra a tabela completa, o resumo do próprio BGG e o link para conferência. Sem votos → “Não verificado”.
- **Tempo**: mínimo, máximo e “playing time” oficiais. O BGG **não publica tempo por jogador**; a aplicação não extrapola. Você pode informar uma estimativa (sessão típica com N jogadores + minutos por jogador extra); a tabela de 2–6 jogadores marca esses valores como “estimativa sua”.
- **Peso**: média de votos (escala 1–5) com o número de votos. Os rótulos (Muito leve…Muito pesado) são da aplicação e configuráveis.
- **Nome em português**: o BGG lista nomes alternativos sem indicar o idioma, então o nome em português **não é preenchido automaticamente**. A ficha mostra as edições em português registradas no BGG (editora/ano) e sugere os nomes alternativos para você confirmar.
- **Etiquetas**: três origens visíveis — *derivadas* de mecânicas/categorias oficiais ou da classificação do BGG (ex.: mecânica “Cooperative Game” → Cooperativo; “Strategy Game Rank” → Estratégico), *inferidas* (ex.: Competitivo quando não há a mecânica cooperativa; faixa de duração) e *manuais*. Etiquetas subjetivas (interação, sorte, Eurogame…) ficam para você aplicar. Uma etiqueta automática removida por você fica “rejeitada” e não volta nas atualizações.
- **Expansões**: links `boardgameexpansion` do jogo-base. Acessórios e reimplementações vêm em outros tipos de link e não entram; jogos independentes que o BGG também lista como expansão são sinalizados; promos e feitas por fãs são identificadas pelo nome/categoria (marcadas como inferidas).

**Atualizar do BGG nunca apaga** proprietário, localização, empréstimos, status, favoritos, notas, preço, nome em português, estimativas de tempo, etiquetas manuais/rejeitadas nem campos que você editou à mão (estes ficam marcados como “manual”; dá para voltar ao valor do BGG na aba *Fontes*).

## Arquitetura

- **Servidor**: Node + Express 5 + TypeScript (executado com `tsx`), SQLite via `better-sqlite3`, validação com `zod`, XML com `fast-xml-parser`, imagens com `sharp`, OCR com `tesseract.js` (dados de idioma incluídos via npm, sem download em tempo de execução).
- **Interface**: React + Vite + TypeScript, componentes próprios com um único sistema de estilos (sem dependência de biblioteca de UI externa). Toda a coleção é carregada uma vez e filtrada no navegador, então os filtros respondem na hora.
- **Por que não Next.js/Prisma**: é uma aplicação local de um usuário, sem renderização no servidor; um servidor Express único que também serve a interface é mais simples de instalar e manter, e SQL direto com migrações versionadas evita os binários do Prisma.

```
src/server/   routes.ts (rotas comuns), app.ts (Express), db.ts + migrations/, bgg/ (cliente, parser, regras),
              services/ (jogos, BGG, importação, backup, imagens), vision/ (Claude e OCR)
src/shared/   tipos, regras de domínio e filtros (usados pelo servidor, interface e testes)
src/client/   interface React
src/mobile/   “servidor” embutido do app: sql.js, armazenamento no aparelho, imagens com canvas, OCR
android/      projeto Android (Capacitor)
tests/        unit/ (parser, Best With, etiquetas, filtros, visão), api/ (fluxos pela API),
              e2e/ (jornadas no navegador com Playwright), fixtures/ (XML no formato do BGG)
scripts/      backup, restore e fake-bgg (BGG simulado para desenvolvimento)
```

Entidades no banco: `games` (jogos-base e expansões), `owners`, `loans` (histórico de empréstimos), `tags` + `game_tags` (com origem e rejeição), `bgg_terms` + `game_bgg_terms` (mecânicas, categorias, famílias, designers, editoras), `player_poll`, `game_relations` (expansões, reimplementações, integrações), `field_sources`, `import_batches` / `import_photos` / `import_candidates`, `bgg_cache`, `settings`. Migrações em `src/server/migrations/` são aplicadas automaticamente ao iniciar.

## Testes

```bash
npm test             # unitários + API (Vitest)
npm run test:e2e     # jornadas da versão de computador (Playwright; `npx playwright install chromium` na 1ª vez)
npm run test:mobile  # app de celular rodando num navegador com tela de celular
npm run typecheck
```

Os testes usam um **BGG simulado** com XML no formato da API real e números ilustrativos (não são dados reais do BGG) e um banco temporário — nunca tocam na sua coleção. Para experimentar a interface sem token: `npm run fake-bgg` em um terminal e, em outro, `BGG_BASE_URL=http://127.0.0.1:5999 BGG_API_TOKEN=dev-token DATA_DIR=data-teste npm start`.

## Limitações conhecidas

- **O APK não pôde ser compilado no ambiente onde o app foi construído** (sem acesso ao SDK do Android); o projeto Android e o workflow do GitHub estão prontos, e o app de celular foi testado rodando num navegador com tela de celular.
- **Integração com o BGG real não pôde ser exercitada no ambiente onde a aplicação foi construída** (o acesso ao boardgamegeek.com estava bloqueado lá). O cliente segue a documentação e o formato da XML API2 e foi testado contra respostas simuladas; na primeira execução com o seu token, confira um jogo conhecido. Se algo vier diferente, a mensagem de erro aparece na ficha (aba *Fontes*).
- A aprovação do token do BGG é manual e pode demorar.
- OCR local é limitado (veja acima); o reconhecimento com Claude depende de chave paga.
- Não há sincronização entre aparelhos: cada celular tem seu próprio banco (use backup JSON para passar de um para outro).
- Não há sincronização com a coleção do seu usuário no BGG nem login multiusuário.
- Tempo por jogador só existe quando você informa uma estimativa.
