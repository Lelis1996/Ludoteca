import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

// `vite build` → versão web (servida pelo servidor no computador)
// `vite build --mode mobile` → app de celular (tudo embutido, sem servidor)
export default defineConfig(({ mode }) => {
  const mobile = mode === 'mobile';
  return {
    root: 'src/client',
    base: mobile ? './' : '/',
    envDir: path.resolve(import.meta.dirname),
    plugins: [react()],
    publicDir: mobile ? path.resolve(import.meta.dirname, 'build/mobile-public') : false,
    define: mobile ? { 'import.meta.env.VITE_EMBEDDED': JSON.stringify('1') } : {},
    build: {
      outDir: mobile ? '../../dist/mobile' : '../../dist/client',
      emptyOutDir: true,
      chunkSizeWarningLimit: 2000,
    },
    server: {
      port: 5173,
      proxy: mobile ? undefined : {
        '/api': 'http://127.0.0.1:5174',
        '/images': 'http://127.0.0.1:5174',
        '/uploads': 'http://127.0.0.1:5174',
      },
    },
    preview: { port: 4173 },
  };
});
