/**
 * Prepara os arquivos estáticos do app de celular em build/mobile-public:
 * worker e núcleo do Tesseract (OCR offline) e dados de idioma (inglês e português).
 */
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { build } from 'esbuild';

const require = createRequire(import.meta.url);
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const out = path.join(root, 'build', 'mobile-public', 'tesseract');
fs.mkdirSync(out, { recursive: true });

await build({
  entryPoints: [path.join(root, 'node_modules/tesseract.js/src/worker-script/browser/index.js')],
  bundle: true, minify: true, format: 'iife', platform: 'browser', target: 'es2020',
  define: { global: 'self', 'process.env.NODE_ENV': '"production"' },
  outfile: path.join(out, 'worker.min.js'),
  logLevel: 'warning',
});

const core = path.dirname(require.resolve('tesseract.js-core/package.json'));
for (const f of fs.readdirSync(core)) if (/^tesseract-core.*lstm\.wasm\.js$/.test(f)) fs.copyFileSync(path.join(core, f), path.join(out, f));
for (const code of ['eng', 'por']) {
  const pkg = require(`@tesseract.js-data/${code}`);
  fs.copyFileSync(path.join(pkg.langPath, `${code}.traineddata.gz`), path.join(out, `${code}.traineddata.gz`));
}
const size = fs.readdirSync(out).reduce((n, f) => n + fs.statSync(path.join(out, f)).size, 0);
console.log(`Arquivos do OCR prontos em ${path.relative(root, out)} (${(size / 1e6).toFixed(1)} MB)`);
