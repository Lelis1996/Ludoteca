/**
 * Restaura o banco a partir de um arquivo .db gerado por `npm run backup` ou pela tela de Configurações.
 *   npm run restore -- caminho/do/backup.db
 * PARE a aplicação antes. O banco atual é guardado como ludoteca.db.antes-da-restauracao-<data>.
 * Para restaurar um backup .json, use Configurações › Restaurar backup JSON (mescla sem duplicar).
 */
import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { loadConfig } from '../src/server/config';

const src = process.argv[2];
if (!src || !fs.existsSync(src)) {
  console.error('Informe o arquivo .db do backup: npm run restore -- caminho/do/backup.db');
  process.exit(1);
}
const check = new Database(src, { readonly: true });
const ok = check.prepare(`SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'games'`).get();
const integrity = check.pragma('integrity_check', { simple: true });
check.close();
if (!ok || integrity !== 'ok') {
  console.error('O arquivo não parece um backup válido da Ludoteca.');
  process.exit(1);
}
const config = loadConfig();
fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });
if (fs.existsSync(config.dbPath)) {
  const keep = `${config.dbPath}.antes-da-restauracao-${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}`;
  fs.renameSync(config.dbPath, keep);
  for (const ext of ['-wal', '-shm']) if (fs.existsSync(config.dbPath + ext)) fs.rmSync(config.dbPath + ext);
  console.log(`Banco atual guardado em ${keep}`);
}
fs.copyFileSync(src, config.dbPath);
console.log(`Restaurado: ${config.dbPath}. Inicie a aplicação normalmente.`);
