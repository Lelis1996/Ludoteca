import type { GameSummary, Owner, Tag } from './types';
import { isWithMe, normalizeText, typicalTime } from './domain';

export type PlayersMode = 'supports' | 'recommended' | 'best';
export type CollectionScope = 'physical' | 'mine' | 'friends' | 'wishlist' | 'want_to_try' | 'reference' | 'all';
export type LocationScope = 'any' | 'with_me' | 'away' | 'loaned' | 'lent_out' | 'borrowed';
export type ExpansionScope = 'hide' | 'include' | 'only';
export type ExpansionFilter =
  | 'any' | 'missing' | 'complete' | 'wishlist' | 'exp_with_friends' | 'exp_with_me_base_away' | 'pending';
export type SortKey = 'name' | 'year' | 'weight' | 'time' | 'players' | 'best' | 'added';

export interface Filters {
  q: string;
  players: number | null;
  playersMode: PlayersMode;
  timeMin: number | null;
  timeMax: number | null;
  weightMin: number;
  weightMax: number;
  collection: CollectionScope;
  ownerIds: number[];
  location: LocationScope;
  tagInclude: number[];
  tagExclude: number[];
  favoritesOnly: boolean;
  expansions: ExpansionScope;
  expansionFilter: ExpansionFilter;
  sort: SortKey;
  sortDir: 'asc' | 'desc';
}

export const DEFAULT_FILTERS: Filters = {
  q: '',
  players: null,
  playersMode: 'supports',
  timeMin: null,
  timeMax: null,
  weightMin: 1,
  weightMax: 5,
  collection: 'physical',
  ownerIds: [],
  location: 'any',
  tagInclude: [],
  tagExclude: [],
  favoritesOnly: false,
  expansions: 'hide',
  expansionFilter: 'any',
  sort: 'name',
  sortDir: 'asc',
};

export function activeFilterCount(f: Filters): number {
  let n = 0;
  if (f.q.trim()) n++;
  if (f.players != null) n++;
  if (f.timeMin != null || f.timeMax != null) n++;
  if (f.weightMin > 1 || f.weightMax < 5) n++;
  if (f.collection !== DEFAULT_FILTERS.collection) n++;
  if (f.ownerIds.length) n++;
  if (f.location !== 'any') n++;
  n += f.tagInclude.length + f.tagExclude.length;
  if (f.favoritesOnly) n++;
  if (f.expansions !== 'hide') n++;
  if (f.expansionFilter !== 'any') n++;
  return n;
}

function parseCount(s: string | null): number | null {
  if (!s) return null;
  const n = parseInt(s, 10);
  return Number.isFinite(n) ? n : null;
}

export function supportsPlayers(g: GameSummary, n: number): boolean {
  if (g.minPlayers == null || g.maxPlayers == null) return false;
  return n >= g.minPlayers && n <= g.maxPlayers;
}

export function communityRecommends(g: GameSummary, n: number): boolean {
  return !!g.recommendedCounts && g.recommendedCounts.includes(n);
}

export function communityBest(g: GameSummary, n: number): boolean {
  return parseCount(g.bestCount1) === n || parseCount(g.bestCount2) === n;
}

function matchesCollection(g: GameSummary, scope: CollectionScope, me: Owner | undefined): boolean {
  switch (scope) {
    case 'all': return true;
    case 'physical': return g.ownershipStatus === 'owned';
    case 'mine': return g.ownershipStatus === 'owned' && !!me && g.ownerId === me.id;
    case 'friends': return g.ownershipStatus === 'owned' && g.ownerId != null && (!me || g.ownerId !== me.id);
    case 'wishlist': return g.ownershipStatus === 'wishlist';
    case 'want_to_try': return g.ownershipStatus === 'want_to_try';
    case 'reference': return g.ownershipStatus === 'reference' || g.ownershipStatus === 'not_owned' || g.ownershipStatus === 'unverified';
  }
}

function matchesLocation(g: GameSummary, scope: LocationScope): boolean {
  switch (scope) {
    case 'any': return true;
    case 'with_me': return isWithMe(g);
    case 'away': return !isWithMe(g);
    case 'loaned': return g.locationType === 'lent_out' || g.locationType === 'borrowed';
    case 'lent_out': return g.locationType === 'lent_out';
    case 'borrowed': return g.locationType === 'borrowed';
  }
}

export interface FilterContext {
  owners: Owner[];
  tags: Tag[];
}

function haystack(g: GameSummary, tagNames: Map<number, string>): string {
  return normalizeText([
    g.nameEn, g.namePt ?? '', ...g.designers, ...g.publishers, ...g.mechanics, ...g.categories,
    ...g.tags.map((t) => tagNames.get(t.id) ?? ''), ...g.baseNames,
  ].join(' | '));
}

export interface FilterResult {
  items: GameSummary[];
  /** jogos-base que entraram no resultado porque uma expansão deles casou com a pesquisa */
  matchedViaExpansion: Map<number, string[]>;
}

export function applyFilters(all: GameSummary[], f: Filters, ctx: FilterContext): FilterResult {
  const me = ctx.owners.find((o) => o.isMe);
  const tagNames = new Map(ctx.tags.map((t) => [t.id, t.name]));
  const q = normalizeText(f.q);
  const qTerms = q ? q.split(' ').filter(Boolean) : [];
  const textMatch = (g: GameSummary) => {
    if (!qTerms.length) return true;
    const h = haystack(g, tagNames);
    return qTerms.every((t) => h.includes(t));
  };

  // expansões por jogo-base, para busca por nome da expansão
  const expansionsByBase = new Map<number, GameSummary[]>();
  for (const g of all) {
    if (g.kind !== 'expansion') continue;
    for (const b of g.baseIds) {
      if (!expansionsByBase.has(b)) expansionsByBase.set(b, []);
      expansionsByBase.get(b)!.push(g);
    }
  }

  const matchedViaExpansion = new Map<number, string[]>();
  const items = all.filter((g) => {
    // tipo de item
    if (f.expansions === 'hide' && g.kind === 'expansion') {
      if (f.expansionFilter !== 'exp_with_friends') return false;
    }
    if (f.expansions === 'only' && g.kind !== 'expansion') return false;

    if (!matchesCollection(g, f.collection, me)) return false;
    if (f.ownerIds.length && (g.ownerId == null || !f.ownerIds.includes(g.ownerId))) return false;
    if (!matchesLocation(g, f.location)) return false;
    if (f.favoritesOnly && !g.favorite) return false;

    if (f.players != null) {
      const ok = f.playersMode === 'supports' ? supportsPlayers(g, f.players)
        : f.playersMode === 'recommended' ? communityRecommends(g, f.players)
        : communityBest(g, f.players);
      if (!ok) return false;
    }

    if (f.timeMin != null || f.timeMax != null) {
      const t = typicalTime(g);
      if (t == null) return false;
      if (f.timeMin != null && t < f.timeMin) return false;
      if (f.timeMax != null && t > f.timeMax) return false;
    }

    if (f.weightMin > 1 || f.weightMax < 5) {
      if (g.weight == null || g.weight <= 0) return false;
      if (g.weight < f.weightMin || g.weight > f.weightMax) return false;
    }

    if (f.tagInclude.length || f.tagExclude.length) {
      const ids = new Set(g.tags.map((t) => t.id));
      if (!f.tagInclude.every((id) => ids.has(id))) return false;
      if (f.tagExclude.some((id) => ids.has(id))) return false;
    }

    switch (f.expansionFilter) {
      case 'any': break;
      case 'missing':
        if (g.kind !== 'base' || !g.expansionStats || g.ownershipStatus !== 'owned') return false;
        if (g.expansionStats.known - g.expansionStats.owned <= 0) return false;
        break;
      case 'complete':
        if (g.kind !== 'base' || !g.expansionStats || g.expansionStats.known === 0) return false;
        if (g.expansionStats.owned < g.expansionStats.known) return false;
        break;
      case 'wishlist':
        if (g.kind === 'base' ? !(g.expansionStats && g.expansionStats.wishlist > 0) : g.ownershipStatus !== 'wishlist') return false;
        break;
      case 'exp_with_friends': {
        if (g.kind !== 'expansion' || g.ownershipStatus !== 'owned') return false;
        const friendOwned = g.ownerId != null && (!me || g.ownerId !== me.id);
        if (!(friendOwned || g.locationType === 'with_friend' || g.locationType === 'lent_out')) return false;
        break;
      }
      case 'exp_with_me_base_away':
        if (g.kind !== 'base' || !g.expansionStats?.ownedWithMeBaseAway) return false;
        break;
      case 'pending':
        if (g.kind === 'base' ? !(g.expansionStats && g.expansionStats.unverified > 0) : !(g.ownershipStatus === 'unverified' || g.dataStatus === 'stub')) return false;
        break;
    }

    if (!textMatch(g)) {
      if (g.kind === 'base' && qTerms.length) {
        const hits = (expansionsByBase.get(g.id) ?? []).filter(textMatch).map((e) => e.nameEn);
        if (hits.length) { matchedViaExpansion.set(g.id, hits); return true; }
      }
      return false;
    }
    return true;
  });

  sortGames(items, f.sort, f.sortDir);
  return { items, matchedViaExpansion };
}

export function sortGames(items: GameSummary[], key: SortKey, dir: 'asc' | 'desc'): void {
  const sign = dir === 'asc' ? 1 : -1;
  const nullsLast = (a: number | null, b: number | null) => {
    if (a == null && b == null) return 0;
    if (a == null) return 1;
    if (b == null) return -1;
    return (a - b) * sign;
  };
  items.sort((a, b) => {
    let r = 0;
    switch (key) {
      case 'name': r = a.nameEn.localeCompare(b.nameEn, 'pt-BR', { sensitivity: 'base' }) * sign; break;
      case 'year': r = nullsLast(a.year, b.year); break;
      case 'weight': r = nullsLast(a.weight, b.weight); break;
      case 'time': r = nullsLast(typicalTime(a), typicalTime(b)); break;
      case 'players': r = nullsLast(a.maxPlayers, b.maxPlayers); break;
      case 'best': r = nullsLast(a.bestVotes1, b.bestVotes1); break;
      case 'added': r = (a.id - b.id) * sign; break;
    }
    return r || a.nameEn.localeCompare(b.nameEn, 'pt-BR');
  });
}
