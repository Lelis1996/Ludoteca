export type OwnershipStatus = 'owned' | 'not_owned' | 'wishlist' | 'want_to_try' | 'reference' | 'unverified';
export type LocationType = 'with_me' | 'with_friend' | 'lent_out' | 'borrowed' | 'other';
export type GameKind = 'base' | 'expansion';
export type TagSource = 'bgg_derived' | 'inferred' | 'manual';
export type DataStatus = 'manual' | 'stub' | 'bgg_ok' | 'bgg_error';
export type ExpansionType =
  | 'content' | 'modular' | 'campaign' | 'characters' | 'maps' | 'scenarios' | 'promo' | 'fan' | 'other';

export interface Owner {
  id: number;
  name: string;
  color: string;
  isMe: boolean;
  gameCount?: number;
}

export interface Tag {
  id: number;
  name: string;
  grp: string;
  description: string | null;
  sort: number;
  gameCount?: number;
}

export interface GameTag {
  id: number;
  name: string;
  grp: string;
  source: TagSource;
  detail: string | null;
}

export interface PollRow {
  numPlayers: string;
  best: number;
  recommended: number;
  notRecommended: number;
}

/** Dados enxutos usados na biblioteca e nos filtros (carregados de uma vez no cliente). */
export interface GameSummary {
  id: number;
  bggId: number | null;
  kind: GameKind;
  standaloneExpansion: boolean;
  expansionType: ExpansionType | null;
  nameEn: string;
  namePt: string | null;
  year: number | null;
  thumb: string | null;
  minPlayers: number | null;
  maxPlayers: number | null;
  playingTime: number | null;
  minPlaytime: number | null;
  maxPlaytime: number | null;
  typicalTimeManual: number | null;
  weight: number | null;
  weightVotes: number | null;
  bestCount1: string | null;
  bestVotes1: number | null;
  bestCount2: string | null;
  bestVotes2: number | null;
  recommendedCounts: number[] | null; // null = não verificado
  pollTotalVotes: number | null;
  ownershipStatus: OwnershipStatus;
  ownerId: number | null;
  locationType: LocationType;
  locationPerson: string | null;
  locationCustom: string | null;
  loanDate: string | null;
  loanDueDate: string | null;
  favorite: boolean;
  dataStatus: DataStatus;
  tags: { id: number; source: TagSource }[];
  mechanics: string[];
  categories: string[];
  designers: string[];
  publishers: string[];
  baseIds: number[];          // jogos-base (para expansões)
  baseNames: string[];
  expansionStats: ExpansionStats | null; // para jogos-base
}

export interface ExpansionStats {
  known: number;        // expansões verificadas (excluindo promos e fan-made)
  owned: number;        // possuídas entre as verificadas
  wishlist: number;
  unverified: number;   // ainda não verificadas / dados pendentes
  promos: number;
  fan: number;
  standalone: number;  // jogos independentes que o BGG lista como expansão
  withFriends: number;  // expansões de amigos
  awayFromHome: number; // fora de casa
  ownedWithMeBaseAway: boolean;
}

export interface FieldSource {
  field: string;
  source: 'bgg' | 'manual' | 'calculated' | 'inferred';
  status: 'verified' | 'unverified' | 'unavailable';
  note: string | null;
  updatedAt: string;
}

export interface Loan {
  id: number;
  direction: 'lent_out' | 'borrowed';
  person: string | null;
  startDate: string | null;
  dueDate: string | null;
  returnedAt: string | null;
  notes: string | null;
}

export interface RelatedRef {
  relationId: number;
  relation: string;
  source: 'bgg' | 'manual';
  gameId: number | null;
  bggId: number | null;
  name: string;
}

export interface GameDetail extends Omit<GameSummary, 'tags'> {
  bggType: string | null;
  namePtSource: string | null;
  altNames: string[];
  ptVersions: { name: string; publisher: string | null; year: number | null }[];
  description: string | null;
  image: string | null;
  minAge: number | null;
  usersRated: number | null;
  avgRating: number | null;
  bggRank: number | null;
  pollBestSummary: string | null;
  pollRecSummary: string | null;
  poll: PollRow[];
  timePerPlayerManual: number | null;
  timeBasePlayersManual: number | null;
  timeNote: string | null;
  expansionTypeSource: string | null;
  notes: string | null;
  acquiredAt: string | null;
  pricePaid: number | null;
  lastVerifiedAt: string | null;
  manualFields: string[];
  bggFetchedAt: string | null;
  bggError: string | null;
  createdAt: string;
  updatedAt: string;
  tags: GameTag[];
  rejectedTags: GameTag[];
  families: string[];
  artists: string[];
  subdomains: string[];
  fieldSources: FieldSource[];
  loans: Loan[];
  bases: RelatedRef[];        // jogos-base desta expansão
  expansions: GameSummary[];  // expansões deste jogo-base
  otherRelations: RelatedRef[];
}

export interface BggSearchResult {
  bggId: number;
  name: string;
  nameType: 'primary' | 'alternate';
  year: number | null;
  type: 'boardgame' | 'boardgameexpansion';
  inCollectionGameId?: number | null;
  thumb?: string | null;
  usersRated?: number | null;
  primaryName?: string | null;
  isExpansionOf?: { bggId: number; name: string }[];
  standaloneExpansion?: boolean;
  similarity?: number;
}

export interface AppStatus {
  bggConfigured: boolean;
  bggBaseUrl: string;
  visionProvider: 'anthropic' | 'ocr' | 'none';
  visionModel: string | null;
  ocrAvailable: boolean;
  dbPath: string;
  version: string;
  embedded?: boolean;
  unlinkedCount?: number;
}

export interface WeightBand { min: number; label: string }
export interface Settings {
  weightBands: WeightBand[];
  durationShortMax: number;
  durationMediumMax: number;
}
