import type {
  GameSummary, LocationType, OwnershipStatus, Settings, WeightBand, ExpansionType, Owner,
} from './types';

export const DEFAULT_SETTINGS: Settings = {
  weightBands: [
    { min: 1.0, label: 'Muito leve' },
    { min: 1.5, label: 'Leve' },
    { min: 2.0, label: 'Médio' },
    { min: 3.0, label: 'Pesado' },
    { min: 4.0, label: 'Muito pesado' },
  ],
  durationShortMax: 45,
  durationMediumMax: 90,
};

export function weightLabel(weight: number | null | undefined, bands: WeightBand[] = DEFAULT_SETTINGS.weightBands): string | null {
  if (weight == null || !(weight > 0)) return null;
  const sorted = [...bands].sort((a, b) => a.min - b.min);
  let label = sorted[0]?.label ?? null;
  for (const b of sorted) if (weight >= b.min) label = b.label;
  return label;
}

/** Faixa [min, max) de peso para uma faixa nomeada. */
export function weightBandRange(label: string, bands: WeightBand[] = DEFAULT_SETTINGS.weightBands): [number, number] | null {
  const sorted = [...bands].sort((a, b) => a.min - b.min);
  const i = sorted.findIndex((b) => b.label === label);
  if (i < 0) return null;
  return [sorted[i].min, i + 1 < sorted.length ? sorted[i + 1].min : 5.0001];
}

export const OWNERSHIP_LABELS: Record<OwnershipStatus, string> = {
  owned: 'Possuo',
  not_owned: 'Não possuo',
  wishlist: 'Quero comprar',
  want_to_try: 'Quero experimentar',
  reference: 'Só consulta',
  unverified: 'Não verificado',
};

export const LOCATION_LABELS: Record<LocationType, string> = {
  with_me: 'Comigo',
  with_friend: 'Com um amigo',
  lent_out: 'Emprestado para alguém',
  borrowed: 'Emprestado por alguém (está comigo)',
  other: 'Outra localização',
};

export const EXPANSION_TYPE_LABELS: Record<ExpansionType, string> = {
  content: 'Conteúdo adicional',
  modular: 'Expansão modular',
  campaign: 'Campanha',
  characters: 'Personagens',
  maps: 'Mapas',
  scenarios: 'Cenários',
  promo: 'Promo',
  fan: 'Feita por fãs',
  other: 'Outra',
};

/** Se o item está fisicamente comigo. */
export function isWithMe(g: Pick<GameSummary, 'locationType'>): boolean {
  return g.locationType === 'with_me' || g.locationType === 'borrowed';
}

/** Item que existe fisicamente na coleção acessível (meu ou de amigo, possuído). */
export function isPhysical(g: Pick<GameSummary, 'ownershipStatus'>): boolean {
  return g.ownershipStatus === 'owned';
}

export function isLoanActive(g: Pick<GameSummary, 'locationType'>): boolean {
  return g.locationType === 'lent_out' || g.locationType === 'borrowed';
}

/** Frase de localização para exibição, ex.: "Com Fulano — não está comigo". */
export function locationPhrase(g: Pick<GameSummary, 'locationType' | 'locationPerson' | 'locationCustom' | 'ownerId'>, owners: Owner[]): string {
  const owner = owners.find((o) => o.id === g.ownerId);
  const who = g.locationPerson?.trim();
  switch (g.locationType) {
    case 'with_me':
      return 'Comigo';
    case 'borrowed':
      return `Comigo — emprestado por ${who || owner?.name || 'alguém'}`;
    case 'with_friend':
      return `Com ${who || (owner && !owner.isMe ? owner.name : 'um amigo')} — não está comigo`;
    case 'lent_out':
      return `Emprestado para ${who || 'alguém'} — não está comigo`;
    case 'other':
      return `${g.locationCustom?.trim() || 'Outro local'} — não está comigo`;
  }
}

/** Tempo típico usado nos filtros e cards: manual > "playing time" do BGG > máximo oficial. */
export function typicalTime(g: Pick<GameSummary, 'typicalTimeManual' | 'playingTime' | 'maxPlaytime' | 'minPlaytime'>): number | null {
  return g.typicalTimeManual ?? g.playingTime ?? g.maxPlaytime ?? g.minPlaytime ?? null;
}

export function formatPlayers(min: number | null, max: number | null): string {
  if (min == null && max == null) return '—';
  if (min != null && max != null) return min === max ? `${min}` : `${min}–${max}`;
  return `${min ?? max}`;
}

export function formatTime(min: number | null, max: number | null): string {
  if (min == null && max == null) return '—';
  if (min != null && max != null && min !== max) return `${min}–${max} min`;
  return `${min ?? max} min`;
}

export interface PlayerTimeEstimate {
  players: number;
  minutes: number | null;
  kind: 'official' | 'manual_estimate' | 'unavailable';
  note: string;
}

/**
 * Estimativas por nº de jogadores. Nunca extrapola linearmente por conta própria:
 * só calcula quando o usuário informou minutos por jogador e o nº de jogadores de referência.
 */
export function playerTimeTable(g: {
  minPlayers: number | null; maxPlayers: number | null;
  minPlaytime: number | null; maxPlaytime: number | null; playingTime: number | null;
  typicalTimeManual: number | null; timePerPlayerManual: number | null; timeBasePlayersManual: number | null;
}): PlayerTimeEstimate[] {
  const out: PlayerTimeEstimate[] = [];
  for (let p = 2; p <= 6; p++) {
    if (g.minPlayers != null && p < g.minPlayers) continue;
    if (g.maxPlayers != null && p > g.maxPlayers) continue;
    if (g.timePerPlayerManual != null && g.timeBasePlayersManual != null) {
      const base = g.typicalTimeManual ?? g.playingTime;
      if (base != null) {
        out.push({
          players: p,
          minutes: Math.max(1, Math.round(base + (p - g.timeBasePlayersManual) * g.timePerPlayerManual)),
          kind: 'manual_estimate',
          note: `Estimativa: ${base} min com ${g.timeBasePlayersManual} jogadores ${g.timePerPlayerManual >= 0 ? '+' : ''}${g.timePerPlayerManual} min por jogador (informado por você)`,
        });
        continue;
      }
    }
    out.push({ players: p, minutes: null, kind: 'unavailable', note: 'Não disponível — o BGG publica apenas a faixa oficial' });
  }
  return out;
}

export function durationBucket(minutes: number | null, s: Settings = DEFAULT_SETTINGS): 'Duração curta' | 'Duração média' | 'Duração longa' | null {
  if (minutes == null) return null;
  if (minutes <= s.durationShortMax) return 'Duração curta';
  if (minutes <= s.durationMediumMax) return 'Duração média';
  return 'Duração longa';
}

export function normalizeText(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

export function displayName(g: { nameEn: string; namePt: string | null }): string {
  return g.nameEn;
}

/** Garante contraste mínimo do texto colorido sobre o fundo escuro da interface. */
export function readableOnDark(hex: string): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return '#f5f1e8';
  const n = parseInt(m[1], 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  const lum = () => {
    const f = (c: number) => { const v = c / 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  };
  const bgL = 0.012; // ~#1b1814
  let i = 0;
  while ((lum() + 0.05) / (bgL + 0.05) < 4.5 && i < 20) {
    r = Math.min(255, Math.round(r + (255 - r) * 0.15));
    g = Math.min(255, Math.round(g + (255 - g) * 0.15));
    b = Math.min(255, Math.round(b + (255 - b) * 0.15));
    i++;
  }
  return '#' + [r, g, b].map((c) => c.toString(16).padStart(2, '0')).join('');
}
