/**
 * Rotas da API, independentes de plataforma: usadas pelo Express (computador)
 * e chamadas diretamente dentro do app de celular.
 */
import { ZodError, z } from 'zod';
import type { DB } from './dbtypes';
import { BggClient, BggError } from './bgg/client';
import { BggService } from './services/bggService';
import type { ImageStore, MediaStore } from './services/ports';
import { getDetail, getSettings, listSummaries, refreshDurationTag } from './services/games';
import {
  HttpError, addManualTag, addRelation, createManualGame, deleteGame, ownerSchema, patchGame, removeRelation,
  removeTag, restoreBggField, restoreTag, tagSchema,
} from './services/mutations';
import { exportCsv, exportJson, importJson } from './services/backup';
import { ImportService } from './services/imports';
import type { VisionProvider } from './vision/core';
import type { AppStatus, Owner, Settings } from '../shared/types';
import { BEST_WITH_METHOD } from './bgg/derive';
import { getSetting, setSetting } from './core';
import { applySeedCollection, SEED_COLLECTION_VERSION } from './services/seed';

export interface UploadedFile { originalname: string; buffer: Uint8Array }
export interface RouteRequest {
  params: Record<string, string>;
  query: Record<string, string | undefined>;
  body: any;
  files?: UploadedFile[];
}
export interface Route {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  status?: number;
  upload?: boolean;
  download?: { filename: () => string; type: string };
  handler: (r: RouteRequest) => unknown;
}

export interface Secrets { bggToken: string | null; anthropicKey: string | null; visionModel: string | null }

export interface CoreOptions {
  db: DB;
  bggToken: string | null;
  bggBaseUrl: string;
  bggMinIntervalMs: number;
  bggCacheTtlHours: number;
  fetchImpl?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
  images: ImageStore;
  media: MediaStore;
  /** escolhe o reconhecimento de fotos conforme a configuração atual */
  provider: (secrets: Secrets) => VisionProvider | null;
  /** app de celular: tokens ficam nas configurações do próprio app */
  embedded: boolean;
  dbLabel: string;
  defaultVisionModel: string;
}

export function createCore(o: CoreOptions) {
  const { db } = o;
  const secrets = (): Secrets => {
    const s = o.embedded ? getSetting<Partial<Secrets>>(db, 'secrets', {}) : {};
    return { bggToken: s.bggToken ?? null, anthropicKey: s.anthropicKey ?? null, visionModel: s.visionModel ?? null };
  };
  const client = new BggClient({
    db, token: o.embedded ? secrets().bggToken : o.bggToken, baseUrl: o.bggBaseUrl, minIntervalMs: o.bggMinIntervalMs,
    cacheTtlHours: o.bggCacheTtlHours, fetchImpl: o.fetchImpl, sleep: o.sleep,
  });
  const bgg = new BggService(db, client, o.images);
  let cachedProvider: { key: string; p: VisionProvider | null } | null = null;
  const provider = (): VisionProvider | null => {
    const s = secrets();
    const key = JSON.stringify(s);
    if (!cachedProvider || cachedProvider.key !== key) cachedProvider = { key, p: o.provider(s) };
    return cachedProvider.p;
  };
  const imports = new ImportService(db, o.media, bgg, provider);
  const routes = buildRoutes({ ...o, client, bgg, imports, provider, secrets });
  return { db, client, bgg, imports, provider, routes, secrets };
}

type Ctx = CoreOptions & {
  client: BggClient; bgg: BggService; imports: ImportService; provider: () => VisionProvider | null; secrets: () => Secrets;
};

function buildRoutes(c: Ctx): Route[] {
  const { db, bgg, imports, client } = c;
  const routes: Route[] = [];
  const add = (method: Route['method'], path: string, handler: Route['handler'], extra: Partial<Route> = {}) =>
    routes.push({ method, path, handler, ...extra });
  const id = (r: RouteRequest, key = 'id') => {
    const n = Number(r.params[key]);
    if (!Number.isInteger(n) || n <= 0) throw new HttpError(400, 'ID inválido.');
    return n;
  };
  const ownerList = (): Owner[] => (db.prepare(`SELECT o.*, (SELECT COUNT(*) FROM games g WHERE g.owner_id = o.id AND g.ownership_status = 'owned') n FROM owners o ORDER BY is_me DESC, name`).all() as any[])
    .map((o) => ({ id: o.id, name: o.name, color: o.color, isMe: !!o.is_me, gameCount: o.n }));

  // ---------- status e configurações ----------
  add('GET', '/api/status', () => {
    const p = c.provider();
    const s = c.secrets();
    const status: AppStatus & Record<string, unknown> = {
      bggConfigured: client.configured,
      bggBaseUrl: c.bggBaseUrl,
      visionProvider: p ? (p.name === 'fake' ? 'anthropic' : p.name) : 'none',
      visionModel: p?.name === 'anthropic' ? (s.visionModel || c.defaultVisionModel) : null,
      ocrAvailable: true,
      dbPath: c.dbLabel,
      version: '1.1.0',
      embedded: c.embedded,
      bestWithMethod: BEST_WITH_METHOD,
      unlinkedCount: (db.prepare('SELECT COUNT(*) n FROM games WHERE bgg_id IS NULL').get() as { n: number }).n,
    };
    return status;
  });

  const settingsSchema = z.object({
    weightBands: z.array(z.object({ min: z.number().min(1).max(5), label: z.string().trim().min(1).max(40) })).min(1).max(10),
    durationShortMax: z.number().int().min(1).max(1000),
    durationMediumMax: z.number().int().min(1).max(2000),
  });
  add('GET', '/api/settings', () => getSettings(db));
  add('PUT', '/api/settings', (r) => {
    const s: Settings = settingsSchema.parse(r.body);
    if (s.durationShortMax >= s.durationMediumMax) throw new HttpError(400, 'A duração curta deve ser menor que a média.');
    db.prepare(`UPDATE settings SET value = ? WHERE key = 'app'`).run(JSON.stringify(s));
    for (const g of db.prepare('SELECT id FROM games').all() as { id: number }[]) refreshDurationTag(db, g.id);
    return s;
  });

  if (c.embedded) {
    // Tokens guardados no próprio aparelho (só no app de celular)
    add('GET', '/api/secrets', () => {
      const s = c.secrets();
      const mask = (v: string | null) => (v ? `${v.slice(0, 4)}…${v.slice(-4)}` : null);
      return { bggToken: mask(s.bggToken), anthropicKey: mask(s.anthropicKey), visionModel: s.visionModel ?? c.defaultVisionModel };
    });
    add('PUT', '/api/secrets', (r) => {
      const b = z.object({
        bggToken: z.string().trim().max(500).nullable().optional(),
        anthropicKey: z.string().trim().max(500).nullable().optional(),
        visionModel: z.string().trim().max(100).nullable().optional(),
      }).parse(r.body);
      const cur = getSetting<Partial<Secrets>>(db, 'secrets', {});
      const next = { ...cur };
      for (const k of ['bggToken', 'anthropicKey', 'visionModel'] as const) if (b[k] !== undefined) next[k] = b[k] || null;
      setSetting(db, 'secrets', next);
      client.setToken(next.bggToken ?? null);
      return { ok: true };
    });
  }

  // ---------- coleção inicial ----------
  add('POST', '/api/seed-collection', () => applySeedCollection(db, true));
  add('GET', '/api/seed-collection', () => ({ version: SEED_COLLECTION_VERSION, applied: getSetting(db, 'seed_collection', null) }));

  // ---------- proprietários ----------
  add('GET', '/api/owners', () => ownerList());
  add('POST', '/api/owners', (r) => {
    const o = ownerSchema.parse(r.body);
    if (db.prepare('SELECT 1 FROM owners WHERE name = ? COLLATE NOCASE').get(o.name)) throw new HttpError(409, 'Já existe um proprietário com esse nome.');
    const newId = Number(db.prepare('INSERT INTO owners (name, color) VALUES (?, ?)').run(o.name, o.color).lastInsertRowid);
    return ownerList().find((x) => x.id === newId);
  }, { status: 201 });
  add('PUT', '/api/owners/:id', (r) => {
    const o = ownerSchema.parse(r.body);
    const oid = id(r);
    if (db.prepare('SELECT 1 FROM owners WHERE name = ? COLLATE NOCASE AND id <> ?').get(o.name, oid)) throw new HttpError(409, 'Já existe um proprietário com esse nome.');
    if (!db.prepare('UPDATE owners SET name = ?, color = ? WHERE id = ?').run(o.name, o.color, oid).changes) throw new HttpError(404, 'Proprietário não encontrado.');
    return ownerList().find((x) => x.id === oid);
  });
  add('DELETE', '/api/owners/:id', (r) => {
    const oid = id(r);
    const o = db.prepare('SELECT * FROM owners WHERE id = ?').get(oid) as any;
    if (!o) throw new HttpError(404, 'Proprietário não encontrado.');
    if (o.is_me) throw new HttpError(400, '"Meus jogos" não pode ser excluído (você pode renomeá-lo).');
    const me = db.prepare('SELECT id FROM owners WHERE is_me = 1').get() as { id: number };
    const target = r.query.reassignTo ? Number(r.query.reassignTo) : me.id;
    db.transaction(() => {
      db.prepare('UPDATE games SET owner_id = ? WHERE owner_id = ?').run(target, oid);
      db.prepare('DELETE FROM owners WHERE id = ?').run(oid);
    })();
    return { ok: true };
  });

  // ---------- etiquetas ----------
  const tagList = () => db.prepare(`SELECT t.*, (SELECT COUNT(*) FROM game_tags gt WHERE gt.tag_id = t.id AND gt.status = 'active') gameCount FROM tags t ORDER BY sort, name`).all();
  add('GET', '/api/tags', () => tagList());
  add('POST', '/api/tags', (r) => {
    const t = tagSchema.parse(r.body);
    if (db.prepare('SELECT 1 FROM tags WHERE name = ? COLLATE NOCASE').get(t.name)) throw new HttpError(409, 'Essa etiqueta já existe.');
    const tid = db.prepare('INSERT INTO tags (name, grp, description, sort) VALUES (?, ?, ?, 500)').run(t.name, t.grp, t.description ?? null).lastInsertRowid;
    return db.prepare('SELECT * FROM tags WHERE id = ?').get(tid);
  }, { status: 201 });
  add('PUT', '/api/tags/:id', (r) => {
    const t = tagSchema.parse(r.body);
    const tid = id(r);
    if (db.prepare('SELECT 1 FROM tags WHERE name = ? COLLATE NOCASE AND id <> ?').get(t.name, tid)) throw new HttpError(409, 'Essa etiqueta já existe.');
    if (!db.prepare('UPDATE tags SET name = ?, grp = ?, description = ? WHERE id = ?').run(t.name, t.grp, t.description ?? null, tid).changes) throw new HttpError(404, 'Etiqueta não encontrada.');
    return db.prepare('SELECT * FROM tags WHERE id = ?').get(tid);
  });
  add('DELETE', '/api/tags/:id', (r) => { db.prepare('DELETE FROM tags WHERE id = ?').run(id(r)); return { ok: true }; });

  // ---------- jogos ----------
  add('GET', '/api/games', () => listSummaries(db));
  add('GET', '/api/games/:id', (r) => {
    const g = getDetail(db, id(r));
    if (!g) throw new HttpError(404, 'Jogo não encontrado.');
    return g;
  });
  add('POST', '/api/games', (r) => getDetail(db, createManualGame(db, r.body)), { status: 201 });
  const fromBggSchema = z.object({
    bggId: z.number().int().positive(),
    ownershipStatus: z.enum(['owned', 'wishlist', 'want_to_try', 'reference']).default('owned'),
    ownerId: z.number().int().nullable().optional(),
    locationType: z.enum(['with_me', 'with_friend', 'lent_out', 'borrowed', 'other']).default('with_me'),
    locationPerson: z.string().trim().max(200).nullable().optional(),
  });
  add('POST', '/api/games/from-bgg', async (r) => {
    const b = fromBggSchema.parse(r.body);
    const me = db.prepare('SELECT id FROM owners WHERE is_me = 1').get() as { id: number };
    const ownerId = b.ownerId === undefined ? me.id : b.ownerId;
    const rows = db.prepare('SELECT id, ownership_status, owner_id FROM games WHERE bgg_id = ? ORDER BY id').all(b.bggId) as any[];
    const sameOwner = rows.find((x) => x.owner_id === ownerId && !['unverified', 'not_owned', 'reference'].includes(x.ownership_status));
    if (sameOwner) throw new HttpError(409, 'Este jogo já está cadastrado para este proprietário.', { duplicateId: sameOwner.id });
    const placeholder = rows.find((x) => ['unverified', 'not_owned', 'reference'].includes(x.ownership_status));
    const defaults = { ownership_status: b.ownershipStatus, owner_id: ownerId, location_type: b.locationType, location_person: b.locationPerson ?? null };
    let gid: number;
    if (placeholder) {
      patchGame(db, placeholder.id, { ownershipStatus: b.ownershipStatus, ownerId, locationType: b.locationType, locationPerson: b.locationPerson ?? null });
      gid = placeholder.id;
      await bgg.refresh(gid).catch(() => undefined);
    } else {
      // outra pessoa já tem uma cópia: cria a cópia deste proprietário
      gid = await bgg.addFromBgg(b.bggId, { defaults, createNew: rows.length > 0 });
    }
    return getDetail(db, gid);
  }, { status: 201 });
  add('PATCH', '/api/games/:id', (r) => { const gid = id(r); patchGame(db, gid, r.body); return getDetail(db, gid); });
  add('DELETE', '/api/games/:id', (r) => deleteGame(db, id(r)));
  add('POST', '/api/games/:id/refresh', async (r) => { const gid = id(r); await bgg.refresh(gid, { force: true }); return getDetail(db, gid); });
  add('POST', '/api/games/:id/expansions/refresh', async (r) => {
    const gid = id(r);
    const g = db.prepare('SELECT bgg_id FROM games WHERE id = ?').get(gid) as any;
    if (!g) throw new HttpError(404, 'Jogo não encontrado.');
    if (g.bgg_id) await bgg.refresh(gid);
    const res = await bgg.refreshExpansions(gid, { onlyMissing: !!r.body?.onlyMissing });
    return { ...res, game: getDetail(db, gid) };
  });
  add('POST', '/api/games/:id/link-bgg', async (r) => {
    const gid = id(r);
    const { bggId } = z.object({ bggId: z.number().int().positive() }).parse(r.body);
    await bgg.link(gid, bggId);
    return getDetail(db, gid);
  });
  add('POST', '/api/games/:id/restore-field', async (r) => {
    const gid = id(r);
    const { field } = z.object({ field: z.string().min(1) }).parse(r.body);
    restoreBggField(db, gid, field);
    const g = db.prepare('SELECT bgg_id FROM games WHERE id = ?').get(gid) as any;
    if (g?.bgg_id) await bgg.refresh(gid).catch(() => undefined);
    return getDetail(db, gid);
  });
  add('POST', '/api/games/:id/tags', (r) => {
    const gid = id(r);
    addManualTag(db, gid, z.object({ tagId: z.number().int().optional(), name: z.string().trim().min(1).max(80).optional() }).parse(r.body));
    return getDetail(db, gid);
  });
  add('DELETE', '/api/games/:id/tags/:tagId', (r) => { const gid = id(r); removeTag(db, gid, id(r, 'tagId')); return getDetail(db, gid); });
  add('POST', '/api/games/:id/tags/:tagId/restore', (r) => { const gid = id(r); restoreTag(db, gid, id(r, 'tagId')); return getDetail(db, gid); });
  add('POST', '/api/games/:id/relations', (r) => {
    const gid = id(r);
    const { baseGameId } = z.object({ baseGameId: z.number().int().positive() }).parse(r.body);
    addRelation(db, gid, baseGameId);
    return getDetail(db, gid);
  });
  add('DELETE', '/api/relations/:id', (r) => {
    const rel = db.prepare('SELECT game_id FROM game_relations WHERE id = ?').get(id(r)) as any;
    removeRelation(db, id(r));
    return rel ? getDetail(db, rel.game_id) : { ok: true };
  });
  add('POST', '/api/games/:id/return', (r) => {
    const gid = id(r);
    const g = db.prepare('SELECT location_type FROM games WHERE id = ?').get(gid) as any;
    if (!g) throw new HttpError(404, 'Jogo não encontrado.');
    // Meu jogo emprestado volta para mim; jogo de amigo que estava comigo volta para o amigo
    const next = g.location_type === 'borrowed' ? 'with_friend' : 'with_me';
    patchGame(db, gid, { locationType: next, locationPerson: null, loanDate: null, loanDueDate: null });
    return getDetail(db, gid);
  });

  // ---------- BGG ----------
  add('GET', '/api/bgg/search', async (r) => {
    const q = String(r.query.q ?? '').trim();
    if (q.length < 2) throw new HttpError(400, 'Digite pelo menos 2 caracteres.');
    return bgg.search(q);
  });

  // ---------- backup ----------
  const today = () => new Date().toISOString().slice(0, 10);
  add('GET', '/api/export.json', () => exportJson(db), { download: { filename: () => `ludoteca-${today()}.json`, type: 'application/json' } });
  add('GET', '/api/export.csv', () => exportCsv(db), { download: { filename: () => `ludoteca-${today()}.csv`, type: 'text/csv; charset=utf-8' } });
  add('POST', '/api/import-backup', (r) => importJson(db, r.body));

  // ---------- importação por fotos e vínculo em lote ----------
  add('GET', '/api/imports', () => imports.list());
  add('POST', '/api/imports', async (r) => {
    const num = (v: unknown) => (v == null || v === '' ? null : Number(v));
    const b = r.body ?? {};
    const batchId = await imports.createBatch(r.files ?? [], {
      ownerId: num(b.ownerId), locationType: b.locationType || 'with_me',
      locationPerson: b.locationPerson || null, ownershipStatus: b.ownershipStatus || 'owned',
    });
    return imports.get(batchId);
  }, { status: 201, upload: true });
  add('POST', '/api/imports/link-bgg', (r) => {
    const { gameIds } = z.object({ gameIds: z.array(z.number().int()).optional() }).parse(r.body ?? {});
    return imports.get(imports.createListBatch(gameIds));
  }, { status: 201 });
  add('GET', '/api/imports/:id', (r) => {
    const b = imports.get(id(r));
    if (!b) throw new HttpError(404, 'Importação não encontrada.');
    return b;
  });
  add('DELETE', '/api/imports/:id', (r) => { imports.deleteBatch(id(r)); return { ok: true }; });
  add('PATCH', '/api/import-candidates/:id', (r) => {
    imports.updateCandidate(id(r), z.object({
      status: z.enum(['pending', 'confirmed', 'ignored']).optional(),
      selectedBggId: z.number().int().positive().nullable().optional(),
      detectedTitle: z.string().trim().min(1).max(300).optional(),
    }).parse(r.body));
    return { ok: true };
  });
  add('POST', '/api/import-candidates/:id/search', async (r) => {
    const { query } = z.object({ query: z.string().trim().min(1).max(300) }).parse(r.body);
    await imports.research(id(r), query);
    return { ok: true };
  });
  add('POST', '/api/import-photos/:id/candidates', async (r) => {
    const { title } = z.object({ title: z.string().trim().min(1).max(300) }).parse(r.body);
    return { id: await imports.addManualCandidate(id(r), title) };
  }, { status: 201 });
  add('POST', '/api/imports/:id/commit', async (r) => {
    const b = z.object({
      ownerId: z.number().int().nullable().optional(),
      locationType: z.enum(['with_me', 'with_friend', 'lent_out', 'borrowed', 'other']).optional(),
      locationPerson: z.string().trim().max(200).nullable().optional(),
      ownershipStatus: z.enum(['owned', 'wishlist', 'want_to_try', 'reference']).optional(),
    }).parse(r.body ?? {});
    const res = await imports.commit(id(r), b);
    return { ...res, batch: imports.get(id(r)) };
  });

  return routes;
}

/** Encontra a rota para um método + caminho. */
export function matchRoute(routes: Route[], method: string, path: string): { route: Route; params: Record<string, string> } | null {
  for (const route of routes) {
    if (route.method !== method) continue;
    const a = route.path.split('/'), b = path.split('/');
    if (a.length !== b.length) continue;
    const params: Record<string, string> = {};
    let ok = true;
    for (let i = 0; i < a.length; i++) {
      if (a[i].startsWith(':')) params[a[i].slice(1)] = decodeURIComponent(b[i]);
      else if (a[i] !== b[i]) { ok = false; break; }
    }
    if (ok) return { route, params };
  }
  return null;
}

/** Converte qualquer erro numa resposta HTTP com mensagem em português. */
export function errorResponse(err: any): { status: number; body: Record<string, unknown> } {
  if (err instanceof ZodError) {
    return { status: 400, body: { error: 'Dados inválidos: ' + err.issues.map((i) => `${i.path.join('.') || 'corpo'}: ${i.message}`).join('; ') } };
  }
  if (err instanceof HttpError) return { status: err.status, body: { error: err.message, ...err.extra } };
  if (err instanceof BggError) {
    const status = err.code === 'not_configured' ? 503 : err.code === 'rate_limited' ? 429 : 502;
    return { status, body: { error: err.message, bgg: err.code } };
  }
  if (err?.type === 'entity.parse.failed') return { status: 400, body: { error: 'JSON inválido.' } };
  if (err?.code === 'LIMIT_FILE_SIZE') return { status: 413, body: { error: 'Foto muito grande (máximo 30 MB).' } };
  if (err?.status === 404 || err?.statusCode === 404) return { status: 404, body: { error: 'Arquivo não encontrado.' } };
  console.error(err);
  return { status: 500, body: { error: 'Erro interno: ' + (err?.message ?? 'desconhecido') } };
}
