import express, { type NextFunction, type Request, type Response } from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import { openDb, type DB } from './db';
import type { Config } from './config';
import { ImageCache } from './services/images';
import { nodeMediaStore } from './services/nodeMedia';
import { createNodeAnthropic, createNodeOcr, type OcrVision, type VisionProvider } from './vision/node';
import { createCore, errorResponse, type RouteRequest } from './routes';
import { applySeedCollection } from './services/seed';

export interface AppDeps {
  config: Config;
  db?: DB;
  fetchImpl?: typeof fetch;
  imageFetch?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
  visionProvider?: VisionProvider | null;
  /** cadastra a coleção inicial no primeiro uso (desligado nos testes) */
  seedCollection?: boolean;
}

/** Servidor para computador: Express em cima das rotas comuns. */
export function createApp(deps: AppDeps) {
  const { config } = deps;
  const opened = deps.db ? null : openDb(config.dbPath);
  const db = deps.db ?? opened!;
  if (deps.seedCollection ?? config.seedCollection) applySeedCollection(db);
  const images = new ImageCache(db, path.join(config.dataDir, 'images'), config.downloadImages, deps.imageFetch);
  const uploadsDir = path.join(config.dataDir, 'uploads');
  let ocr: OcrVision | null = null;
  const core = createCore({
    db, bggToken: config.bggToken, bggBaseUrl: config.bggBaseUrl, bggMinIntervalMs: config.bggMinIntervalMs,
    bggCacheTtlHours: config.bggCacheTtlHours, fetchImpl: deps.fetchImpl, sleep: deps.sleep, images,
    media: nodeMediaStore(uploadsDir), embedded: false, dbLabel: config.dbPath, defaultVisionModel: config.visionModel,
    provider: () => {
      if (deps.visionProvider !== undefined) return deps.visionProvider;
      const wantAnthropic = config.visionProvider === 'anthropic' || config.visionProvider === 'auto';
      if (wantAnthropic && config.anthropicApiKey) return createNodeAnthropic(config.anthropicApiKey, config.visionModel, deps.fetchImpl);
      if (config.visionProvider === 'none') return null;
      ocr ??= createNodeOcr(config.dataDir);
      return ocr;
    },
  });

  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '50mb' }));
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 30 * 1024 * 1024, files: 30 } });

  for (const route of core.routes) {
    const handlers: express.RequestHandler[] = [];
    if (route.upload) handlers.push(upload.array('photos', 30));
    handlers.push(async (req: Request, res: Response, next: NextFunction) => {
      try {
        const r: RouteRequest = {
          params: req.params as Record<string, string>,
          query: req.query as Record<string, string>,
          body: req.body,
          files: ((req.files as Express.Multer.File[] | undefined) ?? []).map((f) => ({ originalname: f.originalname, buffer: f.buffer })),
        };
        const data = await route.handler(r);
        if (route.download) {
          res.setHeader('Content-Type', route.download.type);
          res.setHeader('Content-Disposition', `attachment; filename="${route.download.filename()}"`);
          return res.send(typeof data === 'string' ? data : JSON.stringify(data));
        }
        res.status(route.status ?? 200).json(data);
      } catch (e) {
        next(e);
      }
    });
    (app as any)[route.method.toLowerCase()](route.path, ...handlers);
  }

  // cópia do banco (só no computador)
  app.get('/api/backup.sqlite', async (_req, res, next) => {
    try {
      const dir = path.join(config.dataDir, 'backups');
      fs.mkdirSync(dir, { recursive: true });
      const file = path.join(dir, `ludoteca-${new Date().toISOString().replace(/[:.]/g, '-')}.db`);
      await (db as any).raw?.backup(file) ?? (db as any).backup(file);
      res.download(file);
    } catch (e) { next(e); }
  });

  app.use('/images', express.static(path.join(config.dataDir, 'images'), { maxAge: '30d', fallthrough: false }));
  app.use('/uploads', express.static(uploadsDir, { fallthrough: false }));
  const clientDir = path.join(config.root, 'dist', 'client');
  if (fs.existsSync(clientDir)) {
    app.use(express.static(clientDir, { index: false, maxAge: '1h' }));
    app.get(/^(?!\/api\/).*/, (_req, res) => res.sendFile(path.join(clientDir, 'index.html')));
  }
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Rota não encontrada.' }));
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const r = errorResponse(err);
    res.status(r.status).json(r.body);
  });

  return { app, db, bgg: core.bgg, client: core.client, images, imports: core.imports, close: async () => { await ocr?.close(); db.close(); } };
}
