import { z } from 'zod';
import type { DB } from '../dbtypes';
import { BGG_FIELDS, PERSONAL_FIELDS, refreshDurationTag, tagIdByName } from './games';

export class HttpError extends Error {
  constructor(public status: number, message: string, public extra?: Record<string, unknown>) { super(message); }
}

const ownership = z.enum(['owned', 'not_owned', 'wishlist', 'want_to_try', 'reference', 'unverified']);
const location = z.enum(['with_me', 'with_friend', 'lent_out', 'borrowed', 'other']);
const expType = z.enum(['content', 'modular', 'campaign', 'characters', 'maps', 'scenarios', 'promo', 'fan', 'other']);
const optInt = (min = 0, max = 100000) => z.number().int().min(min).max(max).nullable();
const optStr = (max = 5000) => z.string().trim().max(max).nullable().transform((v) => (v === '' ? null : v));
const optDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data no formato AAAA-MM-DD').nullable().or(z.literal('').transform(() => null));

export const gamePatchSchema = z.object({
  nameEn: z.string().trim().min(1).max(300),
  namePt: optStr(300),
  year: optInt(-5000, 3000),
  description: optStr(20000),
  image: optStr(2000),
  thumb: optStr(2000),
  minPlayers: optInt(1, 100),
  maxPlayers: optInt(1, 100),
  playingTime: optInt(1, 10000),
  minPlaytime: optInt(1, 10000),
  maxPlaytime: optInt(1, 10000),
  minAge: optInt(0, 99),
  weight: z.number().min(1).max(5).nullable(),
  expansionType: expType.nullable(),
  typicalTimeManual: optInt(1, 10000),
  timePerPlayerManual: z.number().int().min(-600).max(600).nullable(),
  timeBasePlayersManual: optInt(1, 100),
  timeNote: optStr(1000),
  ownershipStatus: ownership,
  ownerId: z.number().int().nullable(),
  locationType: location,
  locationPerson: optStr(200),
  locationCustom: optStr(200),
  loanDate: optDate,
  loanDueDate: optDate,
  favorite: z.boolean(),
  notes: optStr(20000),
  acquiredAt: optDate,
  pricePaid: z.number().min(0).max(1e7).nullable(),
  lastVerifiedAt: optDate,
  kind: z.enum(['base', 'expansion']),
}).partial().strict();

export type GamePatch = z.infer<typeof gamePatchSchema>;

export const gameCreateSchema = gamePatchSchema.extend({
  nameEn: z.string().trim().min(1).max(300),
  baseGameId: z.number().int().nullable().optional(),
  tagIds: z.array(z.number().int()).optional(),
  allowDuplicate: z.boolean().optional(),
}).strict();

const apiToCol: Record<string, string> = Object.fromEntries(
  [...Object.entries(BGG_FIELDS), ...Object.entries(PERSONAL_FIELDS)].map(([col, api]) => [api, col]),
);

function checkPlayers(db: DB, id: number | null, p: GamePatch) {
  const cur = id ? (db.prepare('SELECT min_players, max_players, min_playtime, max_playtime FROM games WHERE id = ?').get(id) as any) : {};
  const min = p.minPlayers !== undefined ? p.minPlayers : cur?.min_players;
  const max = p.maxPlayers !== undefined ? p.maxPlayers : cur?.max_players;
  if (min != null && max != null && min > max) throw new HttpError(400, 'O mínimo de jogadores não pode ser maior que o máximo.');
  const tmin = p.minPlaytime !== undefined ? p.minPlaytime : cur?.min_playtime;
  const tmax = p.maxPlaytime !== undefined ? p.maxPlaytime : cur?.max_playtime;
  if (tmin != null && tmax != null && tmin > tmax) throw new HttpError(400, 'O tempo mínimo não pode ser maior que o máximo.');
}

function checkOwner(db: DB, ownerId: number | null | undefined) {
  if (ownerId == null) return;
  if (!db.prepare('SELECT 1 FROM owners WHERE id = ?').get(ownerId)) throw new HttpError(400, 'Proprietário inexistente.');
}

/** Registra empréstimos no histórico quando a localização muda. */
function trackLoans(db: DB, id: number, before: any, after: any) {
  const loanTypes = ['lent_out', 'borrowed'];
  const changed = before.location_type !== after.location_type || before.location_person !== after.location_person;
  if (!changed) {
    if (loanTypes.includes(after.location_type)) {
      db.prepare(`UPDATE loans SET start_date = ?, due_date = ? WHERE game_id = ? AND returned_at IS NULL`).run(after.loan_date, after.loan_due_date, id);
    }
    return;
  }
  if (loanTypes.includes(before.location_type)) {
    db.prepare(`UPDATE loans SET returned_at = date('now') WHERE game_id = ? AND returned_at IS NULL`).run(id);
  }
  if (loanTypes.includes(after.location_type)) {
    db.prepare(`INSERT INTO loans (game_id, direction, person, start_date, due_date) VALUES (?, ?, ?, ?, ?)`)
      .run(id, after.location_type, after.location_person, after.loan_date ?? new Date().toISOString().slice(0, 10), after.loan_due_date);
  }
}

export function patchGame(db: DB, id: number, raw: unknown): void {
  const p = gamePatchSchema.parse(raw);
  const before = db.prepare('SELECT * FROM games WHERE id = ?').get(id) as any;
  if (!before) throw new HttpError(404, 'Jogo não encontrado.');
  checkPlayers(db, id, p);
  checkOwner(db, p.ownerId);
  const manual = new Set<string>(JSON.parse(before.manual_fields || '[]'));
  const sets: string[] = [];
  const params: unknown[] = [];
  for (const [key, v] of Object.entries(p)) {
    const col = apiToCol[key];
    if (!col) continue;
    const value = typeof v === 'boolean' ? (v ? 1 : 0) : v;
    if (before[col] === value) continue;
    sets.push(`${col} = ?`);
    params.push(value);
    if (col in BGG_FIELDS) manual.add(col);
    if (col === 'expansion_type') sets.push(`expansion_type_source = 'manual'`);
    if (col === 'name_pt') sets.push(`name_pt_source = ${value == null ? 'NULL' : `'manual'`}`);
    if (col === 'image_url') sets.push('image_local = NULL');
    if (col === 'thumbnail_url') sets.push('thumb_local = NULL');
  }
  // Ao marcar uma expansão como possuída sem proprietário, herda o proprietário do jogo-base (ou "Meus jogos")
  if (p.ownershipStatus === 'owned' && before.owner_id == null && p.ownerId === undefined) {
    const baseOwner = db.prepare(`SELECT b.owner_id FROM game_relations r JOIN games b ON b.id = r.related_id
      WHERE r.game_id = ? AND r.relation = 'expansion_of' AND r.status = 'active' AND b.owner_id IS NOT NULL LIMIT 1`).get(id) as any;
    const me = db.prepare('SELECT id FROM owners WHERE is_me = 1').get() as any;
    sets.push('owner_id = ?');
    params.push(baseOwner?.owner_id ?? me?.id ?? null);
  }
  if (!sets.length) return;
  sets.push(`manual_fields = ?`, `updated_at = datetime('now')`);
  params.push(JSON.stringify([...manual]));
  db.transaction(() => {
    db.prepare(`UPDATE games SET ${sets.join(', ')} WHERE id = ?`).run(...params, id);
    const after = db.prepare('SELECT * FROM games WHERE id = ?').get(id) as any;
    trackLoans(db, id, before, after);
    for (const [key] of Object.entries(p)) {
      const col = apiToCol[key];
      if (col && col in BGG_FIELDS) {
        db.prepare(`INSERT INTO field_sources (game_id, field, source, status, note, updated_at) VALUES (?, ?, 'manual', 'verified', 'Editado manualmente', datetime('now'))
          ON CONFLICT(game_id, field) DO UPDATE SET source = 'manual', status = 'verified', note = 'Editado manualmente', updated_at = datetime('now')`).run(id, col);
      }
    }
    if (p.timePerPlayerManual !== undefined) {
      db.prepare(`INSERT INTO field_sources (game_id, field, source, status, note, updated_at) VALUES (?, 'time_per_player', ?, ?, ?, datetime('now'))
        ON CONFLICT(game_id, field) DO UPDATE SET source = excluded.source, status = excluded.status, note = excluded.note, updated_at = excluded.updated_at`)
        .run(id, p.timePerPlayerManual != null ? 'manual' : 'calculated', p.timePerPlayerManual != null ? 'verified' : 'unavailable',
          p.timePerPlayerManual != null ? 'Estimativa informada por você' : 'Não disponível: o BGG não publica tempo por jogador');
    }
    if (['typicalTimeManual', 'playingTime', 'minPlaytime', 'maxPlaytime'].some((k) => k in p)) refreshDurationTag(db, id);
  })();
}

export function createManualGame(db: DB, raw: unknown): number {
  const p = gameCreateSchema.parse(raw);
  checkPlayers(db, null, p);
  checkOwner(db, p.ownerId);
  const me0 = db.prepare('SELECT id FROM owners WHERE is_me = 1').get() as { id: number };
  const ownerForDup = p.ownerId === undefined ? me0.id : p.ownerId;
  // mesmo nome do mesmo proprietário = provável duplicata (cópias de proprietários diferentes são permitidas)
  const dup = db.prepare(`SELECT id, name_en FROM games WHERE lower(name_en) = lower(?) AND (year IS ? OR ? IS NULL) AND owner_id IS ?`).get(p.nameEn, p.year ?? null, p.year ?? null, ownerForDup) as any;
  if (dup && !p.allowDuplicate) {
    throw new HttpError(409, `Já existe "${dup.name_en}" na coleção.`, { duplicateId: dup.id });
  }
  const me = db.prepare('SELECT id FROM owners WHERE is_me = 1').get() as { id: number };
  const kind = p.kind ?? (p.baseGameId ? 'expansion' : 'base');
  const id = db.transaction(() => {
    const info = db.prepare(`INSERT INTO games (name_en, kind, ownership_status, owner_id, location_type, data_status) VALUES (?, ?, ?, ?, ?, 'manual')`)
      .run(p.nameEn, kind, p.ownershipStatus ?? 'owned', p.ownerId === undefined ? me.id : p.ownerId, p.locationType ?? 'with_me');
    const gid = Number(info.lastInsertRowid);
    const { nameEn: _n, baseGameId, tagIds, allowDuplicate: _a, ...rest } = p;
    patchGame(db, gid, rest);
    for (const f of ['name_en', 'min_players', 'max_players', 'playing_time', 'weight']) {
      const has = db.prepare(`SELECT ${f} v FROM games WHERE id = ?`).get(gid) as any;
      db.prepare(`INSERT OR REPLACE INTO field_sources (game_id, field, source, status, note) VALUES (?, ?, 'manual', ?, ?)`)
        .run(gid, f, has.v == null ? 'unavailable' : 'verified', has.v == null ? 'Não informado' : 'Cadastrado manualmente');
    }
    if (baseGameId) addRelation(db, gid, baseGameId);
    for (const t of tagIds ?? []) addManualTag(db, gid, { tagId: t });
    refreshDurationTag(db, gid);
    return gid;
  })();
  return id;
}

export function deleteGame(db: DB, id: number): { deletedExpansionStubs: number } {
  const g = db.prepare('SELECT id FROM games WHERE id = ?').get(id);
  if (!g) throw new HttpError(404, 'Jogo não encontrado.');
  return db.transaction(() => {
    // Expansões não possuídas, sem dados pessoais e sem outro jogo-base, são removidas junto
    const stubs = db.prepare(`SELECT g.id FROM game_relations r JOIN games g ON g.id = r.game_id
      WHERE r.related_id = ? AND r.relation = 'expansion_of'
        AND g.ownership_status IN ('unverified','not_owned') AND g.notes IS NULL AND g.favorite = 0
        AND NOT EXISTS (SELECT 1 FROM game_relations r2 WHERE r2.game_id = g.id AND r2.related_id IS NOT NULL AND r2.related_id <> ? AND r2.relation = 'expansion_of')`).all(id, id) as any[];
    for (const s of stubs) db.prepare('DELETE FROM games WHERE id = ?').run(s.id);
    // relações das expansões restantes ficam com o nome/ID do BGG, mas sem o vínculo local
    db.prepare('UPDATE game_relations SET related_id = NULL WHERE related_id = ?').run(id);
    db.prepare('DELETE FROM games WHERE id = ?').run(id);
    return { deletedExpansionStubs: stubs.length };
  })();
}

export function addManualTag(db: DB, gameId: number, input: { tagId?: number; name?: string }) {
  const tid = input.tagId ?? (input.name ? tagIdByName(db, input.name.trim(), 'custom') : null);
  if (!tid) throw new HttpError(400, 'Informe a etiqueta.');
  if (!db.prepare('SELECT 1 FROM tags WHERE id = ?').get(tid)) throw new HttpError(400, 'Etiqueta inexistente.');
  db.prepare(`INSERT INTO game_tags (game_id, tag_id, source, detail, status) VALUES (?, ?, 'manual', 'Adicionada por você', 'active')
    ON CONFLICT(game_id, tag_id) DO UPDATE SET source = 'manual', detail = 'Adicionada por você', status = 'active'`).run(gameId, tid);
  return tid;
}

/** Remove etiqueta: manual some; derivada/inferida fica "rejeitada" para não voltar na próxima atualização. */
export function removeTag(db: DB, gameId: number, tagId: number) {
  const cur = db.prepare('SELECT source FROM game_tags WHERE game_id = ? AND tag_id = ?').get(gameId, tagId) as any;
  if (!cur) return;
  if (cur.source === 'manual') db.prepare('DELETE FROM game_tags WHERE game_id = ? AND tag_id = ?').run(gameId, tagId);
  else db.prepare(`UPDATE game_tags SET status = 'rejected' WHERE game_id = ? AND tag_id = ?`).run(gameId, tagId);
}

export function restoreTag(db: DB, gameId: number, tagId: number) {
  db.prepare(`UPDATE game_tags SET status = 'active' WHERE game_id = ? AND tag_id = ?`).run(gameId, tagId);
}

export function addRelation(db: DB, gameId: number, baseGameId: number) {
  if (gameId === baseGameId) throw new HttpError(400, 'Um jogo não pode ser expansão de si mesmo.');
  const base = db.prepare('SELECT id, bgg_id, name_en FROM games WHERE id = ?').get(baseGameId) as any;
  if (!base) throw new HttpError(404, 'Jogo-base não encontrado.');
  const existing = db.prepare(`SELECT id FROM game_relations WHERE game_id = ? AND relation = 'expansion_of' AND (related_id = ? OR (related_bgg_id IS NOT NULL AND related_bgg_id = ?))`).get(gameId, base.id, base.bgg_id) as any;
  if (existing) {
    db.prepare(`UPDATE game_relations SET status = 'active', related_id = ? WHERE id = ?`).run(base.id, existing.id);
  } else {
    db.prepare(`INSERT INTO game_relations (game_id, related_id, related_bgg_id, related_name, relation, source) VALUES (?, ?, ?, ?, 'expansion_of', 'manual')`)
      .run(gameId, base.id, base.bgg_id, base.name_en);
  }
  db.prepare(`UPDATE games SET kind = 'expansion' WHERE id = ? AND COALESCE(bgg_type, '') <> 'boardgame'`).run(gameId);
}

/** Desfaz uma associação. Associações vindas do BGG ficam marcadas como rejeitadas para não voltarem. */
export function removeRelation(db: DB, relationId: number) {
  const r = db.prepare('SELECT * FROM game_relations WHERE id = ?').get(relationId) as any;
  if (!r) throw new HttpError(404, 'Associação não encontrada.');
  if (r.source === 'manual') db.prepare('DELETE FROM game_relations WHERE id = ?').run(relationId);
  else db.prepare(`UPDATE game_relations SET status = 'rejected' WHERE id = ?`).run(relationId);
}

/** Volta um campo editado à mão para o valor do BGG (na próxima atualização). */
export function restoreBggField(db: DB, gameId: number, field: string) {
  const col = apiToCol[field] ?? field;
  const g = db.prepare('SELECT manual_fields FROM games WHERE id = ?').get(gameId) as any;
  if (!g) throw new HttpError(404, 'Jogo não encontrado.');
  const manual = new Set<string>(JSON.parse(g.manual_fields || '[]'));
  manual.delete(col);
  if (col === 'expansion_type') db.prepare(`UPDATE games SET expansion_type_source = NULL WHERE id = ?`).run(gameId);
  db.prepare('UPDATE games SET manual_fields = ? WHERE id = ?').run(JSON.stringify([...manual]), gameId);
}

export const ownerSchema = z.object({
  name: z.string().trim().min(1).max(80),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Cor no formato #RRGGBB'),
}).strict();

export const tagSchema = z.object({
  name: z.string().trim().min(1).max(80),
  grp: z.enum(['mechanic', 'style', 'interaction', 'luck', 'duration', 'custom']).default('custom'),
  description: z.string().trim().max(500).nullable().optional(),
}).strict();
