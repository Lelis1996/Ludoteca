/** Pontos de integração com a plataforma (computador ou celular). */

/** Guarda as capas dos jogos localmente para funcionar sem o BGG. */
export interface ImageStore {
  schedule(gameId: number): void;
  idle(): Promise<void>;
}

export const noImageStore: ImageStore = { schedule: () => undefined, idle: async () => undefined };

/** Arquivos e processamento de imagens usados pela importação por fotos. */
export interface MediaStore {
  /** Gira pelo EXIF, limita o tamanho e converte para JPEG. Lança erro se não for imagem. */
  normalizePhoto(data: Uint8Array): Promise<{ data: Uint8Array; width: number; height: number }>;
  resize(data: Uint8Array, maxSide: number, quality?: number): Promise<Uint8Array>;
  crop(data: Uint8Array, rect: { left: number; top: number; width: number; height: number }, maxSide: number): Promise<Uint8Array>;
  save(key: string, data: Uint8Array): Promise<void>;
  load(key: string): Promise<Uint8Array>;
  url(key: string): string;
  removePrefix(prefix: string): Promise<void>;
}
