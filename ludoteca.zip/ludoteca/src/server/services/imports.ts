import type { DB } from '../dbtypes';
import type { VisionProvider, DetectedBox } from '../vision/core';
import type { MediaStore } from './ports';
import type { BggService } from './bggService';
import { similarity } from './bggService';
import { BggError } from '../bgg/client';
import { createManualGame, HttpError, patchGame } from './mutations';
import type { BggSearchResult } from '../../shared/types';

export interface CandidateMatch extends BggSearchResult {
  source: 'bgg' | 'local';
}

export interface ImportCandidate {
  id: number;
  photoId: number;
  detectedTitle: string;
  detectedText: string | null;
  bbox: [number, number, number, number] | null;
  crop: string | null;
  expansionGuess: boolean;
  baseGuess: string | null;
  visionConfidence: number | null;
  confidence: number | null;
  matches: CandidateMatch[];
  warnings: string[];
  selectedBggId: number | null;
  status: 'pending' | 'confirmed' | 'ignored' | 'added' | 'error';
  gameId: number | null;
  linkGameId: number | null;
  error: string | null;
}

export interface ImportPhoto {
  id: number;
  filename: string;
  url: string;
  thumb: string | null;
  status: string;
  provider: string | null;
  error: string | null;
  candidates: ImportCandidate[];
}

export interface ImportBatch {
  id: number;
  status: 'processing' | 'review' | 'done' | 'error';
  source: 'photos' | 'list';
  provider: string | null;
  ownerId: number | null;
  locationType: string;
  locationPerson: string | null;
  ownershipStatus: string;
  createdAt: string;
  finishedAt: string | null;
  photos: ImportPhoto[];
}

const parse = <T>(s: string | null, d: T): T => { try { return s ? JSON.parse(s) : d; } catch { return d; } };

export class ImportService {
  private running = new Map<number, Promise<void>>();

  constructor(private db: DB, private media: MediaStore, private bgg: BggService, private getProvider: () => VisionProvider | null) {}

  /** Aguarda o processamento de um lote (usado em testes). */
  wait(batchId: number) { return this.running.get(batchId) ?? Promise.resolve(); }

  async createBatch(files: { originalname: string; buffer: Uint8Array }[], defaults: { ownerId?: number | null; locationType?: string; locationPerson?: string | null; ownershipStatus?: string }): Promise<number> {
    if (!files.length) throw new HttpError(400, 'Envie pelo menos uma foto.');
    const provider = this.getProvider();
    const me = this.db.prepare('SELECT id FROM owners WHERE is_me = 1').get() as { id: number };
    const batchId = Number(this.db.prepare(`INSERT INTO import_batches (provider, owner_id, location_type, location_person, ownership_status) VALUES (?, ?, ?, ?, ?)`)
      .run(provider?.name ?? 'none', defaults.ownerId ?? me.id, defaults.locationType ?? 'with_me', defaults.locationPerson ?? null, defaults.ownershipStatus ?? 'owned').lastInsertRowid);
    for (const [i, f] of files.entries()) {
      let full: { data: Uint8Array; width: number; height: number };
      try {
        full = await this.media.normalizePhoto(f.buffer);
      } catch {
        this.deleteBatch(batchId);
        throw new HttpError(400, `"${f.originalname}" não é uma imagem válida.`);
      }
      const name = `${batchId}/${i + 1}-${Date.now()}.jpg`;
      const view = `${batchId}/view-${i + 1}-${Date.now()}.jpg`;
      await this.media.save(name, full.data);
      await this.media.save(view, await this.media.resize(full.data, 1000, 78));
      this.db.prepare(`INSERT INTO import_photos (batch_id, filename, path, thumb_path, width, height, provider) VALUES (?, ?, ?, ?, ?, ?, ?)`)
        .run(batchId, f.originalname, name, view, full.width, full.height, provider?.name ?? 'none');
    }
    const run = this.process(batchId).finally(() => this.running.delete(batchId));
    this.running.set(batchId, run);
    return batchId;
  }

  /**
   * Cria uma revisão em lote para vincular ao BGG jogos cadastrados manualmente
   * (ex.: a coleção inicial). Nada é alterado antes da confirmação.
   */
  createListBatch(gameIds?: number[]): number {
    if (!this.bgg.client.configured) throw new HttpError(503, 'Configure o token do BGG antes de vincular os jogos.');
    const rows = (this.db.prepare(`SELECT id, name_en, kind FROM games WHERE bgg_id IS NULL ORDER BY kind, name_en`).all() as any[])
      .filter((g) => !gameIds?.length || gameIds.includes(g.id));
    if (!rows.length) throw new HttpError(400, 'Não há jogos sem vínculo com o BGG.');
    return this.db.transaction(() => {
      const batchId = Number(this.db.prepare(`INSERT INTO import_batches (provider, source, ownership_status) VALUES ('bgg', 'list', 'owned')`).run().lastInsertRowid);
      const photoId = Number(this.db.prepare(`INSERT INTO import_photos (batch_id, filename, path, status, provider) VALUES (?, 'Jogos sem vínculo com o BGG', '', 'matching', 'bgg')`).run(batchId).lastInsertRowid);
      for (const g of rows) {
        this.db.prepare(`INSERT INTO import_candidates (photo_id, detected_title, detected_text, expansion_guess, vision_confidence, warnings_json, link_game_id)
          VALUES (?, ?, 'Jogo já cadastrado', ?, 1, '[]', ?)`).run(photoId, g.name_en, g.kind === 'expansion' ? 1 : 0, g.id);
      }
      const run = this.processList(batchId, photoId).finally(() => this.running.delete(batchId));
      this.running.set(batchId, run);
      return batchId;
    })();
  }

  private async processList(batchId: number, photoId: number) {
    const cands = this.db.prepare('SELECT * FROM import_candidates WHERE photo_id = ? ORDER BY id').all(photoId) as any[];
    for (const c of cands) {
      try {
        await this.match(c.id, { title: c.detected_title, isExpansion: !!c.expansion_guess, confidence: 1 });
      } catch (e) {
        this.db.prepare(`UPDATE import_candidates SET error = ? WHERE id = ?`).run((e as Error).message, c.id);
      }
    }
    this.db.prepare(`UPDATE import_photos SET status = 'done' WHERE id = ?`).run(photoId);
    this.db.prepare(`UPDATE import_batches SET status = 'review' WHERE id = ? AND status = 'processing'`).run(batchId);
  }

  private async process(batchId: number) {
    const provider = this.getProvider();
    const photos = this.db.prepare('SELECT * FROM import_photos WHERE batch_id = ? ORDER BY id').all(batchId) as any[];
    for (const p of photos) {
      try {
        if (!provider) {
          this.db.prepare(`UPDATE import_photos SET status = 'done', error = ? WHERE id = ?`).run(
            'Nenhum reconhecimento de imagem disponível. Adicione os jogos desta foto manualmente na revisão.', p.id);
          continue;
        }
        this.db.prepare(`UPDATE import_photos SET status = 'analyzing' WHERE id = ?`).run(p.id);
        const buf = await this.media.load(p.path);
        const { boxes, raw } = await provider.analyze(buf);
        this.db.prepare(`UPDATE import_photos SET status = 'matching', raw_result = ? WHERE id = ?`).run(JSON.stringify(raw).slice(0, 200000), p.id);
        for (const [i, b] of boxes.entries()) {
          const crop = b.bbox ? await this.crop(p, b.bbox, i) : null;
          const cid = Number(this.db.prepare(`INSERT INTO import_candidates (photo_id, detected_title, detected_text, bbox_json, crop_path, expansion_guess, base_guess, vision_confidence, warnings_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(p.id, b.title, [b.text, b.publisher, b.edition, b.notes].filter(Boolean).join(' · ') || null,
            b.bbox ? JSON.stringify(b.bbox) : null, crop, b.isExpansion ? 1 : 0, b.baseGame ?? null, b.confidence, '[]').lastInsertRowid);
          await this.match(cid, b, provider.name === 'ocr');
        }
        this.db.prepare(`UPDATE import_photos SET status = 'done' WHERE id = ?`).run(p.id);
      } catch (e) {
        this.db.prepare(`UPDATE import_photos SET status = 'error', error = ? WHERE id = ?`).run((e as Error).message, p.id);
      }
    }
    this.flagDuplicatesInBatch(batchId);
    this.db.prepare(`UPDATE import_batches SET status = 'review' WHERE id = ? AND status = 'processing'`).run(batchId);
  }

  private async crop(photo: any, bbox: [number, number, number, number], i: number): Promise<string | null> {
    try {
      const [x, y, w, h] = bbox;
      const pad = 0.02;
      const left = Math.max(0, Math.floor((x - pad) * photo.width));
      const top = Math.max(0, Math.floor((y - pad) * photo.height));
      const width = Math.min(photo.width - left, Math.ceil((w + pad * 2) * photo.width));
      const height = Math.min(photo.height - top, Math.ceil((h + pad * 2) * photo.height));
      if (width < 8 || height < 8) return null;
      const key = `${photo.batch_id}/crop-${photo.id}-${i}.jpg`;
      await this.media.save(key, await this.media.crop(await this.media.load(photo.path), { left, top, width, height }, 360));
      return key;
    } catch {
      return null;
    }
  }

  /** Procura correspondências e calcula a confiança. Nunca escolhe sozinho quando há ambiguidade. */
  async match(candidateId: number, b: Pick<DetectedBox, 'title' | 'isExpansion' | 'baseGame' | 'confidence'>, fromOcr = false, query?: string) {
    const warnings: string[] = [];
    let matches: CandidateMatch[] = [];
    const linkGameId = (this.db.prepare('SELECT link_game_id FROM import_candidates WHERE id = ?').get(candidateId) as any)?.link_game_id ?? null;
    const q = (query ?? b.title).trim();
    let bggFailed = false;
    if (this.bgg.client.configured || query) {
      try {
        const res = await this.bgg.search(q, { enrich: 6 });
        matches = res.slice(0, 8).map((r) => ({ ...r, source: 'bgg' as const }));
      } catch (e) {
        bggFailed = true;
        warnings.push(e instanceof BggError && e.code === 'not_configured'
          ? 'BGG não configurado: mostrando apenas jogos já cadastrados. Você pode confirmar como cadastro manual.'
          : `Falha ao consultar o BGG: ${(e as Error).message}`);
      }
    } else {
      bggFailed = true;
      warnings.push('BGG não configurado: mostrando apenas jogos já cadastrados. Você pode confirmar como cadastro manual.');
    }
    if (bggFailed) {
      const local = (this.db.prepare('SELECT id, bgg_id, name_en, name_pt, year, kind, thumbnail_url, thumb_local FROM games').all() as any[]).filter((g) => g.id !== linkGameId);
      matches = local
        .map((g) => ({ g, sim: Math.max(similarity(q, g.name_en), g.name_pt ? similarity(q, g.name_pt) : 0) }))
        .filter((x) => x.sim >= 0.5)
        .sort((a, b2) => b2.sim - a.sim)
        .slice(0, 5)
        .map(({ g, sim }) => ({
          source: 'local' as const, bggId: g.bgg_id ?? 0, name: g.name_en, nameType: 'primary' as const, year: g.year,
          type: g.kind === 'expansion' ? 'boardgameexpansion' as const : 'boardgame' as const,
          inCollectionGameId: g.id, thumb: g.thumb_local ? (g.thumb_local.startsWith('data:') ? g.thumb_local : `/images/${g.thumb_local}`) : g.thumbnail_url, similarity: Math.round(sim * 100) / 100,
        }));
    }

    const top = matches[0];
    const second = matches[1];
    let selected: number | null = null;
    let confidence = 0;
    if (top) {
      confidence = Math.round((top.similarity ?? 0) * (b.confidence ?? 0.5) * 100) / 100;
      const ambiguous = !!second && (top.similarity ?? 0) - (second.similarity ?? 0) < 0.08 && (second.similarity ?? 0) >= 0.7;
      if (ambiguous) {
        warnings.push(`Mais de um item do BGG com nome parecido (${matches.slice(0, 3).map((m) => `${m.primaryName ?? m.name}${m.year ? ` (${m.year})` : ''}`).join(', ')}). Escolha a edição/versão correta.`);
        confidence = Math.min(confidence, 0.5);
      }
      if ((top.similarity ?? 0) >= 0.8 && !ambiguous && top.source === 'bgg') selected = top.bggId;
      if (top.source === 'local' && (top.similarity ?? 0) >= 0.9) warnings.push('Parece ser um jogo já cadastrado.');
      if (top.type === 'boardgameexpansion' && !b.isExpansion) warnings.push(`O BGG classifica "${top.primaryName ?? top.name}" como expansão${top.isExpansionOf?.length ? ` de ${top.isExpansionOf.map((x) => x.name).join(', ')}` : ''}.`);
      if (top.type === 'boardgame' && b.isExpansion) warnings.push('A caixa parece uma expansão, mas o item sugerido é um jogo-base. Confira.');
      if (top.standaloneExpansion) warnings.push('Este item é um jogo independente que o BGG também lista como expansão — confirme como deseja registrá-lo.');
      if (top.inCollectionGameId && top.inCollectionGameId !== linkGameId && !linkGameId) {
        const g = this.db.prepare('SELECT ownership_status FROM games WHERE id = ?').get(top.inCollectionGameId) as any;
        warnings.push(g?.ownership_status === 'owned'
          ? 'Possível duplicata: este jogo já está na coleção. Ao confirmar, ele não será adicionado de novo.'
          : 'Já cadastrado como "não possuído/não verificado": confirmar marca como possuído.');
      }
    } else if (!bggFailed) {
      warnings.push('Nenhum resultado no BGG para este título. Edite o título e busque novamente, ou ignore.');
    }
    if (fromOcr) warnings.push('Título lido por OCR: confira com atenção.');

    // OCR sem nenhuma correspondência costuma ser ruído (editora, slogan...): já entra como ignorado
    const status = fromOcr && !matches.length ? 'ignored' : undefined;
    this.db.prepare(`UPDATE import_candidates SET matches_json = ?, warnings_json = ?, selected_bgg_id = ?, confidence = ?${status ? `, status = '${status}'` : ''} WHERE id = ?`)
      .run(JSON.stringify(matches), JSON.stringify(warnings), selected, confidence, candidateId);
  }

  private flagDuplicatesInBatch(batchId: number) {
    const rows = this.db.prepare(`SELECT c.id, c.selected_bgg_id, c.warnings_json FROM import_candidates c JOIN import_photos p ON p.id = c.photo_id
      WHERE p.batch_id = ? AND c.selected_bgg_id IS NOT NULL AND c.status <> 'ignored' ORDER BY c.id`).all(batchId) as any[];
    const seen = new Map<number, number>();
    for (const r of rows) {
      if (seen.has(r.selected_bgg_id)) {
        const w = parse<string[]>(r.warnings_json, []);
        w.push('O mesmo jogo foi detectado em outra foto deste lote — confirme apenas uma vez, se for a mesma caixa.');
        this.db.prepare('UPDATE import_candidates SET warnings_json = ? WHERE id = ?').run(JSON.stringify(w), r.id);
      } else seen.set(r.selected_bgg_id, r.id);
    }
  }

  get(batchId: number): ImportBatch | null {
    const b = this.db.prepare('SELECT * FROM import_batches WHERE id = ?').get(batchId) as any;
    if (!b) return null;
    const photos = this.db.prepare('SELECT * FROM import_photos WHERE batch_id = ? ORDER BY id').all(batchId) as any[];
    const cands = this.db.prepare(`SELECT c.* FROM import_candidates c JOIN import_photos p ON p.id = c.photo_id WHERE p.batch_id = ? ORDER BY c.id`).all(batchId) as any[];
    return {
      id: b.id, status: b.status, source: b.source ?? 'photos', provider: b.provider, ownerId: b.owner_id, locationType: b.location_type, locationPerson: b.location_person,
      ownershipStatus: b.ownership_status, createdAt: b.created_at, finishedAt: b.finished_at,
      photos: photos.map((p) => ({
        id: p.id, filename: p.filename, url: p.thumb_path ? this.media.url(p.thumb_path) : '', thumb: p.thumb_path ? this.media.url(p.thumb_path) : null,
        status: p.status, provider: p.provider, error: p.error,
        candidates: cands.filter((c) => c.photo_id === p.id).map((c) => this.toCandidate(c)),
      })),
    };
  }

  private toCandidate(c: any): ImportCandidate {
    return {
      id: c.id, photoId: c.photo_id, detectedTitle: c.detected_title, detectedText: c.detected_text,
      bbox: parse(c.bbox_json, null), crop: c.crop_path ? this.media.url(c.crop_path) : null, linkGameId: c.link_game_id ?? null,
      expansionGuess: !!c.expansion_guess, baseGuess: c.base_guess, visionConfidence: c.vision_confidence,
      confidence: c.confidence, matches: parse(c.matches_json, []), warnings: parse(c.warnings_json, []),
      selectedBggId: c.selected_bgg_id, status: c.status, gameId: c.game_id, error: c.error,
    };
  }

  list() {
    return this.db.prepare(`SELECT b.id, b.status, b.provider, b.created_at createdAt, b.finished_at finishedAt,
      (SELECT COUNT(*) FROM import_photos p WHERE p.batch_id = b.id) photos,
      (SELECT COUNT(*) FROM import_candidates c JOIN import_photos p ON p.id = c.photo_id WHERE p.batch_id = b.id) candidates,
      (SELECT COUNT(*) FROM import_candidates c JOIN import_photos p ON p.id = c.photo_id WHERE p.batch_id = b.id AND c.status = 'added') added
      FROM import_batches b ORDER BY b.id DESC`).all();
  }

  updateCandidate(id: number, patch: { status?: string; selectedBggId?: number | null; detectedTitle?: string }) {
    const c = this.db.prepare('SELECT * FROM import_candidates WHERE id = ?').get(id) as any;
    if (!c) throw new HttpError(404, 'Item da importação não encontrado.');
    if (c.status === 'added') throw new HttpError(409, 'Este item já foi adicionado à coleção.');
    if (patch.status && !['pending', 'confirmed', 'ignored'].includes(patch.status)) throw new HttpError(400, 'Status inválido.');
    this.db.prepare(`UPDATE import_candidates SET status = COALESCE(?, status), selected_bgg_id = CASE WHEN ? THEN ? ELSE selected_bgg_id END,
      detected_title = COALESCE(?, detected_title) WHERE id = ?`)
      .run(patch.status ?? null, patch.selectedBggId !== undefined ? 1 : 0, patch.selectedBggId ?? null, patch.detectedTitle?.trim() || null, id);
  }

  async research(id: number, query: string) {
    const c = this.db.prepare('SELECT * FROM import_candidates WHERE id = ?').get(id) as any;
    if (!c) throw new HttpError(404, 'Item da importação não encontrado.');
    if (!query.trim()) throw new HttpError(400, 'Informe um título para buscar.');
    this.db.prepare(`UPDATE import_candidates SET detected_title = ?, status = CASE WHEN status = 'ignored' THEN 'pending' ELSE status END WHERE id = ?`).run(query.trim(), id);
    await this.match(id, { title: query, isExpansion: !!c.expansion_guess, baseGame: c.base_guess, confidence: 1 }, false, query);
  }

  /** Adiciona manualmente um item a uma foto (quando o reconhecimento não encontrou a caixa). */
  async addManualCandidate(photoId: number, title: string) {
    const p = this.db.prepare('SELECT id FROM import_photos WHERE id = ?').get(photoId);
    if (!p) throw new HttpError(404, 'Foto não encontrada.');
    const cid = Number(this.db.prepare(`INSERT INTO import_candidates (photo_id, detected_title, detected_text, vision_confidence, warnings_json) VALUES (?, ?, 'Informado manualmente', 1, '[]')`).run(photoId, title.trim()).lastInsertRowid);
    await this.match(cid, { title, confidence: 1 }, false, title);
    return cid;
  }

  /** Grava na coleção os itens confirmados. */
  async commit(batchId: number, overrides: { ownerId?: number | null; locationType?: string; locationPerson?: string | null; ownershipStatus?: string } = {}) {
    const b = this.db.prepare('SELECT * FROM import_batches WHERE id = ?').get(batchId) as any;
    if (!b) throw new HttpError(404, 'Importação não encontrada.');
    if (b.status === 'processing') throw new HttpError(409, 'A análise das fotos ainda não terminou.');
    const ownerId = overrides.ownerId !== undefined ? overrides.ownerId : b.owner_id;
    const locationType = overrides.locationType ?? b.location_type;
    const locationPerson = overrides.locationPerson !== undefined ? overrides.locationPerson : b.location_person;
    const ownershipStatus = overrides.ownershipStatus ?? b.ownership_status;
    this.db.prepare('UPDATE import_batches SET owner_id = ?, location_type = ?, location_person = ?, ownership_status = ? WHERE id = ?')
      .run(ownerId, locationType, locationPerson, ownershipStatus, batchId);
    const cands = this.db.prepare(`SELECT c.* FROM import_candidates c JOIN import_photos p ON p.id = c.photo_id
      WHERE p.batch_id = ? AND c.status = 'confirmed' ORDER BY c.id`).all(batchId) as any[];
    const result = { added: 0, updated: 0, duplicates: 0, errors: [] as string[] };
    const done = new Set<number>();
    for (const c of cands) {
      try {
        let gameId: number;
        const personal = { ownershipStatus, ownerId, locationType, locationPerson };
        if (c.link_game_id) {
          // vínculo em lote: o jogo já existe; só liga ao BGG, mantendo os dados pessoais
          if (!c.selected_bgg_id) { this.setAdded(c.id, c.link_game_id, 'Mantido como cadastro manual'); continue; }
          await this.bgg.link(c.link_game_id, c.selected_bgg_id);
          result.updated++;
          this.setAdded(c.id, c.link_game_id, null);
          continue;
        }
        if (c.selected_bgg_id) {
          if (done.has(c.selected_bgg_id)) { result.duplicates++; this.setAdded(c.id, null, 'Mesmo jogo já confirmado neste lote'); continue; }
          done.add(c.selected_bgg_id);
          const rows = this.db.prepare('SELECT id, ownership_status, owner_id FROM games WHERE bgg_id = ? ORDER BY id').all(c.selected_bgg_id) as any[];
          const same = rows.find((x) => x.owner_id === ownerId && x.ownership_status === ownershipStatus);
          if (same) {
            result.duplicates++;
            this.setAdded(c.id, same.id, 'Já estava na coleção — não foi duplicado');
            continue;
          }
          const placeholder = rows.find((x) => ['unverified', 'not_owned', 'reference'].includes(x.ownership_status) || (x.owner_id === ownerId));
          if (placeholder) {
            patchGame(this.db, placeholder.id, personal);
            gameId = placeholder.id;
            result.updated++;
            if (this.bgg.client.configured) await this.bgg.refresh(gameId).catch(() => undefined);
          } else {
            // ninguém tem este jogo, ou só a cópia de outro proprietário: cria uma nova
            gameId = await this.bgg.addFromBgg(c.selected_bgg_id, {
              defaults: { ownership_status: ownershipStatus, owner_id: ownerId, location_type: locationType, location_person: locationPerson },
              createNew: rows.length > 0,
            });
            result.added++;
          }
        } else {
          const local = this.db.prepare('SELECT id FROM games WHERE lower(name_en) = lower(?) AND owner_id IS ?').get(c.detected_title, ownerId) as any;
          if (local) { result.duplicates++; this.setAdded(c.id, local.id, 'Já estava na coleção — não foi duplicado'); continue; }
          gameId = createManualGame(this.db, { nameEn: c.detected_title, ...personal, kind: c.expansion_guess ? 'expansion' : 'base' });
          result.added++;
        }
        this.setAdded(c.id, gameId, null);
      } catch (e) {
        const msg = (e as Error).message;
        this.db.prepare(`UPDATE import_candidates SET status = 'error', error = ? WHERE id = ?`).run(msg, c.id);
        result.errors.push(`${c.detected_title}: ${msg}`);
      }
    }
    const pending = this.db.prepare(`SELECT COUNT(*) n FROM import_candidates c JOIN import_photos p ON p.id = c.photo_id
      WHERE p.batch_id = ? AND c.status IN ('pending','confirmed','error')`).get(batchId) as { n: number };
    if (pending.n === 0) this.db.prepare(`UPDATE import_batches SET status = 'done', finished_at = datetime('now') WHERE id = ?`).run(batchId);
    return result;
  }

  private setAdded(cid: number, gameId: number | null, note: string | null) {
    this.db.prepare(`UPDATE import_candidates SET status = 'added', game_id = ?, error = ? WHERE id = ?`).run(gameId, note, cid);
  }

  deleteBatch(batchId: number) {
    this.db.prepare('DELETE FROM import_batches WHERE id = ?').run(batchId);
    void this.media.removePrefix(`${batchId}/`);
  }
}
