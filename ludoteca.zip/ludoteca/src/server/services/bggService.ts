import type { DB } from '../dbtypes';
import { BggClient, BggError } from '../bgg/client';
import { relationsOf } from '../bgg/derive';
import type { BggSearchResult } from '../../shared/types';
import { normalizeText } from '../../shared/domain';
import { applyBggThing, markBggError, type ApplyOptions } from './games';
import { HttpError } from './mutations';
import type { ImageStore } from './ports';

export function similarity(a: string, b: string): number {
  const x = normalizeText(a), y = normalizeText(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  // Levenshtein normalizado combinado com sobreposição de palavras
  const m = x.length, n = y.length;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1));
    prev = cur;
  }
  const lev = 1 - prev[n] / Math.max(m, n);
  const tx = new Set(x.split(' ')), ty = new Set(y.split(' '));
  const inter = [...tx].filter((t) => ty.has(t)).length;
  const jac = inter / new Set([...tx, ...ty]).size;
  const contains = y.startsWith(x + ' ') || x.startsWith(y + ' ') ? 0.85 : 0;
  return Math.max(lev, jac, contains * Math.min(1, Math.min(m, n) / Math.max(m, n) + 0.4));
}

export class BggService {
  constructor(private db: DB, public client: BggClient, private images: ImageStore) {}

  /** Pesquisa no BGG e enriquece os melhores resultados com miniatura, tipo e relação de expansão. */
  async search(query: string, opts: { enrich?: number } = {}): Promise<BggSearchResult[]> {
    const items = await this.client.search(query);
    const ranked = items
      .map((i) => ({ i, sim: similarity(query, i.name) }))
      .sort((a, b) => b.sim - a.sim || (b.i.nameType === 'primary' ? 1 : 0) - (a.i.nameType === 'primary' ? 1 : 0))
      .slice(0, 30);
    const enrichN = opts.enrich ?? 8;
    const topIds = ranked.slice(0, enrichN).map((r) => r.i.id);
    let details = new Map<number, import('../bgg/parse').BggThing>();
    if (topIds.length) {
      try { details = await this.client.things(topIds); } catch { /* segue sem enriquecer */ }
    }
    const inColl = this.db.prepare('SELECT id FROM games WHERE bgg_id = ?');
    const results = ranked.map(({ i, sim }) => {
      const d = details.get(i.id);
      const rel = d ? relationsOf(d) : null;
      return {
        bggId: i.id,
        name: i.name,
        nameType: i.nameType,
        year: i.year,
        type: (d?.type ?? i.type) as BggSearchResult['type'],
        inCollectionGameId: (inColl.get(i.id) as { id: number } | undefined)?.id ?? null,
        thumb: d?.thumbnail ?? null,
        usersRated: d?.stats?.usersRated ?? null,
        primaryName: d?.primaryName ?? null,
        isExpansionOf: rel ? rel.bases.map((b) => ({ bggId: b.id, name: b.value })) : undefined,
        standaloneExpansion: rel?.standaloneExpansion ?? false,
        similarity: Math.round(sim * 100) / 100,
      } satisfies BggSearchResult;
    });
    // Entre resultados igualmente parecidos, prioriza o mais conhecido (mais avaliações)
    results.sort((a, b) => (b.similarity! - a.similarity!) || ((b.usersRated ?? -1) - (a.usersRated ?? -1)));
    return results;
  }

  /**
   * Adiciona (ou atualiza) um item do BGG na coleção.
   * Se for expansão, também cadastra o(s) jogo(s)-base como "Só consulta" quando ainda não existem.
   */
  async addFromBgg(bggId: number, opts: ApplyOptions & { withExpansions?: boolean } = {}): Promise<number> {
    const t = await this.client.thing(bggId, { versions: true });
    if (!t) throw new BggError(`O BGG não retornou o item ${bggId}.`, 'bad_response');
    const id = applyBggThing(this.db, t, opts);
    this.images.schedule(id);
    const rel = relationsOf(t);
    if (t.type === 'boardgameexpansion' || rel.standaloneExpansion) {
      const missing = rel.bases.map((b) => b.id).filter((bid) => !this.db.prepare('SELECT 1 FROM games WHERE bgg_id = ?').get(bid));
      if (missing.length && t.type === 'boardgameexpansion') {
        const bases = await this.client.things(missing);
        for (const b of bases.values()) {
          const bid = applyBggThing(this.db, b, { defaults: { ownership_status: 'reference', kind: 'base' } });
          this.images.schedule(bid);
        }
      }
    }
    if (opts.withExpansions !== false && t.type === 'boardgame' && rel.expansions.length) {
      this.registerExpansionStubs(id, rel.expansions.map((e) => ({ bggId: e.id, name: e.value })));
    }
    return id;
  }

  /** Registra as expansões conhecidas como "Não verificado" (sem presumir posse). */
  registerExpansionStubs(baseId: number, list: { bggId: number; name: string }[]) {
    const base = this.db.prepare('SELECT bgg_id FROM games WHERE id = ?').get(baseId) as { bgg_id: number };
    const tx = this.db.transaction(() => {
      // expansões cadastradas à mão para este jogo (ainda sem vínculo com o BGG)
      const manual = this.db.prepare(`SELECT g.id, g.name_en FROM game_relations r JOIN games g ON g.id = r.game_id
        WHERE r.related_id = ? AND r.relation = 'expansion_of' AND g.bgg_id IS NULL`).all(baseId) as { id: number; name_en: string }[];
      for (const e of list) {
        // não cria um registro paralelo se já existe uma expansão manual com o mesmo nome (o vínculo é feito na revisão)
        if (manual.some((m) => similarity(m.name_en, e.name) >= 0.85 || similarity(m.name_en, e.name.replace(/^[^:]+:\s*/, '')) >= 0.85)) continue;
        let row = this.db.prepare('SELECT id FROM games WHERE bgg_id = ?').get(e.bggId) as { id: number } | undefined;
        if (!row) {
          const info = this.db.prepare(`INSERT INTO games (bgg_id, name_en, kind, bgg_type, ownership_status, data_status, location_type)
            VALUES (?, ?, 'expansion', 'boardgameexpansion', 'unverified', 'stub', 'with_me')`).run(e.bggId, e.name);
          row = { id: Number(info.lastInsertRowid) };
          this.db.prepare(`INSERT INTO field_sources (game_id, field, source, status, note) VALUES (?, 'name_en', 'bgg', 'unverified', 'Nome vindo da lista de expansões do jogo-base; detalhes ainda não buscados')`).run(row.id);
        }
        this.db.prepare(`INSERT OR IGNORE INTO game_relations (game_id, related_id, related_bgg_id, related_name, relation, source)
          VALUES (?, ?, ?, (SELECT name_en FROM games WHERE id = ?), 'expansion_of', 'bgg')`).run(row.id, baseId, base.bgg_id, baseId);
      }
    });
    tx();
  }

  /**
   * Vincula um jogo cadastrado manualmente a um item do BGG e busca os dados oficiais.
   * Se o item já existir só como registro automático de expansão (sem dados pessoais), os dois são mesclados.
   */
  async link(gameId: number, bggId: number): Promise<void> {
    const me = this.db.prepare('SELECT owner_id FROM games WHERE id = ?').get(gameId) as any;
    const others = this.db.prepare('SELECT * FROM games WHERE bgg_id = ? AND id <> ?').all(bggId, gameId) as any[];
    const sameOwner = others.find((x) => x.owner_id != null && x.owner_id === me?.owner_id && x.ownership_status === 'owned');
    if (sameOwner) throw new HttpError(409, `Este proprietário já tem "${sameOwner.name_en}" vinculado a esse item do BGG.`, { duplicateId: sameOwner.id });
    // cópias de outros proprietários convivem; só registros automáticos (sem dados pessoais) são mesclados
    const other = others.find((x) => ['unverified', 'not_owned'].includes(x.ownership_status) && !x.notes && !x.favorite);
    if (other) {
      this.db.transaction(() => {
        // as relações do registro automático passam para o jogo do usuário
        for (const r of this.db.prepare('SELECT * FROM game_relations WHERE game_id = ?').all(other.id) as any[]) {
          const dup = this.db.prepare(`SELECT id FROM game_relations WHERE game_id = ? AND relation = ? AND (related_id = ? OR related_bgg_id = ?)`)
            .get(gameId, r.relation, r.related_id ?? -1, r.related_bgg_id ?? -1) as any;
          if (dup) this.db.prepare('UPDATE game_relations SET related_id = COALESCE(related_id, ?), related_bgg_id = COALESCE(related_bgg_id, ?) WHERE id = ?').run(r.related_id, r.related_bgg_id, dup.id);
          else this.db.prepare('UPDATE game_relations SET game_id = ? WHERE id = ?').run(gameId, r.id);
        }
        this.db.prepare('UPDATE game_relations SET related_id = ? WHERE related_id = ?').run(gameId, other.id);
        this.db.prepare('DELETE FROM games WHERE id = ?').run(other.id);
      })();
    }
    const prev = this.db.prepare('SELECT manual_fields, data_status FROM games WHERE id = ?').get(gameId) as any;
    if (!prev) throw new HttpError(404, 'Jogo não encontrado.');
    this.db.prepare(`UPDATE games SET bgg_id = ?, manual_fields = '[]', data_status = 'stub' WHERE id = ?`).run(bggId, gameId);
    try {
      await this.refresh(gameId, { force: true });
    } catch (e) {
      this.db.prepare(`UPDATE games SET bgg_id = NULL, manual_fields = ?, data_status = ? WHERE id = ?`).run(prev.manual_fields, prev.data_status, gameId);
      throw e;
    }
  }

  /** Atualiza dados do BGG de um jogo (e opcionalmente das expansões), preservando dados pessoais. */
  async refresh(gameId: number, opts: { force?: boolean } = {}): Promise<{ updated: number; errors: string[] }> {
    const g = this.db.prepare('SELECT id, bgg_id FROM games WHERE id = ?').get(gameId) as { id: number; bgg_id: number | null } | undefined;
    if (!g) throw new Error('Jogo não encontrado');
    if (!g.bgg_id) throw new BggError('Este jogo não tem ID do BGG. Vincule-o a um item do BGG primeiro.', 'bad_response');
    try {
      const t = await this.client.thing(g.bgg_id, { versions: true, force: opts.force });
      if (!t) throw new BggError(`O BGG não retornou o item ${g.bgg_id}.`, 'bad_response');
      applyBggThing(this.db, t);
      this.images.schedule(g.id);
      const rel = relationsOf(t);
      if (t.type === 'boardgame' && rel.expansions.length) this.registerExpansionStubs(g.id, rel.expansions.map((e) => ({ bggId: e.id, name: e.value })));
      return { updated: 1, errors: [] };
    } catch (e) {
      markBggError(this.db, g.id, (e as Error).message);
      throw e;
    }
  }

  /** Busca os dados completos das expansões conhecidas de um jogo-base (em lotes de 20). */
  async refreshExpansions(baseId: number, opts: { onlyMissing?: boolean; force?: boolean } = {}): Promise<{ updated: number; notExpansion: number; errors: string[] }> {
    const rows = this.db.prepare(`SELECT g.id, g.bgg_id, g.data_status FROM game_relations r JOIN games g ON g.id = r.game_id
      WHERE r.related_id = ? AND r.relation = 'expansion_of' AND r.status = 'active' AND g.bgg_id IS NOT NULL`).all(baseId) as any[];
    const target = opts.onlyMissing ? rows.filter((r) => r.data_status !== 'bgg_ok') : rows;
    const errors: string[] = [];
    let updated = 0, notExpansion = 0;
    if (!target.length) return { updated, notExpansion, errors };
    let things;
    try {
      things = await this.client.things(target.map((r) => r.bgg_id), { force: opts.force });
    } catch (e) {
      for (const r of target) markBggError(this.db, r.id, (e as Error).message);
      throw e;
    }
    for (const r of target) {
      const t = things.get(r.bgg_id);
      if (!t) {
        markBggError(this.db, r.id, 'O BGG não retornou este item');
        errors.push(`BGG #${r.bgg_id} não retornado`);
        continue;
      }
      applyBggThing(this.db, t);
      if (t.type !== 'boardgameexpansion') notExpansion++;
      this.images.schedule(r.id);
      updated++;
    }
    return { updated, notExpansion, errors };
  }
}
