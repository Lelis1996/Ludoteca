// Migrações versionadas (aplicadas em ordem, uma única vez).
export const MIGRATIONS: { name: string; sql: string; noForeignKeys?: boolean }[] = [
  { name: '001_init.sql', sql: `-- Ludoteca — esquema inicial

CREATE TABLE owners (
  id          INTEGER PRIMARY KEY,
  name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
  color       TEXT NOT NULL DEFAULT '#f5f1e8',
  is_me       INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Jogos-base, expansões e jogos independentes ficam na mesma tabela.
CREATE TABLE games (
  id                 INTEGER PRIMARY KEY,
  bgg_id             INTEGER UNIQUE,
  bgg_type           TEXT,                 -- boardgame | boardgameexpansion (como o BGG classifica)
  kind               TEXT NOT NULL DEFAULT 'base',  -- base | expansion
  standalone_expansion INTEGER NOT NULL DEFAULT 0,  -- item boardgame que o BGG também lista como expansão
  expansion_type     TEXT,                 -- content | modular | campaign | characters | maps | scenarios | promo | fan | other
  expansion_type_source TEXT,              -- inferred | manual
  name_en            TEXT NOT NULL,
  name_pt            TEXT,
  name_pt_source     TEXT,                 -- manual | bgg_alternate_confirmed
  alt_names_json     TEXT,                 -- nomes alternativos registrados no BGG
  pt_versions_json   TEXT,                 -- edições em português listadas no BGG
  description        TEXT,
  year               INTEGER,
  image_url          TEXT,
  thumbnail_url      TEXT,
  image_local        TEXT,
  thumb_local        TEXT,
  min_players        INTEGER,
  max_players        INTEGER,
  playing_time       INTEGER,
  min_playtime       INTEGER,
  max_playtime       INTEGER,
  min_age            INTEGER,
  weight             REAL,
  weight_votes       INTEGER,
  users_rated        INTEGER,
  avg_rating         REAL,
  bgg_rank           INTEGER,
  poll_total_votes   INTEGER,
  poll_best_summary  TEXT,                 -- texto do poll-summary do BGG
  poll_rec_summary   TEXT,
  best_count_1       TEXT,                 -- 1º melhor nº de jogadores (votos "Best")
  best_votes_1       INTEGER,
  best_count_2       TEXT,
  best_votes_2       INTEGER,
  recommended_counts TEXT,                 -- JSON array de contagens recomendadas pela comunidade
  -- dados pessoais / manuais
  typical_time_manual   INTEGER,
  time_per_player_manual INTEGER,
  time_base_players_manual INTEGER,
  time_note          TEXT,
  ownership_status   TEXT NOT NULL DEFAULT 'owned', -- owned | not_owned | wishlist | want_to_try | reference | unverified
  owner_id           INTEGER REFERENCES owners(id) ON DELETE SET NULL,
  location_type      TEXT NOT NULL DEFAULT 'with_me', -- with_me | with_friend | lent_out | borrowed | other
  location_person    TEXT,
  location_custom    TEXT,
  loan_date          TEXT,
  loan_due_date      TEXT,
  favorite           INTEGER NOT NULL DEFAULT 0,
  notes              TEXT,
  acquired_at        TEXT,
  price_paid         REAL,
  last_verified_at   TEXT,
  manual_fields      TEXT NOT NULL DEFAULT '[]', -- campos editados à mão que o BGG não sobrescreve
  data_status        TEXT NOT NULL DEFAULT 'manual', -- manual | stub | bgg_ok | bgg_error
  bgg_fetched_at     TEXT,
  bgg_error          TEXT,
  created_at         TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_games_kind ON games(kind);
CREATE INDEX idx_games_owner ON games(owner_id);

-- Votação "User Suggested Number of Players" (Community / Best With)
CREATE TABLE player_poll (
  game_id         INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  num_players     TEXT NOT NULL,
  best            INTEGER NOT NULL,
  recommended     INTEGER NOT NULL,
  not_recommended INTEGER NOT NULL,
  PRIMARY KEY (game_id, num_players)
);

-- Termos oficiais do BGG: mecânicas, categorias, famílias, designers, editoras, artistas
CREATE TABLE bgg_terms (
  id        INTEGER PRIMARY KEY,
  type      TEXT NOT NULL,   -- mechanic | category | family | designer | publisher | artist | subdomain
  bgg_link_id INTEGER,
  name      TEXT NOT NULL,
  UNIQUE (type, name)
);
CREATE TABLE game_bgg_terms (
  game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  term_id INTEGER NOT NULL REFERENCES bgg_terms(id) ON DELETE CASCADE,
  PRIMARY KEY (game_id, term_id)
);

-- Etiquetas da aplicação
CREATE TABLE tags (
  id          INTEGER PRIMARY KEY,
  name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
  grp         TEXT NOT NULL DEFAULT 'custom', -- mechanic | style | interaction | luck | duration | custom
  description TEXT,
  sort        INTEGER NOT NULL DEFAULT 100
);
CREATE TABLE game_tags (
  game_id     INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  tag_id      INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  source      TEXT NOT NULL,           -- bgg_derived | inferred | manual
  detail      TEXT,                    -- de onde veio (ex.: mecânica BGG "Worker Placement")
  status      TEXT NOT NULL DEFAULT 'active', -- active | rejected (rejeitada manualmente: não volta na atualização)
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (game_id, tag_id)
);

-- Relações entre jogos (expansões, reimplementações, integrações...)
CREATE TABLE game_relations (
  id          INTEGER PRIMARY KEY,
  game_id     INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE, -- a expansão / item
  related_id  INTEGER REFERENCES games(id) ON DELETE CASCADE,          -- o jogo-base, se cadastrado
  related_bgg_id INTEGER,
  related_name TEXT,
  relation    TEXT NOT NULL,  -- expansion_of | implementation_of | integrates_with | compilation_of
  source      TEXT NOT NULL,  -- bgg | manual
  status      TEXT NOT NULL DEFAULT 'active', -- active | rejected (associação incorreta corrigida pelo usuário)
  UNIQUE (game_id, related_bgg_id, relation),
  UNIQUE (game_id, related_id, relation)
);

-- Histórico de empréstimos
CREATE TABLE loans (
  id          INTEGER PRIMARY KEY,
  game_id     INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  direction   TEXT NOT NULL,   -- lent_out | borrowed
  person      TEXT,
  start_date  TEXT,
  due_date    TEXT,
  returned_at TEXT,
  notes       TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Fonte de cada campo
CREATE TABLE field_sources (
  game_id    INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  field      TEXT NOT NULL,
  source     TEXT NOT NULL,     -- bgg | manual | calculated | inferred
  status     TEXT NOT NULL,     -- verified | unverified | unavailable
  note       TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (game_id, field)
);

-- Importação por fotos
CREATE TABLE import_batches (
  id            INTEGER PRIMARY KEY,
  status        TEXT NOT NULL DEFAULT 'processing', -- processing | review | done | error
  provider      TEXT,
  owner_id      INTEGER REFERENCES owners(id) ON DELETE SET NULL,
  location_type TEXT NOT NULL DEFAULT 'with_me',
  location_person TEXT,
  ownership_status TEXT NOT NULL DEFAULT 'owned',
  notes         TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at   TEXT
);
CREATE TABLE import_photos (
  id          INTEGER PRIMARY KEY,
  batch_id    INTEGER NOT NULL REFERENCES import_batches(id) ON DELETE CASCADE,
  filename    TEXT NOT NULL,
  path        TEXT NOT NULL,
  thumb_path  TEXT,
  width       INTEGER,
  height      INTEGER,
  status      TEXT NOT NULL DEFAULT 'pending', -- pending | analyzing | matching | done | error
  provider    TEXT,
  raw_result  TEXT,
  error       TEXT
);
CREATE TABLE import_candidates (
  id            INTEGER PRIMARY KEY,
  photo_id      INTEGER NOT NULL REFERENCES import_photos(id) ON DELETE CASCADE,
  detected_title TEXT NOT NULL,
  detected_text TEXT,
  bbox_json     TEXT,
  crop_path     TEXT,
  expansion_guess INTEGER NOT NULL DEFAULT 0,
  base_guess    TEXT,
  vision_confidence REAL,
  confidence    REAL,
  matches_json  TEXT,       -- resultados do BGG avaliados
  warnings_json TEXT,
  selected_bgg_id INTEGER,
  status        TEXT NOT NULL DEFAULT 'pending', -- pending | confirmed | ignored | added | error
  game_id       INTEGER REFERENCES games(id) ON DELETE SET NULL,
  error         TEXT
);

-- Cache de respostas do BGG
CREATE TABLE bgg_cache (
  key        TEXT PRIMARY KEY,
  body       TEXT NOT NULL,
  fetched_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
` },
  { name: '002_mobile.sql', sql: `-- Vínculo em lote: candidatos que apontam para um jogo já cadastrado
ALTER TABLE import_candidates ADD COLUMN link_game_id INTEGER REFERENCES games(id) ON DELETE CASCADE;
ALTER TABLE import_batches ADD COLUMN source TEXT NOT NULL DEFAULT 'photos';
-- arquivos guardados no próprio banco (versão para celular)
CREATE TABLE IF NOT EXISTS blobs (
  key  TEXT PRIMARY KEY,
  mime TEXT NOT NULL,
  data BLOB NOT NULL
);
` },
  { name: '003_copies.sql', noForeignKeys: true, sql: `-- Permite várias cópias do mesmo jogo do BGG (ex.: o seu Dixit e o de um amigo)
CREATE TABLE games_new (
  id                 INTEGER PRIMARY KEY,
  bgg_id             INTEGER,
  bgg_type           TEXT,                 -- boardgame | boardgameexpansion (como o BGG classifica)
  kind               TEXT NOT NULL DEFAULT 'base',  -- base | expansion
  standalone_expansion INTEGER NOT NULL DEFAULT 0,  -- item boardgame que o BGG também lista como expansão
  expansion_type     TEXT,                 -- content | modular | campaign | characters | maps | scenarios | promo | fan | other
  expansion_type_source TEXT,              -- inferred | manual
  name_en            TEXT NOT NULL,
  name_pt            TEXT,
  name_pt_source     TEXT,                 -- manual | bgg_alternate_confirmed
  alt_names_json     TEXT,                 -- nomes alternativos registrados no BGG
  pt_versions_json   TEXT,                 -- edições em português listadas no BGG
  description        TEXT,
  year               INTEGER,
  image_url          TEXT,
  thumbnail_url      TEXT,
  image_local        TEXT,
  thumb_local        TEXT,
  min_players        INTEGER,
  max_players        INTEGER,
  playing_time       INTEGER,
  min_playtime       INTEGER,
  max_playtime       INTEGER,
  min_age            INTEGER,
  weight             REAL,
  weight_votes       INTEGER,
  users_rated        INTEGER,
  avg_rating         REAL,
  bgg_rank           INTEGER,
  poll_total_votes   INTEGER,
  poll_best_summary  TEXT,                 -- texto do poll-summary do BGG
  poll_rec_summary   TEXT,
  best_count_1       TEXT,                 -- 1º melhor nº de jogadores (votos "Best")
  best_votes_1       INTEGER,
  best_count_2       TEXT,
  best_votes_2       INTEGER,
  recommended_counts TEXT,                 -- JSON array de contagens recomendadas pela comunidade
  -- dados pessoais / manuais
  typical_time_manual   INTEGER,
  time_per_player_manual INTEGER,
  time_base_players_manual INTEGER,
  time_note          TEXT,
  ownership_status   TEXT NOT NULL DEFAULT 'owned', -- owned | not_owned | wishlist | want_to_try | reference | unverified
  owner_id           INTEGER REFERENCES owners(id) ON DELETE SET NULL,
  location_type      TEXT NOT NULL DEFAULT 'with_me', -- with_me | with_friend | lent_out | borrowed | other
  location_person    TEXT,
  location_custom    TEXT,
  loan_date          TEXT,
  loan_due_date      TEXT,
  favorite           INTEGER NOT NULL DEFAULT 0,
  notes              TEXT,
  acquired_at        TEXT,
  price_paid         REAL,
  last_verified_at   TEXT,
  manual_fields      TEXT NOT NULL DEFAULT '[]', -- campos editados à mão que o BGG não sobrescreve
  data_status        TEXT NOT NULL DEFAULT 'manual', -- manual | stub | bgg_ok | bgg_error
  bgg_fetched_at     TEXT,
  bgg_error          TEXT,
  created_at         TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT INTO games_new (id, bgg_id, bgg_type, kind, standalone_expansion, expansion_type, expansion_type_source, name_en, name_pt, name_pt_source, alt_names_json, pt_versions_json, description, year, image_url, thumbnail_url, image_local, thumb_local, min_players, max_players, playing_time, min_playtime, max_playtime, min_age, weight, weight_votes, users_rated, avg_rating, bgg_rank, poll_total_votes, poll_best_summary, poll_rec_summary, best_count_1, best_votes_1, best_count_2, best_votes_2, recommended_counts, typical_time_manual, time_per_player_manual, time_base_players_manual, time_note, ownership_status, owner_id, location_type, location_person, location_custom, loan_date, loan_due_date, favorite, notes, acquired_at, price_paid, last_verified_at, manual_fields, data_status, bgg_fetched_at, bgg_error, created_at, updated_at) SELECT id, bgg_id, bgg_type, kind, standalone_expansion, expansion_type, expansion_type_source, name_en, name_pt, name_pt_source, alt_names_json, pt_versions_json, description, year, image_url, thumbnail_url, image_local, thumb_local, min_players, max_players, playing_time, min_playtime, max_playtime, min_age, weight, weight_votes, users_rated, avg_rating, bgg_rank, poll_total_votes, poll_best_summary, poll_rec_summary, best_count_1, best_votes_1, best_count_2, best_votes_2, recommended_counts, typical_time_manual, time_per_player_manual, time_base_players_manual, time_note, ownership_status, owner_id, location_type, location_person, location_custom, loan_date, loan_due_date, favorite, notes, acquired_at, price_paid, last_verified_at, manual_fields, data_status, bgg_fetched_at, bgg_error, created_at, updated_at FROM games;
DROP TABLE games;
ALTER TABLE games_new RENAME TO games;
CREATE INDEX idx_games_kind ON games(kind);
CREATE INDEX idx_games_owner ON games(owner_id);
CREATE INDEX idx_games_bgg ON games(bgg_id);
` },
];
