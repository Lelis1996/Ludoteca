import type { DB } from './dbtypes';
import { MIGRATIONS } from './migrations';
import { DEFAULT_SETTINGS } from '../shared/domain';

export const SEED_TAGS: { name: string; grp: string }[] = [
  ...['Worker placement', 'Deck building', 'Card drafting', 'Engine building', 'Area control / area majority',
    'Tile placement', 'Set collection', 'Action selection', 'Resource management', 'Dice rolling',
    'Hand management', 'Push your luck', 'Auction / bidding', 'Route building', 'Variable player powers',
    'Cooperative play', 'Hidden roles', 'Social deduction', 'Campaign / legacy', 'Real-time play',
  ].map((name) => ({ name, grp: 'mechanic' })),
  ...['Eurogame', 'Ameritrash / thematic', 'Cooperativo', 'Competitivo', 'Solo', 'Equipes', 'Party game',
    'Abstract', 'Wargame', 'Família', 'Estratégico', 'Tático', 'Temático', 'Econômico', 'Narrativo',
    'Presença de cartas', 'Negociação', 'Confronto direto', 'Eliminação de jogadores', 'Informação oculta',
  ].map((name) => ({ name, grp: 'style' })),
  ...['Alta interação', 'Média interação', 'Baixa interação'].map((name) => ({ name, grp: 'interaction' })),
  ...['Alta dependência de sorte', 'Baixa dependência de sorte'].map((name) => ({ name, grp: 'luck' })),
  ...['Duração curta', 'Duração média', 'Duração longa'].map((name) => ({ name, grp: 'duration' })),
];

export function migrate(db: DB): string[] {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT (datetime('now')))`);
  const done = new Set((db.prepare('SELECT name FROM schema_migrations').all() as { name: string }[]).map((r) => r.name));
  const applied: string[] = [];
  for (const m of MIGRATIONS) {
    if (done.has(m.name)) continue;
    // recriar tabelas exige desligar as chaves estrangeiras fora da transação
    if (m.noForeignKeys) db.exec('PRAGMA foreign_keys = OFF');
    try {
      db.transaction(() => {
        db.exec(m.sql);
        db.prepare('INSERT INTO schema_migrations (name) VALUES (?)').run(m.name);
      })();
    } finally {
      if (m.noForeignKeys) db.exec('PRAGMA foreign_keys = ON');
    }
    applied.push(m.name);
  }
  return applied;
}

export function seedBasics(db: DB) {
  const owners = db.prepare('SELECT COUNT(*) n FROM owners').get() as { n: number };
  if (owners.n === 0) db.prepare(`INSERT INTO owners (name, color, is_me) VALUES ('Meus jogos', '#f5f1e8', 1)`).run();
  if (!db.prepare(`SELECT value FROM settings WHERE key = 'seeded_tags'`).get()) {
    db.transaction(() => {
      SEED_TAGS.forEach((t, i) => db.prepare('INSERT OR IGNORE INTO tags (name, grp, sort) VALUES (?, ?, ?)').run(t.name, t.grp, i));
      db.prepare(`INSERT INTO settings (key, value) VALUES ('seeded_tags', '1')`).run();
    })();
  }
  if (!db.prepare(`SELECT value FROM settings WHERE key = 'app'`).get()) {
    db.prepare(`INSERT INTO settings (key, value) VALUES ('app', ?)`).run(JSON.stringify(DEFAULT_SETTINGS));
  }
}

export function getSetting<T>(db: DB, key: string, fallback: T): T {
  const r = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
  if (!r) return fallback;
  try { return JSON.parse(r.value) as T; } catch { return fallback; }
}

export function setSetting(db: DB, key: string, value: unknown) {
  db.prepare(`INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`).run(key, JSON.stringify(value));
}
