import type { PollRow, ExpansionType } from '../../shared/types';
import type { BggThing } from './parse';

export interface BestWith {
  first: { count: string; votes: number } | null;
  second: { count: string; votes: number } | null;
  recommended: number[];
  method: string;
}

export const BEST_WITH_METHOD =
  'Enquete "User Suggested Number of Players" do BGG (a mesma exibida em Community › Best). ' +
  'As duas melhores quantidades são as com mais votos "Best"; empate é desempatado por "Best + Recommended". ' +
  'Contagens "N+" (acima do máximo oficial) são ignoradas. "Recomendado" = votos Best + Recommended maiores que Not Recommended, ' +
  'a mesma regra que o BGG usa no resumo "Recommended with".';

/**
 * Calcula as duas melhores quantidades de jogadores segundo a comunidade.
 * Não inventa nada: sem votos, devolve null.
 */
export function computeBestWith(poll: PollRow[]): BestWith {
  const rows = poll.filter((r) => /^\d+$/.test(r.numPlayers));
  const withVotes = rows.filter((r) => r.best + r.recommended + r.notRecommended > 0);
  const recommended = withVotes
    .filter((r) => r.best + r.recommended > r.notRecommended)
    .map((r) => parseInt(r.numPlayers, 10))
    .sort((a, b) => a - b);
  const ranked = withVotes
    .filter((r) => r.best > 0)
    .sort((a, b) => b.best - a.best || (b.best + b.recommended) - (a.best + a.recommended) || parseInt(a.numPlayers) - parseInt(b.numPlayers));
  return {
    first: ranked[0] ? { count: ranked[0].numPlayers, votes: ranked[0].best } : null,
    second: ranked[1] ? { count: ranked[1].numPlayers, votes: ranked[1].best } : null,
    recommended,
    method: BEST_WITH_METHOD,
  };
}

/** Mapeamento explícito de mecânicas/categorias oficiais do BGG para etiquetas da aplicação. */
const MECHANIC_MAP: { test: RegExp; tags: string[] }[] = [
  { test: /^Worker Placement/i, tags: ['Worker placement'] },
  { test: /^Deck, Bag, and Pool Building$|^Deck \/ Pool Building$/i, tags: ['Deck building'] },
  { test: /^(Open|Closed) Drafting$|^Card Drafting$/i, tags: ['Card drafting'] },
  { test: /^Engine Building$/i, tags: ['Engine building'] },
  { test: /^Area Majority \/ Influence$|^Area Control/i, tags: ['Area control / area majority'] },
  { test: /^Tile Placement$/i, tags: ['Tile placement'] },
  { test: /^Set Collection$/i, tags: ['Set collection'] },
  { test: /^(Action Drafting|Action Selection|Role Selection|Action Retrieval)$/i, tags: ['Action selection'] },
  { test: /^Dice Rolling$/i, tags: ['Dice rolling'] },
  { test: /^Hand Management$/i, tags: ['Hand management'] },
  { test: /^Push Your Luck$/i, tags: ['Push your luck'] },
  { test: /^Auction|Bidding/i, tags: ['Auction / bidding'] },
  { test: /^Route\/Network Building$|^Network and Route Building$/i, tags: ['Route building'] },
  { test: /^Variable Player Powers$/i, tags: ['Variable player powers'] },
  { test: /^Cooperative Game$/i, tags: ['Cooperative play', 'Cooperativo'] },
  { test: /^Hidden Roles$/i, tags: ['Hidden roles', 'Informação oculta'] },
  { test: /^Traitor Game$/i, tags: ['Hidden roles', 'Social deduction'] },
  { test: /^(Legacy Game|Scenario \/ Mission \/ Campaign Game)$/i, tags: ['Campaign / legacy'] },
  { test: /^Real-Time$/i, tags: ['Real-time play'] },
  { test: /^Team-Based Game$/i, tags: ['Equipes'] },
  { test: /^Solo \/ Solitaire Game$/i, tags: ['Solo'] },
  { test: /^Negotiation$/i, tags: ['Negociação'] },
  { test: /^Player Elimination$/i, tags: ['Eliminação de jogadores'] },
  { test: /^(Hidden Movement|Hidden Victory Points)$/i, tags: ['Informação oculta'] },
  { test: /^Take That$/i, tags: ['Confronto direto'] },
];

const CATEGORY_MAP: { test: RegExp; tags: string[] }[] = [
  { test: /^Card Game$/i, tags: ['Presença de cartas'] },
  { test: /^Wargame$/i, tags: ['Wargame'] },
  { test: /^Party Game$/i, tags: ['Party game'] },
  { test: /^Abstract Strategy$/i, tags: ['Abstract'] },
  { test: /^Economic$/i, tags: ['Econômico'] },
  { test: /^Negotiation$/i, tags: ['Negociação'] },
];

/** Rankings de subdomínio do BGG ("Strategy Game Rank" etc.) — classificação oficial do BGG. */
const SUBDOMAIN_MAP: Record<string, string> = {
  strategygames: 'Estratégico',
  thematic: 'Temático',
  familygames: 'Família',
  partygames: 'Party game',
  abstracts: 'Abstract',
  wargames: 'Wargame',
};

export interface DerivedTag { name: string; source: 'bgg_derived' | 'inferred'; detail: string }

export function deriveTags(t: BggThing, typicalMinutes: number | null, durationBucket: (m: number | null) => string | null): DerivedTag[] {
  const out = new Map<string, DerivedTag>();
  const add = (name: string, source: DerivedTag['source'], detail: string) => {
    const prev = out.get(name);
    if (prev) {
      if (prev.source === 'inferred' && source === 'bgg_derived') out.set(name, { name, source, detail });
      else if (prev.source === source && !prev.detail.includes(detail)) prev.detail += `; ${detail}`;
      return;
    }
    out.set(name, { name, source, detail });
  };
  const mechanics = t.links.filter((l) => l.type === 'boardgamemechanic').map((l) => l.value);
  const categories = t.links.filter((l) => l.type === 'boardgamecategory').map((l) => l.value);
  for (const m of mechanics) for (const r of MECHANIC_MAP) if (r.test.test(m)) r.tags.forEach((tag) => add(tag, 'bgg_derived', `Mecânica BGG "${m}"`));
  for (const c of categories) for (const r of CATEGORY_MAP) if (r.test.test(c)) r.tags.forEach((tag) => add(tag, 'bgg_derived', `Categoria BGG "${c}"`));
  for (const r of t.stats?.subdomainRanks ?? []) {
    const tag = SUBDOMAIN_MAP[r.name];
    if (tag) add(tag, 'bgg_derived', `Classificado pelo BGG em "${r.friendlyName}"`);
  }
  if (t.minPlayers === 1) add('Solo', 'bgg_derived', 'Mínimo oficial de 1 jogador no BGG');
  const coop = mechanics.some((m) => /^Cooperative Game$/i.test(m));
  if (!coop && (t.maxPlayers ?? 0) >= 2 && mechanics.length > 0) {
    add('Competitivo', 'inferred', 'Inferido: o BGG não lista a mecânica "Cooperative Game" — confira, pode ser semicooperativo');
  }
  const bucket = durationBucket(typicalMinutes);
  if (bucket) add(bucket, 'inferred', `Calculado a partir do tempo típico (${typicalMinutes} min)`);
  return [...out.values()];
}

/** Classifica o tipo de expansão quando há evidência no nome/categorias. */
export function inferExpansionType(t: BggThing): ExpansionType | null {
  const name = t.primaryName;
  const cats = t.links.filter((l) => l.type === 'boardgamecategory').map((l) => l.value.toLowerCase());
  const fams = t.links.filter((l) => l.type === 'boardgamefamily').map((l) => l.value.toLowerCase());
  if (cats.includes('fan expansion') || fams.some((f) => f.includes('fan expansion'))) return 'fan';
  if (/\bpromo(s|tional)?\b/i.test(name) || fams.some((f) => f.startsWith('promotional'))) return 'promo';
  if (/\bcampaign|campanha|legacy\b/i.test(name)) return 'campaign';
  if (/\bscenario|scenarios|cenário/i.test(name)) return 'scenarios';
  if (/\bmap(s|pack)?\b|\bboard\b|mapa/i.test(name)) return 'maps';
  if (/\bcharacter|heroes|hero pack|personagens?\b/i.test(name)) return 'characters';
  if (/\bmodule|modules|módulo/i.test(name)) return 'modular';
  return null;
}

/** Edições do BGG em português (nome da edição + editora). Não é o título traduzido. */
export function portugueseVersions(t: BggThing): { name: string; publisher: string | null; year: number | null }[] {
  return (t.versions ?? [])
    .filter((v) => v.languages.some((l) => /portuguese/i.test(l)))
    .map((v) => ({ name: v.name, publisher: v.publishers[0] ?? null, year: v.year }));
}

/** Relações do item (para expansões e itens relacionados). */
export function relationsOf(t: BggThing) {
  const baseOf = t.links.filter((l) => l.type === 'boardgameexpansion' && l.inbound);
  const expansions = t.links.filter((l) => l.type === 'boardgameexpansion' && !l.inbound);
  return {
    // Para uma expansão: links inbound apontam para o(s) jogo(s)-base
    bases: t.type === 'boardgameexpansion' ? t.links.filter((l) => l.type === 'boardgameexpansion') : baseOf,
    // Para um jogo-base: links de expansão
    expansions: t.type === 'boardgame' ? expansions : [],
    standaloneExpansion: t.type === 'boardgame' && baseOf.length > 0,
    implementations: t.links.filter((l) => l.type === 'boardgameimplementation'),
    integrations: t.links.filter((l) => l.type === 'boardgameintegration'),
    compilations: t.links.filter((l) => l.type === 'boardgamecompilation'),
  };
}
