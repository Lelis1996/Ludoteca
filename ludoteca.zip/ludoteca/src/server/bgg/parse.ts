import { XMLParser } from 'fast-xml-parser';
import type { PollRow } from '../../shared/types';

const ARRAY_TAGS = new Set(['item', 'name', 'link', 'poll', 'results', 'result', 'rank', 'poll-summary']);

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '',
  htmlEntities: true,
  parseAttributeValue: false,
  parseTagValue: false,
  trimValues: true,
  isArray: (tagName, _jPath, _isLeaf, isAttribute) => !isAttribute && ARRAY_TAGS.has(tagName),
});

export interface BggLink { type: string; id: number; value: string; inbound: boolean }

export interface BggVersion {
  id: number;
  name: string;
  year: number | null;
  languages: string[];
  publishers: string[];
}

export interface BggThing {
  id: number;
  type: string;
  primaryName: string;
  altNames: string[];
  description: string | null;
  year: number | null;
  image: string | null;
  thumbnail: string | null;
  minPlayers: number | null;
  maxPlayers: number | null;
  playingTime: number | null;
  minPlaytime: number | null;
  maxPlaytime: number | null;
  minAge: number | null;
  poll: PollRow[];
  pollTotalVotes: number | null;
  pollSummaryBest: string | null;
  pollSummaryRec: string | null;
  links: BggLink[];
  stats: {
    usersRated: number | null;
    average: number | null;
    weight: number | null;
    numWeights: number | null;
    rank: number | null;
    subdomainRanks: { name: string; friendlyName: string; value: number | null }[];
  } | null;
  versions: BggVersion[] | null; // null = não solicitado
}

export interface BggSearchItem {
  id: number;
  type: string;
  name: string;
  nameType: 'primary' | 'alternate';
  year: number | null;
}

function int(v: unknown): number | null {
  if (v == null || v === '') return null;
  const n = parseInt(String(v), 10);
  return Number.isFinite(n) ? n : null;
}
function float(v: unknown): number | null {
  if (v == null || v === '') return null;
  const n = parseFloat(String(v));
  return Number.isFinite(n) ? n : null;
}
function attrVal(node: any): any {
  if (node == null) return null;
  if (Array.isArray(node)) node = node[0];
  return typeof node === 'object' ? node.value : node;
}
function text(node: any): string | null {
  if (node == null) return null;
  if (typeof node === 'string') return node.trim() || null;
  if (typeof node === 'object' && '#text' in node) return String(node['#text']).trim() || null;
  return null;
}

/** Erro devolvido pelo BGG dentro de um XML (ex.: <errors><error><message>...). */
export function xmlErrorMessage(xml: string): string | null {
  const doc = parser.parse(xml);
  const errs = doc?.errors?.error ?? doc?.error;
  if (!errs) return null;
  const e = Array.isArray(errs) ? errs[0] : errs;
  return text(e?.message) ?? (typeof e === 'string' ? e : 'Erro desconhecido do BGG');
}

export function parseSearch(xml: string): BggSearchItem[] {
  const doc = parser.parse(xml);
  const items: any[] = doc?.items?.item ?? [];
  const out: BggSearchItem[] = [];
  for (const it of items) {
    const id = int(it.id);
    const nameNode = it.name?.[0];
    if (id == null || !nameNode) continue;
    out.push({
      id,
      type: String(it.type),
      name: String(nameNode.value),
      nameType: nameNode.type === 'alternate' ? 'alternate' : 'primary',
      year: int(attrVal(it.yearpublished)),
    });
  }
  return out;
}

function cleanDescription(s: string | null): string | null {
  if (!s) return null;
  return s
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/\r/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim() || null;
}

export function parseThings(xml: string): BggThing[] {
  const doc = parser.parse(xml);
  const items: any[] = doc?.items?.item ?? [];
  return items.map(parseThingItem).filter((t): t is BggThing => t != null);
}

function parseThingItem(it: any): BggThing | null {
  const id = int(it.id);
  if (id == null) return null;
  const names: any[] = it.name ?? [];
  const primary = names.find((n) => n.type === 'primary') ?? names[0];
  const links: BggLink[] = (it.link ?? []).map((l: any) => ({
    type: String(l.type), id: int(l.id) ?? 0, value: String(l.value), inbound: l.inbound === 'true',
  }));

  let poll: PollRow[] = [];
  let pollTotalVotes: number | null = null;
  const np = (it.poll ?? []).find((p: any) => p.name === 'suggested_numplayers');
  if (np) {
    pollTotalVotes = int(np.totalvotes);
    poll = (np.results ?? []).map((r: any) => {
      const res: any[] = r.result ?? [];
      const v = (label: string) => int(res.find((x) => x.value === label)?.numvotes) ?? 0;
      return { numPlayers: String(r.numplayers), best: v('Best'), recommended: v('Recommended'), notRecommended: v('Not Recommended') };
    });
  }
  let pollSummaryBest: string | null = null;
  let pollSummaryRec: string | null = null;
  const ps = (it['poll-summary'] ?? []).find((p: any) => p.name === 'suggested_numplayers');
  if (ps) {
    for (const r of ps.result ?? []) {
      if (r.name === 'bestwith') pollSummaryBest = String(r.value);
      if (r.name === 'recommmendedwith' || r.name === 'recommendedwith') pollSummaryRec = String(r.value);
    }
  }

  let stats: BggThing['stats'] = null;
  const ratings = it.statistics?.ratings;
  if (ratings) {
    const ranks: any[] = ratings.ranks?.rank ?? [];
    const overall = ranks.find((r) => r.type === 'subtype');
    stats = {
      usersRated: int(attrVal(ratings.usersrated)),
      average: float(attrVal(ratings.average)),
      weight: float(attrVal(ratings.averageweight)),
      numWeights: int(attrVal(ratings.numweights)),
      rank: overall ? int(overall.value) : null,
      subdomainRanks: ranks.filter((r) => r.type === 'family').map((r) => ({
        name: String(r.name), friendlyName: String(r.friendlyname ?? r.name), value: int(r.value),
      })),
    };
  }

  let versions: BggVersion[] | null = null;
  if (it.versions) {
    versions = (it.versions.item ?? []).map((v: any) => {
      const vl: any[] = v.link ?? [];
      const vn: any[] = v.name ?? [];
      return {
        id: int(v.id) ?? 0,
        name: String((vn.find((n) => n.type === 'primary') ?? vn[0])?.value ?? ''),
        year: int(attrVal(v.yearpublished)),
        languages: vl.filter((l) => l.type === 'language').map((l) => String(l.value)),
        publishers: vl.filter((l) => l.type === 'boardgamepublisher').map((l) => String(l.value)),
      };
    });
  }

  const zeroToNull = (n: number | null) => (n === 0 ? null : n);
  return {
    id,
    type: String(it.type),
    primaryName: String(primary?.value ?? `BGG #${id}`),
    altNames: names.filter((n) => n.type === 'alternate').map((n) => String(n.value)),
    description: cleanDescription(text(it.description)),
    year: zeroToNull(int(attrVal(it.yearpublished))),
    image: text(it.image),
    thumbnail: text(it.thumbnail),
    minPlayers: zeroToNull(int(attrVal(it.minplayers))),
    maxPlayers: zeroToNull(int(attrVal(it.maxplayers))),
    playingTime: zeroToNull(int(attrVal(it.playingtime))),
    minPlaytime: zeroToNull(int(attrVal(it.minplaytime))),
    maxPlaytime: zeroToNull(int(attrVal(it.maxplaytime))),
    minAge: zeroToNull(int(attrVal(it.minage))),
    poll,
    pollTotalVotes,
    pollSummaryBest,
    pollSummaryRec,
    links,
    stats,
    versions,
  };
}
