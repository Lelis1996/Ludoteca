import type { DB } from '../dbtypes';
import { parseSearch, parseThings, xmlErrorMessage, type BggSearchItem, type BggThing } from './parse';

export class BggError extends Error {
  constructor(message: string, public code: 'not_configured' | 'auth' | 'unavailable' | 'rate_limited' | 'bad_response') {
    super(message);
  }
}

export interface BggClientOptions {
  db: DB;
  token: string | null;
  baseUrl: string;
  minIntervalMs: number;
  cacheTtlHours: number;
  fetchImpl?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
  maxRetries?: number;
}

const realSleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/**
 * Cliente da XML API2 do BGG.
 * - Exige token (Authorization: Bearer) — política do BGG desde 2025.
 * - Uma requisição por vez, com intervalo mínimo entre elas.
 * - Repetição com espera exponencial em 202/429/500/502/503/504.
 * - Cache em SQLite (tabela bgg_cache), usado também quando o BGG está fora do ar.
 */
export class BggClient {
  private queue: Promise<unknown> = Promise.resolve();
  private lastRequestAt = 0;
  private fetchImpl: typeof fetch;
  private sleep: (ms: number) => Promise<void>;
  public requestCount = 0;

  constructor(private o: BggClientOptions) {
    this.fetchImpl = o.fetchImpl ?? fetch;
    this.sleep = o.sleep ?? realSleep;
  }

  /** Troca o token (o app de celular guarda o token nas configurações). */
  setToken(token: string | null) {
    this.o.token = token?.trim() || null;
  }

  get configured(): boolean {
    return !!this.o.token;
  }

  private cacheGet(key: string, maxAgeHours: number | null): string | null {
    const row = this.o.db.prepare('SELECT body, fetched_at FROM bgg_cache WHERE key = ?').get(key) as { body: string; fetched_at: string } | undefined;
    if (!row) return null;
    if (maxAgeHours != null) {
      const age = (Date.now() - Date.parse(row.fetched_at + 'Z')) / 36e5;
      if (age > maxAgeHours) return null;
    }
    return row.body;
  }

  private cachePut(key: string, body: string) {
    this.o.db.prepare(`INSERT INTO bgg_cache (key, body, fetched_at) VALUES (?, ?, datetime('now'))
      ON CONFLICT(key) DO UPDATE SET body = excluded.body, fetched_at = excluded.fetched_at`).run(key, body);
  }

  /** Busca XML com cache. `force` ignora o cache fresco (mas ainda cai no cache antigo se o BGG falhar). */
  async getXml(path: string, params: Record<string, string>, opts: { force?: boolean } = {}): Promise<{ xml: string; fromCache: boolean; stale: boolean }> {
    const qs = new URLSearchParams(params).toString();
    const key = `${path}?${qs}`;
    if (!opts.force) {
      const fresh = this.cacheGet(key, this.o.cacheTtlHours);
      if (fresh) return { xml: fresh, fromCache: true, stale: false };
    }
    if (!this.o.token) {
      const old = this.cacheGet(key, null);
      if (old) return { xml: old, fromCache: true, stale: true };
      throw new BggError('BGG não configurado: defina BGG_API_TOKEN no arquivo .env (veja o README).', 'not_configured');
    }
    try {
      const xml = await this.enqueue(() => this.fetchWithRetry(`${this.o.baseUrl}/xmlapi2/${path}?${qs}`));
      this.cachePut(key, xml);
      return { xml, fromCache: false, stale: false };
    } catch (e) {
      const old = this.cacheGet(key, null);
      if (old && e instanceof BggError && e.code !== 'auth') return { xml: old, fromCache: true, stale: true };
      throw e;
    }
  }

  private enqueue<T>(fn: () => Promise<T>): Promise<T> {
    const run = this.queue.then(async () => {
      const wait = this.lastRequestAt + this.o.minIntervalMs - Date.now();
      if (wait > 0) await this.sleep(wait);
      try { return await fn(); } finally { this.lastRequestAt = Date.now(); }
    });
    this.queue = run.catch(() => undefined);
    return run;
  }

  private async fetchWithRetry(url: string): Promise<string> {
    const max = this.o.maxRetries ?? 5;
    let delay = Math.max(this.o.minIntervalMs, 1000);
    let lastErr: BggError | null = null;
    for (let attempt = 0; attempt <= max; attempt++) {
      let res: Response;
      try {
        this.requestCount++;
        res = await this.fetchImpl(url, {
          headers: {
            Authorization: `Bearer ${this.o.token}`,
            Accept: 'application/xml, text/xml',
            'User-Agent': 'Ludoteca/1.0 (gerenciador pessoal de coleção)',
          },
          signal: AbortSignal.timeout(30000),
        });
      } catch (e) {
        lastErr = new BggError(`Não foi possível conectar ao BGG (${(e as Error).message}).`, 'unavailable');
        await this.sleep(delay + Math.random() * 500);
        delay *= 2;
        continue;
      }
      if (res.status === 401 || res.status === 403) {
        throw new BggError('O BGG recusou o token (HTTP ' + res.status + '). Confira BGG_API_TOKEN e se a aplicação foi aprovada em boardgamegeek.com/applications.', 'auth');
      }
      if ([202, 429, 500, 502, 503, 504].includes(res.status)) {
        lastErr = new BggError(
          res.status === 429 ? 'Limite de requisições do BGG atingido.' : res.status === 202 ? 'O BGG ainda está preparando a resposta.' : `BGG indisponível (HTTP ${res.status}).`,
          res.status === 429 ? 'rate_limited' : 'unavailable',
        );
        const retryAfter = Number(res.headers.get('retry-after'));
        await this.sleep((Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : delay) + Math.random() * 500);
        delay *= 2;
        continue;
      }
      if (!res.ok) throw new BggError(`Resposta inesperada do BGG (HTTP ${res.status}).`, 'bad_response');
      const body = await res.text();
      if (!body.trim().startsWith('<')) throw new BggError('Resposta do BGG não é XML.', 'bad_response');
      const err = xmlErrorMessage(body);
      if (err) throw new BggError(`BGG: ${err}`, 'bad_response');
      return body;
    }
    throw lastErr ?? new BggError('BGG indisponível.', 'unavailable');
  }

  async search(query: string, types: string[] = ['boardgame', 'boardgameexpansion']): Promise<BggSearchItem[]> {
    const q = query.trim().replace(/\s+/g, ' ');
    if (!q) return [];
    const { xml } = await this.getXml('search', { query: q, type: types.join(',') });
    const items = parseSearch(xml);
    // a busca do BGG pode repetir um item (um por tipo); mantém o primeiro
    const seen = new Set<number>();
    return items.filter((i) => (seen.has(i.id) ? false : (seen.add(i.id), true)));
  }

  /** Busca itens por ID, em lotes de até 20 (limite do BGG). */
  async things(ids: number[], opts: { versions?: boolean; force?: boolean } = {}): Promise<Map<number, BggThing>> {
    const unique = [...new Set(ids)].sort((a, b) => a - b);
    const out = new Map<number, BggThing>();
    for (let i = 0; i < unique.length; i += 20) {
      const chunk = unique.slice(i, i + 20);
      const params: Record<string, string> = { id: chunk.join(','), stats: '1' };
      if (opts.versions) params.versions = '1';
      const { xml } = await this.getXml('thing', params, { force: opts.force });
      for (const t of parseThings(xml)) out.set(t.id, t);
    }
    return out;
  }

  async thing(id: number, opts: { versions?: boolean; force?: boolean } = {}): Promise<BggThing | null> {
    return (await this.things([id], opts)).get(id) ?? null;
  }
}
