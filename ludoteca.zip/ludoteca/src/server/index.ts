import { loadConfig } from './config';
import { createApp } from './app';

const config = loadConfig();
const { app, close } = createApp({ config });

const server = app.listen(config.port, config.host, () => {
  const url = `http://${config.host === '0.0.0.0' ? 'localhost' : config.host}:${config.port}`;
  console.log(`\n  Ludoteca rodando em ${url}`);
  console.log(`  Banco de dados: ${config.dbPath}`);
  console.log(`  BGG: ${config.bggToken ? 'token configurado' : 'SEM token (defina BGG_API_TOKEN no .env para buscar dados)'}`);
  console.log(`  Reconhecimento de fotos: ${config.anthropicApiKey && config.visionProvider !== 'ocr' && config.visionProvider !== 'none' ? `Claude (${config.visionModel})` : config.visionProvider === 'none' ? 'desativado' : 'OCR local (Tesseract)'}\n`);
});

const shutdown = () => {
  server.close(async () => {
    await close();
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 3000).unref();
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
