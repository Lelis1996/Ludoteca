import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import sharp from 'sharp';
import { AnthropicVision, OcrVision, type OcrWorker, type VisionImageOps } from './core';

export * from './core';

/** Operações de imagem com sharp (computador). */
export const nodeVisionOps: VisionImageOps = {
  async jpegBase64(image, maxSide) {
    const jpeg = await sharp(image).rotate().resize({ width: maxSide, height: maxSide, fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 85 }).toBuffer();
    return jpeg.toString('base64');
  },
  async forOcr(image, maxSide) {
    const { data, info } = await sharp(image).rotate().resize({ width: maxSide, height: maxSide, fit: 'inside', withoutEnlargement: true }).toBuffer({ resolveWithObject: true });
    return { width: info.width, height: info.height, rotated: (deg) => sharp(data).rotate(deg).greyscale().png().toBuffer() };
  },
};

function langDir(cacheDir: string): string {
  const dir = path.join(cacheDir, 'tessdata');
  fs.mkdirSync(dir, { recursive: true });
  const require = createRequire(import.meta.url);
  for (const code of ['eng', 'por']) {
    const target = path.join(dir, `${code}.traineddata.gz`);
    if (!fs.existsSync(target)) {
      const pkg = require(`@tesseract.js-data/${code}`);
      fs.copyFileSync(path.join(pkg.langPath, `${code}.traineddata.gz`), target);
    }
  }
  return dir;
}

/** OCR no computador, com os dados de idioma incluídos via npm (sem download). */
export function createNodeOcr(cacheDir: string): OcrVision {
  return new OcrVision(nodeVisionOps, async () => {
    const { createWorker } = await import('tesseract.js');
    return (await createWorker(['eng', 'por'], 1, { langPath: langDir(cacheDir), gzip: true, cachePath: path.join(cacheDir, 'tesscache') })) as unknown as OcrWorker;
  });
}

export function createNodeAnthropic(apiKey: string, model: string, fetchImpl?: typeof fetch): AnthropicVision {
  return new AnthropicVision(apiKey, model, nodeVisionOps, fetchImpl);
}
