import type { Database } from 'sql.js';
import type { DB, Statement } from '../server/dbtypes';

const norm = (params: unknown[]) => params.map((p) => {
  if (p === undefined) return null;
  if (typeof p === 'boolean') return p ? 1 : 0;
  if (typeof p === 'bigint') return Number(p);
  return p as any;
});

/** Adapta o sql.js (SQLite em WebAssembly) à mesma API usada no servidor. */
export function wrapSqlJs(raw: Database, onWrite: () => void): DB {
  let depth = 0;
  const lastId = () => Number(raw.exec('SELECT last_insert_rowid()')[0]?.values[0][0] ?? 0);
  const db: DB = {
    prepare(sql: string): Statement {
      return {
        run(...params) {
          const st = raw.prepare(sql);
          try { st.run(norm(params)); } finally { st.free(); }
          const changes = raw.getRowsModified();
          const id = lastId();
          onWrite();
          return { changes, lastInsertRowid: id };
        },
        get(...params) {
          const st = raw.prepare(sql);
          try {
            st.bind(norm(params));
            return st.step() ? st.getAsObject() : undefined;
          } finally { st.free(); }
        },
        all(...params) {
          const st = raw.prepare(sql);
          const out: unknown[] = [];
          try {
            st.bind(norm(params));
            while (st.step()) out.push(st.getAsObject());
          } finally { st.free(); }
          return out;
        },
      };
    },
    exec(sql: string) {
      raw.exec(sql);
      onWrite();
    },
    transaction<F extends (...args: any[]) => any>(fn: F): F {
      return ((...args: any[]) => {
        const level = depth++;
        const sp = `sp_${level}`;
        raw.exec(level === 0 ? 'BEGIN' : `SAVEPOINT ${sp}`);
        try {
          const r = fn(...args);
          raw.exec(level === 0 ? 'COMMIT' : `RELEASE ${sp}`);
          return r;
        } catch (e) {
          raw.exec(level === 0 ? 'ROLLBACK' : `ROLLBACK TO ${sp}; RELEASE ${sp}`);
          throw e;
        } finally {
          depth--;
          onWrite();
        }
      }) as F;
    },
    close() { raw.close(); },
  };
  return db;
}
