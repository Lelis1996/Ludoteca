import { Capacitor, CapacitorHttp } from '@capacitor/core';
import { fromBase64 } from './bytes';

/**
 * No app Android, as requisições saem pela camada nativa (sem bloqueio de CORS),
 * o que permite falar direto com o BGG e com a API da Anthropic.
 */
export const appFetch: typeof fetch = (input, init) => fetch(input, init);

export async function httpGetBytes(url: string): Promise<Uint8Array> {
  if (Capacitor.isNativePlatform()) {
    const r = await CapacitorHttp.get({ url, responseType: 'blob' });
    if (r.status >= 400) throw new Error(`HTTP ${r.status}`);
    return fromBase64(String(r.data));
  }
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return new Uint8Array(await res.arrayBuffer());
}
