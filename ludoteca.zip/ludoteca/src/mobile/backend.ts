/**
 * "Servidor" que roda dentro do app de celular: o mesmo código das rotas do
 * computador, com SQLite em WebAssembly e arquivos guardados no aparelho.
 */
import initSqlJs from 'sql.js';
import wasmUrl from 'sql.js/dist/sql-wasm.wasm?url';
import { App } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { migrate, seedBasics } from '../server/core';
import { createCore, errorResponse, matchRoute, type UploadedFile } from '../server/routes';
import { applySeedCollection } from '../server/services/seed';
import { AnthropicVision, type OcrVision } from '../server/vision/core';
import { wrapSqlJs } from './sqljsDb';
import { loadDbBytes, saveDbBytes } from './persist';
import { browserImageStore, browserMediaStore, browserVisionOps } from './media';
import { appFetch } from './http';
import { createBrowserOcr } from './ocr';

export interface LocalResponse { status: number; data: any; download?: { filename: string; type: string } }
export interface LocalBackend {
  dispatch(method: string, url: string, body?: unknown): Promise<LocalResponse>;
  flush(): Promise<void>;
  exportDb(): Uint8Array;
}

const DEFAULT_MODEL = 'claude-sonnet-5-5';

export async function startBackend(): Promise<LocalBackend> {
  const SQL = await initSqlJs({ locateFile: () => wasmUrl });
  const bytes = await loadDbBytes();
  const raw = bytes ? new SQL.Database(bytes) : new SQL.Database();

  // grava o banco no aparelho logo depois de cada alteração (agrupando alterações próximas)
  let dirty = false;
  let timer: ReturnType<typeof setTimeout> | null = null;
  let saving: Promise<void> = Promise.resolve();
  const flush = async () => {
    if (timer) { clearTimeout(timer); timer = null; }
    if (!dirty) return saving;
    dirty = false;
    const data = raw.export();
    raw.exec('PRAGMA foreign_keys = ON'); // export() desliga as chaves estrangeiras
    saving = saving.then(() => saveDbBytes(data)).catch((e) => { console.error('Falha ao salvar o banco', e); dirty = true; });
    return saving;
  };
  const onWrite = () => {
    dirty = true;
    if (!timer) timer = setTimeout(() => { timer = null; void flush(); }, 400);
  };

  const db = wrapSqlJs(raw, onWrite);
  raw.exec('PRAGMA foreign_keys = ON');
  migrate(db);
  seedBasics(db);
  applySeedCollection(db);
  await flush();

  let ocr: OcrVision | null = null;
  const core = createCore({
    db,
    bggToken: null,
    bggBaseUrl: (import.meta.env.VITE_BGG_BASE_URL as string | undefined) || 'https://boardgamegeek.com',
    bggMinIntervalMs: Number(import.meta.env.VITE_BGG_MIN_INTERVAL_MS) || 2500,
    bggCacheTtlHours: 24 * 7,
    fetchImpl: appFetch,
    images: browserImageStore(db),
    media: browserMediaStore(db),
    embedded: true,
    dbLabel: 'Neste aparelho',
    defaultVisionModel: DEFAULT_MODEL,
    provider: (s) => {
      if (s.anthropicKey) return new AnthropicVision(s.anthropicKey, s.visionModel || DEFAULT_MODEL, browserVisionOps, appFetch, true);
      ocr ??= createBrowserOcr();
      return ocr;
    },
  });

  // salva ao sair do app ou trocar de aba
  if (Capacitor.isNativePlatform()) {
    void App.addListener('pause', () => { void flush(); });
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') void flush(); });

  return {
    async dispatch(method, url, body) {
      const u = new URL(url, 'http://local');
      const m = matchRoute(core.routes, method.toUpperCase(), u.pathname);
      if (!m) return { status: 404, data: { error: 'Rota não encontrada.' } };
      let reqBody: any = body;
      let files: UploadedFile[] | undefined;
      if (typeof FormData !== 'undefined' && body instanceof FormData) {
        reqBody = {};
        files = [];
        for (const [k, v] of body.entries()) {
          if (typeof v === 'string') reqBody[k] = v;
          else files.push({ originalname: v.name, buffer: new Uint8Array(await v.arrayBuffer()) });
        }
      }
      try {
        const data = await m.route.handler({ params: m.params, query: Object.fromEntries(u.searchParams), body: reqBody, files });
        return {
          status: m.route.status ?? 200,
          data,
          download: m.route.download ? { filename: m.route.download.filename(), type: m.route.download.type } : undefined,
        };
      } catch (e) {
        const r = errorResponse(e);
        return { status: r.status, data: r.body };
      }
    },
    flush,
    exportDb: () => {
      const d = raw.export();
      raw.exec('PRAGMA foreign_keys = ON');
      return d;
    },
  };
}
