import { createWorker } from 'tesseract.js';
import { OcrVision, type OcrWorker } from '../server/vision/core';
import { browserVisionOps } from './media';

/**
 * OCR no aparelho. Os arquivos do Tesseract (worker, núcleo WebAssembly e idiomas)
 * vão dentro do app em /tesseract/ — nada é baixado da internet.
 */
export function createBrowserOcr(): OcrVision {
  const base = new URL('tesseract/', document.baseURI).href;
  return new OcrVision(browserVisionOps, async () => (await createWorker(['eng', 'por'], 1, {
    workerPath: `${base}worker.min.js`,
    corePath: base,
    langPath: base,
    gzip: true,
    workerBlobURL: false,
    cacheMethod: 'none',
  })) as unknown as OcrWorker);
}
