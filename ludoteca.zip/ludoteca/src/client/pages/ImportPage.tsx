import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../lib/api';
import { useStore } from '../lib/store';
import type { LocationType } from '../../shared/types';
import { LOCATION_LABELS } from '../../shared/domain';
import { Icon } from '../components/Icon';
import { Confirm, Spinner } from '../components/ui';

const PROVIDER_LABEL: Record<string, string> = {
  anthropic: 'Claude (visão computacional)', ocr: 'OCR local (Tesseract)', none: 'Sem reconhecimento automático', fake: 'Simulado',
};

export function ImportPage({ batchId, go }: { batchId: number | null; go: (to: string) => void }) {
  return batchId ? <Review id={batchId} go={go} /> : <NewImport go={go} />;
}

function NewImport({ go }: { go: (to: string) => void }) {
  const { owners, status, toast } = useStore();
  const me = owners.find((o) => o.isMe);
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [drag, setDrag] = useState(false);
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const [d, setD] = useState({ ownerId: me?.id ?? null as number | null, locationType: 'with_me' as LocationType, locationPerson: '', ownershipStatus: 'owned' });
  const inputRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  useEffect(() => { api.imports().then(setHistory).catch(() => undefined); }, []);
  useEffect(() => {
    const urls = files.map((f) => URL.createObjectURL(f));
    setPreviews(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
  }, [files]);
  useEffect(() => { if (me && d.ownerId == null) setD((x) => ({ ...x, ownerId: me.id })); }, [me]); // eslint-disable-line react-hooks/exhaustive-deps

  const addFiles = (list: FileList | null) => {
    if (!list) return;
    const imgs = [...list].filter((f) => f.type.startsWith('image/') || /\.(jpe?g|png|webp|heic|heif)$/i.test(f.name));
    if (imgs.length < list.length) toast('Alguns arquivos foram ignorados por não serem imagens.', 'error');
    setFiles((f) => [...f, ...imgs].slice(0, 30));
  };

  const start = async () => {
    if (!files.length) return;
    setBusy(true);
    try {
      const form = new FormData();
      files.forEach((f) => form.append('photos', f));
      if (d.ownerId != null) form.append('ownerId', String(d.ownerId));
      form.append('locationType', d.locationType);
      if (d.locationPerson) form.append('locationPerson', d.locationPerson);
      form.append('ownershipStatus', d.ownershipStatus);
      const b = await api.createImport(form);
      go(`/importar/${b.id}`);
    } catch (e) { toast((e as Error).message, 'error'); } finally { setBusy(false); }
  };

  const provider = status?.visionProvider ?? 'none';
  return (
    <div className="page">
      <div className="page-head"><h2>Importar por fotos</h2></div>
      <div className={`notice ${provider === 'anthropic' ? 'info' : 'warn'}`}>
        <Icon name="info" />
        <div>
          Reconhecimento: <b>{PROVIDER_LABEL[provider]}</b>{status?.visionModel ? ` (${status.visionModel})` : ''}.{' '}
          {provider === 'ocr' && 'O OCR local lê textos grandes e legíveis (capas de frente funcionam melhor que lombadas). Para estantes inteiras, configure ANTHROPIC_API_KEY — veja Configurações.'}
          {provider === 'none' && 'Você ainda poderá revisar as fotos e informar os jogos manualmente.'}
          {!status?.bggConfigured && ' O BGG não está configurado: as correspondências serão feitas só com jogos já cadastrados.'}
          {' '}Nada é adicionado à coleção antes da sua revisão.
        </div>
      </div>
      <div className={`dropzone${drag ? ' drag' : ''}`} role="button" tabIndex={0}
        onClick={() => inputRef.current?.click()} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') inputRef.current?.click(); }}
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); addFiles(e.dataTransfer.files); }}>
        <Icon name="camera" size={34} />
        <h3>Arraste fotos aqui ou clique para escolher</h3>
        <div className="hint">Caixas, estantes, prateleiras ou pilhas. Até 30 fotos por vez (máx. 30 MB cada).</div>
        <input ref={inputRef} type="file" accept="image/*" multiple hidden onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} data-testid="photo-input" />
        <div className="btn-row" style={{ justifyContent: 'center', marginTop: 14 }} onClick={(e) => e.stopPropagation()}>
          <button type="button" className="btn primary" onClick={() => cameraRef.current?.click()}><Icon name="camera" size={15} />Tirar foto</button>
          <button type="button" className="btn" onClick={() => inputRef.current?.click()}><Icon name="upload" size={15} />Escolher da galeria</button>
        </div>
        <input ref={cameraRef} type="file" accept="image/*" capture="environment" hidden onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />
        {previews.length > 0 && <div className="thumbs">{previews.map((u, i) => <img key={u} src={u} alt={files[i]?.name} />)}</div>}
      </div>
      {files.length > 0 && (
        <div className="card-panel" style={{ marginTop: 18 }}>
          <h3>Padrões para os jogos desta importação</h3>
          <div className="grid-4">
            <label className="field"><span>Status</span>
              <select className="input" value={d.ownershipStatus} onChange={(e) => setD({ ...d, ownershipStatus: e.target.value })}>
                <option value="owned">Possuo</option><option value="wishlist">Quero comprar</option><option value="want_to_try">Quero experimentar</option><option value="reference">Só consulta</option>
              </select>
            </label>
            <label className="field"><span>Proprietário</span>
              <select className="input" value={d.ownerId ?? ''} onChange={(e) => setD({ ...d, ownerId: e.target.value ? Number(e.target.value) : null })}>
                {owners.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
              </select>
            </label>
            <label className="field"><span>Onde estão</span>
              <select className="input" value={d.locationType} onChange={(e) => setD({ ...d, locationType: e.target.value as LocationType })}>
                {(Object.keys(LOCATION_LABELS) as LocationType[]).map((k) => <option key={k} value={k}>{LOCATION_LABELS[k]}</option>)}
              </select>
            </label>
            {['with_friend', 'lent_out', 'borrowed'].includes(d.locationType) && (
              <label className="field"><span>Com quem</span><input className="input" value={d.locationPerson} onChange={(e) => setD({ ...d, locationPerson: e.target.value })} /></label>
            )}
          </div>
          <div className="btn-row">
            <button className="btn primary" onClick={start} disabled={busy}>{busy ? <Spinner /> : <Icon name="search" />}Analisar {files.length} foto(s)</button>
            <button className="btn ghost" onClick={() => setFiles([])}>Limpar</button>
          </div>
        </div>
      )}
      {history.length > 0 && (
        <div style={{ marginTop: 24 }}>
          <h3 style={{ marginBottom: 10 }}>Importações anteriores</h3>
          <div className="list">
            {history.map((h) => (
              <a key={h.id} className="row" href={`#/importar/${h.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                <span className="grow">Importação #{h.id} · {new Date(h.createdAt.replace(' ', 'T') + 'Z').toLocaleString('pt-BR')}</span>
                <span className="hint">{h.photos} foto(s) · {h.candidates} detectado(s) · {h.added} adicionado(s)</span>
                <span className={`badge ${h.status === 'done' ? 'ok' : h.status === 'review' ? 'warn' : ''}`}>{h.status === 'done' ? 'Concluída' : h.status === 'review' ? 'Aguardando revisão' : h.status === 'processing' ? 'Analisando' : h.status}</span>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Review({ id, go }: { id: number; go: (to: string) => void }) {
  const { owners, reload, toast } = useStore();
  const [b, setB] = useState<any | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [committing, setCommitting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [d, setD] = useState<any | null>(null);

  const load = useCallback(async () => {
    try {
      const x = await api.importBatch(id);
      setB(x);
      setD((prev: any) => prev ?? { ownerId: x.ownerId, locationType: x.locationType, locationPerson: x.locationPerson ?? '', ownershipStatus: x.ownershipStatus });
      setErr(null);
    } catch (e) { setErr((e as Error).message); }
  }, [id]);
  useEffect(() => { setB(null); setD(null); void load(); }, [load]);
  useEffect(() => {
    if (b?.status !== 'processing') return;
    const t = setInterval(load, 1500);
    return () => clearInterval(t);
  }, [b?.status, load]);

  if (err) return <div className="page"><div className="notice danger">{err}</div></div>;
  if (!b || !d) return <div className="page"><Spinner /></div>;

  const isList = b.source === 'list';
  const all = b.photos.flatMap((p: any) => p.candidates);
  const confirmed = all.filter((c: any) => c.status === 'confirmed');
  const pending = all.filter((c: any) => c.status === 'pending');
  const highConf = pending.filter((c: any) => c.selectedBggId && (c.confidence ?? 0) >= 0.75 && !c.warnings.some((w: string) => /duplicata|Mais de um|Confira|independente/.test(w)));

  const patch = async (cid: number, p: Record<string, unknown>) => {
    try { await api.updateCandidate(cid, p); await load(); } catch (e) { toast((e as Error).message, 'error'); }
  };
  const commit = async () => {
    setCommitting(true);
    try {
      const r = await api.commitImport(id, {
        ownerId: d.ownerId, locationType: d.locationType, ownershipStatus: d.ownershipStatus,
        locationPerson: ['with_friend', 'lent_out', 'borrowed'].includes(d.locationType) ? d.locationPerson || null : null,
      });
      await load(); await reload();
      toast(isList
        ? `${r.updated} jogo(s) vinculado(s) ao BGG.${r.errors.length ? ` ${r.errors.length} erro(s): ${r.errors.slice(0, 2).join('; ')}` : ''}`
        : `${r.added} adicionado(s), ${r.updated} atualizado(s), ${r.duplicates} já existiam.${r.errors.length ? ` ${r.errors.length} erro(s).` : ''}`, r.errors.length ? 'error' : 'ok');
    } catch (e) { toast((e as Error).message, 'error'); } finally { setCommitting(false); }
  };

  return (
    <div className="page" style={{ maxWidth: 1240 }}>
      <div className="page-head">
        <a className="btn ghost" href="#/importar">← Importações</a>
        <h2>{isList ? 'Vincular jogos ao BGG' : `Revisão da importação #${id}`}</h2>
        {!isList && <span className="hint">via {PROVIDER_LABEL[b.provider] ?? b.provider}</span>}
        <div className="spacer" />
        {b.status === 'processing' && <span className="badge warn"><Spinner /> {isList ? `Buscando no BGG… ${all.filter((c: any) => c.matches.length || c.warnings.length || c.error).length}/${all.length}` : 'Analisando fotos…'}</span>}
        {b.status === 'done' && <span className="badge ok">Concluída</span>}
        {highConf.length > 0 && <button className="btn" onClick={async () => { for (const c of highConf) await api.updateCandidate(c.id, { status: 'confirmed' }); await load(); }}>Confirmar {highConf.length} de alta confiança</button>}
        <button className="btn ghost danger" onClick={() => setConfirmDelete(true)}><Icon name="trash" size={14} />Descartar</button>
      </div>

      {isList && <div className="notice info"><Icon name="info" />Confira a correspondência sugerida para cada jogo e confirme. Ao vincular, o app busca os dados oficiais (jogadores, tempo, peso, capa, expansões) e mantém proprietário, local e notas. O BGG limita a velocidade das consultas, então a busca leva alguns minutos.</div>}
      {b.photos.map((p: any) => <PhotoBlock key={p.id} p={p} patch={patch} reload={load} processing={b.status === 'processing'} list={isList} />)}

      <div className="commit-bar">
        {!isList && <>
        <label className="field"><span>Status</span>
          <select className="input" value={d.ownershipStatus} onChange={(e) => setD({ ...d, ownershipStatus: e.target.value })}>
            <option value="owned">Possuo</option><option value="wishlist">Quero comprar</option><option value="want_to_try">Quero experimentar</option><option value="reference">Só consulta</option>
          </select>
        </label>
        <label className="field"><span>Proprietário</span>
          <select className="input" value={d.ownerId ?? ''} onChange={(e) => setD({ ...d, ownerId: e.target.value ? Number(e.target.value) : null })}>
            {owners.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
        </label>
        <label className="field"><span>Onde estão</span>
          <select className="input" value={d.locationType} onChange={(e) => setD({ ...d, locationType: e.target.value })}>
            {(Object.keys(LOCATION_LABELS) as LocationType[]).map((k) => <option key={k} value={k}>{LOCATION_LABELS[k]}</option>)}
          </select>
        </label>
        {['with_friend', 'lent_out', 'borrowed'].includes(d.locationType) && (
          <label className="field"><span>Com quem</span><input className="input" value={d.locationPerson} onChange={(e) => setD({ ...d, locationPerson: e.target.value })} /></label>
        )}
        </>}
        <div className="spacer" style={{ flex: 1 }} />
        <div className="hint">{confirmed.length} confirmado(s) · {pending.length} pendente(s)</div>
        <button className="btn primary" disabled={!confirmed.length || committing || b.status === 'processing'} onClick={commit}>
          {committing ? <Spinner /> : <Icon name="check" />}{isList ? `Vincular ${confirmed.length}` : `Adicionar ${confirmed.length} à coleção`}
        </button>
        {b.status === 'done' && <a className="btn" href="#/">Ver biblioteca</a>}
      </div>
      {confirmDelete && <Confirm title="Descartar importação" danger confirmLabel="Descartar" text="As fotos e a revisão desta importação serão apagadas. Jogos já adicionados à coleção continuam lá."
        onClose={() => setConfirmDelete(false)} onConfirm={async () => { await api.deleteImport(id); go('/importar'); }} />}
    </div>
  );
}

function PhotoBlock({ p, patch, reload, processing, list }: { p: any; patch: (id: number, p: Record<string, unknown>) => Promise<void>; reload: () => Promise<void>; processing: boolean; list?: boolean }) {
  const { toast } = useStore();
  const [hover, setHover] = useState<number | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [adding, setAdding] = useState(false);
  const [showIgnored, setShowIgnored] = useState(false);
  const visible = p.candidates.filter((c: any) => showIgnored || c.status !== 'ignored');
  const ignored = p.candidates.filter((c: any) => c.status === 'ignored').length;
  if (list) {
    return (
      <div>
        {visible.map((c: any) => <Candidate key={c.id} c={c} patch={patch} reload={reload} onHover={setHover} list />)}
        {ignored > 0 && <button className="btn ghost small" onClick={() => setShowIgnored(!showIgnored)}>{showIgnored ? 'Ocultar' : 'Mostrar'} {ignored} pulado(s)</button>}
      </div>
    );
  }
  return (
    <div className="photo-block">
      <div>
        <div className="ph-img">
          <img src={p.url} alt={p.filename} />
          {p.candidates.filter((c: any) => c.bbox && c.status !== 'ignored').map((c: any) => (
            <div key={c.id} className={`bbox${hover != null && hover !== c.id ? ' dim' : ''}`}
              style={{ left: `${c.bbox[0] * 100}%`, top: `${c.bbox[1] * 100}%`, width: `${c.bbox[2] * 100}%`, height: `${c.bbox[3] * 100}%` }} />
          ))}
        </div>
        <div className="hint" style={{ marginTop: 6 }}>{p.filename}</div>
        {['pending', 'analyzing', 'matching'].includes(p.status) && <div className="hint"><Spinner /> {p.status === 'matching' ? 'Procurando no BGG…' : 'Analisando…'}</div>}
        {p.error && <div className={p.status === 'error' ? 'error-text' : 'hint'}>{p.error}</div>}
      </div>
      <div>
        {!processing && p.candidates.length === 0 && <div className="hint" style={{ marginBottom: 10 }}>Nenhum jogo identificado nesta foto.</div>}
        {visible.map((c: any) => <Candidate key={c.id} c={c} patch={patch} reload={reload} onHover={setHover} />)}
        {ignored > 0 && <button className="btn ghost small" onClick={() => setShowIgnored(!showIgnored)}>{showIgnored ? 'Ocultar' : 'Mostrar'} {ignored} ignorado(s)</button>}
        <form className="btn-row" style={{ marginTop: 8 }} onSubmit={async (e) => {
          e.preventDefault();
          if (!newTitle.trim()) return;
          setAdding(true);
          try { await api.addCandidate(p.id, newTitle.trim()); setNewTitle(''); await reload(); } catch (err) { toast((err as Error).message, 'error'); } finally { setAdding(false); }
        }}>
          <input className="input" style={{ flex: 1, minWidth: 180 }} placeholder="Faltou algum jogo nesta foto? Digite o nome" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} aria-label="Adicionar jogo não detectado" />
          <button className="btn" disabled={adding || !newTitle.trim()}>{adding ? <Spinner /> : <Icon name="plus" size={14} />}Adicionar</button>
        </form>
      </div>
    </div>
  );
}

function Candidate({ c, patch, reload, onHover, list }: { c: any; patch: (id: number, p: Record<string, unknown>) => Promise<void>; reload: () => Promise<void>; onHover: (id: number | null) => void; list?: boolean }) {
  const { toast } = useStore();
  const [title, setTitle] = useState(c.detectedTitle);
  const [searching, setSearching] = useState(false);
  const locked = c.status === 'added';
  const pct = Math.round((c.confidence ?? 0) * 100);
  const research = async () => {
    setSearching(true);
    try { await api.searchCandidate(c.id, title); await reload(); } catch (e) { toast((e as Error).message, 'error'); } finally { setSearching(false); }
  };
  const selected = c.matches.find((m: any) => m.bggId === c.selectedBggId);
  return (
    <div className={`cand ${c.status}${list ? ' list' : ''}`} onMouseEnter={() => onHover(c.id)} onMouseLeave={() => onHover(null)}>
      {!list && (c.crop ? <img className="crop" src={c.crop} alt="Recorte da caixa" /> : <div className="crop" />)}
      <div style={{ minWidth: 0 }}>
        <div className="btn-row" style={{ justifyContent: 'space-between' }}>
          <form className="btn-row" style={{ flex: 1, minWidth: 200 }} onSubmit={(e) => { e.preventDefault(); void research(); }}>
            <input className="input" style={{ flex: 1, fontWeight: 600 }} value={title} disabled={locked} onChange={(e) => setTitle(e.target.value)} aria-label="Título identificado" />
            {!locked && <button className="btn small" disabled={searching}>{searching ? <Spinner /> : <Icon name="search" size={13} />}Buscar de novo</button>}
          </form>
          <span className="conf" title="Confiança combinada: leitura da imagem × semelhança do nome">
            Confiança <span className="bar"><i style={{ width: `${pct}%`, background: pct >= 75 ? 'var(--ok)' : pct >= 45 ? 'var(--warn)' : 'var(--danger)' }} /></span>{pct}%
          </span>
        </div>
        {!list && c.detectedText && c.detectedText !== c.detectedTitle && <div className="hint" style={{ marginTop: 4 }}>Lido na imagem: {c.detectedText}</div>}
        {c.expansionGuess && <div className="hint">Parece expansão{c.baseGuess ? ` de ${c.baseGuess}` : ''}.</div>}
        {c.warnings.length > 0 && <div className="warnings">{c.warnings.map((w: string, i: number) => <div key={i}>⚠ {w}</div>)}</div>}
        {c.error && <div className="error-text">{c.error}</div>}
        {!locked && c.matches.length > 0 && (
          <div className="match-list" role="radiogroup" aria-label="Correspondências">
            {c.matches.slice(0, 5).map((m: any) => (
              <div key={`${m.source}-${m.bggId}-${m.inCollectionGameId}`} role="radio" aria-checked={c.selectedBggId === m.bggId} tabIndex={0}
                className={`match${c.selectedBggId === m.bggId ? ' sel' : ''}`}
                onClick={() => m.source === 'bgg' && patch(c.id, { selectedBggId: c.selectedBggId === m.bggId ? null : m.bggId })}
                onKeyDown={(e) => { if (e.key === 'Enter' && m.source === 'bgg') void patch(c.id, { selectedBggId: m.bggId }); }}>
                <span>{c.selectedBggId === m.bggId ? '◉' : '○'}</span>
                {m.thumb ? <img src={m.thumb} alt="" loading="lazy" /> : <div className="ph" />}
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 600 }}>{m.primaryName ?? m.name}{m.year ? <span className="muted"> ({m.year})</span> : ''}</div>
                  <div className="hint">
                    {m.type === 'boardgameexpansion' ? `Expansão${m.isExpansionOf?.length ? ` de ${m.isExpansionOf.map((x: any) => x.name).join(', ')}` : ''}` : 'Jogo'}
                    {m.nameType === 'alternate' && m.primaryName && m.primaryName !== m.name ? ` · encontrado como “${m.name}”` : ''}
                    {m.source === 'local' ? ' · já cadastrado (sem BGG)' : ` · BGG #${m.bggId}`}
                    {m.inCollectionGameId && m.source === 'bgg' ? ' · já cadastrado' : ''}
                  </div>
                </div>
                <span className="hint">{Math.round((m.similarity ?? 0) * 100)}%</span>
              </div>
            ))}
          </div>
        )}
        <div className="btn-row" style={{ marginTop: 10 }}>
          {c.status === 'added' ? (
            <span className="badge info">{c.error ?? (list ? 'Vinculado ao BGG' : 'Adicionado à coleção')}</span>
          ) : c.status === 'confirmed' ? (
            <>
              <span className="badge ok">✓ Confirmado{selected ? `: ${selected.primaryName ?? selected.name}` : list ? ' — fica sem vínculo' : ' como cadastro manual'}</span>
              <button className="btn small ghost" onClick={() => patch(c.id, { status: 'pending' })}>Desfazer</button>
            </>
          ) : c.status === 'ignored' ? (
            <button className="btn small" onClick={() => patch(c.id, { status: 'pending' })}>Restaurar</button>
          ) : (
            <>
              {(!list || c.selectedBggId) && (
                <button className="btn small primary" onClick={() => patch(c.id, { status: 'confirmed', detectedTitle: title })}>
                  <Icon name="check" size={13} />{c.selectedBggId ? 'Confirmar' : 'Confirmar como cadastro manual'}
                </button>
              )}
              <button className="btn small ghost" onClick={() => patch(c.id, { status: 'ignored' })}>{list ? 'Pular' : 'Ignorar'}</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
