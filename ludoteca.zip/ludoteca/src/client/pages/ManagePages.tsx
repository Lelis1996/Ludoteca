import { useEffect, useRef, useState } from 'react';
import { api, EMBEDDED } from '../lib/api';
import { exportCollection } from '../lib/files';
import { useStore } from '../lib/store';
import type { Owner, Settings, Tag } from '../../shared/types';
import { DEFAULT_SETTINGS } from '../../shared/domain';
import { Icon } from '../components/Icon';
import { Confirm, ownerColor } from '../components/ui';

const PALETTE = ['#60a5fa', '#4ade80', '#c084fc', '#f472b6', '#fb923c', '#facc15', '#2dd4bf', '#f87171'];

export function OwnersPage() {
  const { owners, reloadOwners, reloadGames, toast } = useStore();
  const [name, setName] = useState('');
  const [color, setColor] = useState(PALETTE[owners.length % PALETTE.length]);
  const [del, setDel] = useState<Owner | null>(null);
  const create = async () => {
    if (!name.trim()) return;
    try { await api.createOwner({ name: name.trim(), color }); setName(''); setColor(PALETTE[(owners.length + 1) % PALETTE.length]); await reloadOwners(); toast('Proprietário adicionado.'); }
    catch (e) { toast((e as Error).message, 'error'); }
  };
  return (
    <div className="page">
      <div className="page-head"><h2>Proprietários</h2></div>
      <p className="hint">A cor de cada proprietário pinta o nome dos jogos dele na biblioteca. Cores muito escuras são clareadas automaticamente para manter a leitura.</p>
      <div className="list">
        {owners.map((o) => <OwnerRow key={o.id} o={o} onDelete={() => setDel(o)} />)}
      </div>
      <form className="card-panel" style={{ marginTop: 18 }} onSubmit={(e) => { e.preventDefault(); void create(); }}>
        <h3>Adicionar amigo / proprietário</h3>
        <div className="btn-row">
          <input className="color-input" type="color" value={color} onChange={(e) => setColor(e.target.value)} aria-label="Cor" />
          <input className="input" style={{ flex: 1, minWidth: 180 }} placeholder="Nome (ex.: Fulano)" value={name} onChange={(e) => setName(e.target.value)} aria-label="Nome do proprietário" />
          <button className="btn primary" disabled={!name.trim()}><Icon name="plus" />Adicionar</button>
        </div>
        <div className="btn-row">{PALETTE.map((c) => <button type="button" key={c} className="owner-dot" style={{ background: c, width: 22, height: 22, border: c === color ? '2px solid #fff' : 0, cursor: 'pointer' }} onClick={() => setColor(c)} aria-label={`Cor ${c}`} />)}</div>
      </form>
      {del && (
        <Confirm title={`Excluir ${del.name}`} danger confirmLabel="Excluir"
          text={<>Os {del.gameCount ?? 0} jogo(s) de {del.name} passarão a pertencer a “{owners.find((o) => o.isMe)?.name}”. Se preferir, antes mude o proprietário desses jogos na ficha de cada um.</>}
          onClose={() => setDel(null)}
          onConfirm={async () => { await api.deleteOwner(del.id); await reloadOwners(); await reloadGames(); toast('Proprietário excluído.'); }} />
      )}
    </div>
  );
}

function OwnerRow({ o, onDelete }: { o: Owner; onDelete: () => void }) {
  const { reloadOwners, toast } = useStore();
  const [name, setName] = useState(o.name);
  const [color, setColor] = useState(o.color);
  const dirty = name !== o.name || color !== o.color;
  const save = async () => {
    try { await api.updateOwner(o.id, { name: name.trim(), color }); await reloadOwners(); toast('Salvo.'); } catch (e) { toast((e as Error).message, 'error'); }
  };
  return (
    <div className="row">
      <input className="color-input" type="color" value={color} onChange={(e) => setColor(e.target.value)} aria-label={`Cor de ${o.name}`} />
      <input className="input grow" value={name} onChange={(e) => setName(e.target.value)} aria-label="Nome" style={{ flex: 1 }} />
      <span className="game-name" style={{ color: ownerColor({ ...o, color }), fontSize: 15 }}>Exemplo de jogo</span>
      <span className="hint">{o.gameCount ?? 0} jogo(s){o.isMe ? ' · você' : ''}</span>
      {dirty && <button className="btn small primary" onClick={save}>Salvar</button>}
      {!o.isMe && <button className="btn small ghost danger" onClick={onDelete} aria-label={`Excluir ${o.name}`}><Icon name="trash" size={14} /></button>}
    </div>
  );
}

const GROUPS: [string, string][] = [['style', 'Estilo e experiência'], ['mechanic', 'Mecânicas'], ['interaction', 'Interação'], ['luck', 'Sorte'], ['duration', 'Duração'], ['custom', 'Personalizadas']];

export function TagsPage() {
  const { tags, reloadTags, reloadGames, toast } = useStore();
  const [name, setName] = useState('');
  const [grp, setGrp] = useState('custom');
  const [del, setDel] = useState<Tag | null>(null);
  return (
    <div className="page">
      <div className="page-head"><h2>Etiquetas</h2></div>
      <div className="notice info"><Icon name="info" />
        <div>Algumas etiquetas são aplicadas automaticamente a partir de mecânicas/categorias oficiais do BGG (linha contínua) ou inferidas pela aplicação (linha tracejada). Etiquetas subjetivas — interação, sorte, “Eurogame” — você aplica na ficha de cada jogo.</div>
      </div>
      <form className="card-panel" onSubmit={async (e) => {
        e.preventDefault();
        if (!name.trim()) return;
        try { await api.createTag({ name: name.trim(), grp }); setName(''); await reloadTags(); toast('Etiqueta criada.'); } catch (err) { toast((err as Error).message, 'error'); }
      }}>
        <div className="btn-row">
          <input className="input" style={{ flex: 1, minWidth: 180 }} placeholder="Nova etiqueta" value={name} onChange={(e) => setName(e.target.value)} />
          <select className="input" style={{ width: 'auto' }} value={grp} onChange={(e) => setGrp(e.target.value)}>{GROUPS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
          <button className="btn primary" disabled={!name.trim()}><Icon name="plus" />Criar</button>
        </div>
      </form>
      {GROUPS.map(([g, label]) => {
        const list = tags.filter((t) => t.grp === g);
        if (!list.length) return null;
        return (
          <div key={g} style={{ marginBottom: 18 }}>
            <h3 style={{ fontSize: 17, marginBottom: 8 }}>{label}</h3>
            <div className="list">{list.map((t) => <TagRow key={t.id} t={t} onDelete={() => setDel(t)} />)}</div>
          </div>
        );
      })}
      {del && <Confirm title="Excluir etiqueta" danger confirmLabel="Excluir" text={<>Excluir “{del.name}”? Ela será removida de {del.gameCount ?? 0} jogo(s). Etiquetas automáticas podem voltar a ser criadas na próxima atualização do BGG.</>}
        onClose={() => setDel(null)} onConfirm={async () => { await api.deleteTag(del.id); await reloadTags(); await reloadGames(); }} />}
    </div>
  );
}

function TagRow({ t, onDelete }: { t: Tag; onDelete: () => void }) {
  const { reloadTags, toast } = useStore();
  const [name, setName] = useState(t.name);
  const [grp, setGrp] = useState(t.grp);
  const dirty = name !== t.name || grp !== t.grp;
  return (
    <div className="row" style={{ padding: '6px 12px' }}>
      <input className="input grow" style={{ flex: 1 }} value={name} onChange={(e) => setName(e.target.value)} aria-label="Nome da etiqueta" />
      <select className="input" style={{ width: 'auto' }} value={grp} onChange={(e) => setGrp(e.target.value)}>{GROUPS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
      <span className="hint" style={{ width: 70 }}>{t.gameCount ?? 0} jogo(s)</span>
      {dirty && <button className="btn small primary" onClick={async () => { try { await api.updateTag(t.id, { name: name.trim(), grp }); await reloadTags(); } catch (e) { toast((e as Error).message, 'error'); } }}>Salvar</button>}
      <button className="btn small ghost danger" onClick={onDelete} aria-label={`Excluir ${t.name}`}><Icon name="trash" size={14} /></button>
    </div>
  );
}

export function SettingsPage() {
  const { status, settings, setSettings, reload, toast } = useStore();
  const [s, setS] = useState<Settings>(settings);
  const fileRef = useRef<HTMLInputElement>(null);
  const [importing, setImporting] = useState(false);
  const save = async () => {
    try { setSettings(await api.saveSettings({ ...s, weightBands: [...s.weightBands].sort((a, b) => a.min - b.min) })); toast('Configurações salvas.'); }
    catch (e) { toast((e as Error).message, 'error'); }
  };
  return (
    <div className="page">
      <div className="page-head"><h2>Configurações e backup</h2></div>

      {EMBEDDED ? <MobileKeys /> : <ServerKeysInfo />}

      <div className="card-panel">
        <h3>Faixas de peso (rótulos da aplicação)</h3>
        <div className="hint">O valor numérico do BGG é sempre mantido; estes rótulos são só uma conveniência.</div>
        {s.weightBands.map((b, i) => (
          <div key={i} className="btn-row">
            <span className="hint" style={{ width: 70 }}>a partir de</span>
            <input className="input" style={{ width: 90 }} type="number" step={0.05} min={1} max={5} value={b.min}
              onChange={(e) => setS({ ...s, weightBands: s.weightBands.map((x, j) => j === i ? { ...x, min: Number(e.target.value) } : x) })} aria-label="Peso mínimo da faixa" />
            <input className="input" style={{ flex: 1 }} value={b.label} onChange={(e) => setS({ ...s, weightBands: s.weightBands.map((x, j) => j === i ? { ...x, label: e.target.value } : x) })} aria-label="Rótulo" />
          </div>
        ))}
        <h3 style={{ marginTop: 6 }}>Etiquetas de duração</h3>
        <div className="btn-row">
          <span className="hint">Curta até</span>
          <input className="input" style={{ width: 90 }} type="number" value={s.durationShortMax} onChange={(e) => setS({ ...s, durationShortMax: Number(e.target.value) })} />
          <span className="hint">min; média até</span>
          <input className="input" style={{ width: 90 }} type="number" value={s.durationMediumMax} onChange={(e) => setS({ ...s, durationMediumMax: Number(e.target.value) })} />
          <span className="hint">min; acima disso, longa.</span>
        </div>
        <div className="btn-row">
          <button className="btn primary" onClick={save}>Salvar</button>
          <button className="btn ghost" onClick={() => setS(DEFAULT_SETTINGS)}>Restaurar padrão</button>
        </div>
      </div>

      <div className="card-panel">
        <h3>Exportar e fazer backup</h3>
        <div className="hint">Os arquivos incluem jogos, expansões, proprietários, localização, empréstimos, etiquetas e IDs do BGG. Não dependem do BGG para serem restaurados.</div>
        <div className="btn-row">
          <button className="btn" onClick={() => exportCollection('json').catch((e) => toast(e.message, 'error'))}><Icon name="download" size={14} />Backup JSON</button>
          <button className="btn" onClick={() => exportCollection('csv').catch((e) => toast(e.message, 'error'))}><Icon name="download" size={14} />Planilha CSV</button>
          {EMBEDDED
            ? <button className="btn" onClick={() => exportCollection('db').catch((e) => toast(e.message, 'error'))}><Icon name="download" size={14} />Cópia do banco (SQLite)</button>
            : <a className="btn" href="/api/backup.sqlite" download><Icon name="download" size={14} />Cópia do banco (SQLite)</a>}
        </div>
        {EMBEDDED && <div className="hint">No celular, o backup abre o menu de compartilhar: salve no Google Drive, mande por e-mail ou WhatsApp. Os dados ficam só neste aparelho — faça backups de vez em quando.</div>}
        <h3 style={{ marginTop: 6 }}>Restaurar backup JSON</h3>
        <div className="hint">Mescla com a coleção atual: jogos já cadastrados (mesmo ID do BGG, ou mesmo nome e ano) são ignorados para evitar duplicações.</div>
        <div className="btn-row">
          <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = '';
            if (!f) return;
            setImporting(true);
            try {
              const data = JSON.parse(await f.text());
              const r = await api.importBackup(data);
              await reload();
              toast(`${r.added} item(ns) restaurado(s); ${r.skippedDuplicates} já existiam.`);
            } catch (err) { toast(err instanceof SyntaxError ? 'O arquivo não é um JSON válido.' : (err as Error).message, 'error'); } finally { setImporting(false); }
          }} />
          <button className="btn" disabled={importing} onClick={() => fileRef.current?.click()}><Icon name="upload" size={14} />Escolher arquivo de backup…</button>
        </div>
      </div>

      <div className="hint">Banco de dados: <code>{status?.dbPath}</code> · versão {status?.version}</div>
    </div>
  );
}

function ServerKeysInfo() {
  const { status } = useStore();
  return (
    <>
      <div className="card-panel">
        <h3>BoardGameGeek</h3>
        {status?.bggConfigured
          ? <div className="badge ok" style={{ alignSelf: 'flex-start' }}>Token configurado</div>
          : <div className="badge warn" style={{ alignSelf: 'flex-start' }}>Sem token — busca e atualização desativadas</div>}
        <div className="hint">
          Desde 2025 a API XML do BGG exige um token de aplicação. Para ativar: entre no BGG, registre uma aplicação de uso não comercial em
          {' '}<a href="https://boardgamegeek.com/applications" target="_blank" rel="noreferrer">boardgamegeek.com/applications</a>, aguarde a aprovação, gere um token e coloque no arquivo <code>.env</code> do projeto como <code>BGG_API_TOKEN=...</code>. Depois reinicie a aplicação.
          O token fica só no servidor.
        </div>
      </div>
      <div className="card-panel">
        <h3>Reconhecimento de fotos</h3>
        <div className="badge info" style={{ alignSelf: 'flex-start' }}>
          {status?.visionProvider === 'anthropic' ? `Claude (${status.visionModel})` : status?.visionProvider === 'ocr' ? 'OCR local (Tesseract, inglês + português)' : 'Desativado'}
        </div>
        <div className="hint">
          Sem configuração, usa OCR local (gratuito, sem internet). Para reconhecer estantes e lombadas com muito mais precisão, defina <code>ANTHROPIC_API_KEY</code> no <code>.env</code>.
        </div>
      </div>
    </>
  );
}

/** No celular, os tokens ficam guardados no próprio aparelho. */
function MobileKeys() {
  const { status, reload, toast } = useStore();
  const [cur, setCur] = useState<{ bggToken: string | null; anthropicKey: string | null; visionModel: string } | null>(null);
  const [bgg, setBgg] = useState('');
  const [anth, setAnth] = useState('');
  const load = () => api.secrets().then(setCur).catch(() => undefined);
  useEffect(() => { void load(); }, []);
  const save = async (p: Record<string, string | null>, msg: string) => {
    try { await api.saveSecrets(p); setBgg(''); setAnth(''); await load(); await reload(); toast(msg); }
    catch (e) { toast((e as Error).message, 'error'); }
  };
  return (
    <>
      <div className="card-panel">
        <h3>BoardGameGeek</h3>
        {status?.bggConfigured
          ? <div className="badge ok" style={{ alignSelf: 'flex-start' }}>Token configurado ({cur?.bggToken})</div>
          : <div className="badge warn" style={{ alignSelf: 'flex-start' }}>Sem token — busca e atualização desativadas</div>}
        <div className="hint">
          O BGG exige um token: entre no BGG, registre uma aplicação de uso não comercial em
          {' '}<a href="https://boardgamegeek.com/applications" target="_blank" rel="noreferrer">boardgamegeek.com/applications</a>, aguarde a aprovação, gere o token e cole aqui. Ele fica guardado só neste aparelho.
        </div>
        <div className="btn-row">
          <input className="input" style={{ flex: 1, minWidth: 200 }} type="password" autoComplete="off" placeholder="Colar token do BGG" value={bgg} onChange={(e) => setBgg(e.target.value)} aria-label="Token do BGG" />
          <button className="btn primary" disabled={!bgg.trim()} onClick={() => save({ bggToken: bgg.trim() }, 'Token do BGG salvo.')}>Salvar</button>
          {cur?.bggToken && <button className="btn ghost" onClick={() => save({ bggToken: null }, 'Token removido.')}>Remover</button>}
        </div>
      </div>
      <div className="card-panel">
        <h3>Reconhecimento de fotos</h3>
        <div className="badge info" style={{ alignSelf: 'flex-start' }}>
          {status?.visionProvider === 'anthropic' ? `Claude (${status.visionModel})` : 'OCR no aparelho (Tesseract, inglês + português)'}
        </div>
        <div className="hint">
          Sem chave, o app lê os títulos com OCR no próprio celular (gratuito, sem internet), melhor com capas de frente.
          Com uma chave da API da Anthropic (paga, em console.anthropic.com), o Claude reconhece estantes e lombadas com muito mais precisão; as fotos são enviadas para a Anthropic só nesse caso.
        </div>
        <div className="btn-row">
          <input className="input" style={{ flex: 1, minWidth: 200 }} type="password" autoComplete="off" placeholder="Chave da API da Anthropic (opcional)" value={anth} onChange={(e) => setAnth(e.target.value)} aria-label="Chave da Anthropic" />
          <button className="btn primary" disabled={!anth.trim()} onClick={() => save({ anthropicKey: anth.trim() }, 'Chave salva.')}>Salvar</button>
          {cur?.anthropicKey && <button className="btn ghost" onClick={() => save({ anthropicKey: null }, 'Chave removida.')}>Remover</button>}
        </div>
      </div>
    </>
  );
}
