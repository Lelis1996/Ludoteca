import { useState } from 'react';
import { StoreProvider, useRoute, usePersistentState, useStore } from './lib/store';
import { DEFAULT_FILTERS, type Filters } from '../shared/filter';
import { Library } from './pages/Library';
import { ImportPage } from './pages/ImportPage';
import { OwnersPage, SettingsPage, TagsPage } from './pages/ManagePages';
import { GameDrawer } from './components/GameDrawer';
import { AddGameDialog } from './components/AddGameDialog';
import { Icon } from './components/Icon';
import { Toasts } from './components/ui';

export function App() {
  return (
    <StoreProvider>
      <Shell />
      <Toasts />
    </StoreProvider>
  );
}

function Shell() {
  const { path, go } = useRoute();
  const { loaded } = useStore();
  const [filters, setFilters] = usePersistentState<Filters>('ludoteca.filters.v1', DEFAULT_FILTERS);
  const [ui, setUi] = usePersistentState<{ view: 'grid' | 'list' }>('ludoteca.ui.v1', { view: 'grid' });
  const [adding, setAdding] = useState(false);

  const section = path[0] ?? '';
  const gameId = section === 'jogo' ? Number(path[1]) : null;
  const libraryVisible = section === '' || section === 'jogo';
  const openGame = (id: number) => go(`/jogo/${id}`);
  const closeGame = () => go('/');

  const nav: [string, string, string][] = [
    ['', 'Biblioteca', 'home'], ['importar', 'Importar fotos', 'camera'], ['proprietarios', 'Proprietários', 'users'],
    ['etiquetas', 'Etiquetas', 'tag'], ['configuracoes', 'Configurações', 'settings'],
  ];

  return (
    <div className="app">
      <header className="topbar">
        <a className="brand" href="#/" aria-label="Ludoteca — início">
          <span className="brand-mark">L</span>
          <h1>Ludoteca</h1>
        </a>
        {libraryVisible && (
          <div className="search">
            <Icon name="search" />
            <input type="search" placeholder="Buscar por nome, designer, editora, mecânica, etiqueta…" value={filters.q}
              onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))} aria-label="Pesquisar na coleção" />
          </div>
        )}
        <nav className="topnav">
          {nav.map(([to, label, icon]) => (
            <a key={to} href={`#/${to}`} className={(to === '' ? libraryVisible : section === to) ? 'active' : ''} title={label}>
              <Icon name={icon} size={15} /> <span className="label-text">{label}</span>
            </a>
          ))}
          <button className="btn primary small" onClick={() => setAdding(true)}><Icon name="plus" size={14} /><span className="label-text">Adicionar jogo</span></button>
        </nav>
      </header>

      {!loaded ? <div className="page"><span className="spinner" /></div> : (
        <>
          {libraryVisible && <Library filters={filters} setFilters={setFilters} view={ui.view} setView={(v) => setUi({ view: v })} openGame={openGame} onAdd={() => setAdding(true)} />}
          {section === 'importar' && <ImportPage batchId={path[1] ? Number(path[1]) : null} go={go} />}
          {section === 'proprietarios' && <OwnersPage />}
          {section === 'etiquetas' && <TagsPage />}
          {section === 'configuracoes' && <SettingsPage />}
        </>
      )}

      <nav className="bottomnav" aria-label="Navegação">
        {nav.map(([to, label, icon]) => (
          <a key={to} href={`#/${to}`} className={(to === '' ? libraryVisible : section === to) ? 'active' : ''}>
            <Icon name={icon} size={20} /><span>{label.replace(' fotos', '')}</span>
          </a>
        ))}
      </nav>
      {(libraryVisible && gameId == null) && (
        <button className="fab" onClick={() => setAdding(true)} aria-label="Adicionar jogo"><Icon name="plus" size={26} /></button>
      )}

      {gameId != null && Number.isFinite(gameId) && <GameDrawer id={gameId} onClose={closeGame} openGame={openGame} />}
      {adding && <AddGameDialog onClose={() => setAdding(false)} openGame={openGame} />}
    </div>
  );
}
