import { useMemo, useState } from 'react';
import { api } from '../lib/api';
import { useStore } from '../lib/store';
import type { GameDetail, GameSummary, OwnershipStatus } from '../../shared/types';
import { EXPANSION_TYPE_LABELS, isWithMe, locationPhrase } from '../../shared/domain';
import { Icon } from './Icon';
import { Cover, Modal, ownerColor, Spinner } from './ui';
import { BggPicker } from './AddGameDialog';

type Update = (fn: () => Promise<GameDetail>, msg?: string) => Promise<boolean>;
type View = 'all' | 'owned' | 'not_owned' | 'wishlist' | 'friends' | 'away';

const STATUS_OPTIONS: [OwnershipStatus, string][] = [
  ['unverified', 'Não verificado'], ['owned', 'Possuo'], ['not_owned', 'Não possuo'], ['wishlist', 'Quero comprar'],
];

export function ExpansionsTab({ g, update, reload, openGame }: { g: GameDetail; update: Update; reload: () => Promise<void>; openGame: (id: number) => void }) {
  if (g.kind === 'expansion' || (g.bases.length > 0 && g.expansions.length === 0)) return <BasesView g={g} update={update} openGame={openGame} />;
  return <ExpansionList g={g} reload={reload} openGame={openGame} update={update} />;
}

function ExpansionList({ g, reload, openGame, update }: { g: GameDetail; reload: () => Promise<void>; openGame: (id: number) => void; update: Update }) {
  const { owners, reloadGames, toast, status } = useStore();
  const [view, setView] = useState<View>('all');
  const [busy, setBusy] = useState(false);
  const [adding, setAdding] = useState<null | 'menu' | 'bgg' | 'manual'>(null);
  const me = owners.find((o) => o.isMe);
  const s = g.expansionStats;

  const list = useMemo(() => g.expansions.filter((e) => {
    switch (view) {
      case 'all': return true;
      case 'owned': return e.ownershipStatus === 'owned';
      case 'not_owned': return e.ownershipStatus === 'not_owned' || e.ownershipStatus === 'unverified';
      case 'wishlist': return e.ownershipStatus === 'wishlist';
      case 'friends': return e.ownershipStatus === 'owned' && e.ownerId != null && e.ownerId !== me?.id;
      case 'away': return e.ownershipStatus === 'owned' && !isWithMe(e);
    }
  }), [g.expansions, view, me]);

  const fetchAll = async () => {
    setBusy(true);
    try {
      const r = await api.refreshExpansions(g.id);
      await reload(); await reloadGames();
      toast(`${r.updated} expansão(ões) atualizada(s)${r.notExpansion ? `; ${r.notExpansion} é(são) jogo(s) independente(s)` : ''}.`);
    } catch (e) { toast((e as Error).message, 'error'); } finally { setBusy(false); }
  };

  const setStatus = async (e: GameSummary, st: OwnershipStatus) => {
    try { await api.patchGame(e.id, { ownershipStatus: st }); await reload(); await reloadGames(); }
    catch (err) { toast((err as Error).message, 'error'); }
  };

  const stubs = g.expansions.filter((e) => e.dataStatus === 'stub' || e.dataStatus === 'bgg_error').length;

  return (
    <div className="section">
      {s && s.known + s.unverified + s.promos + s.fan + s.standalone > 0 ? (
        <div className="card-panel">
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
            <h3>Possuo {s.owned} de {s.known} expansões conhecidas</h3>
            {s.wishlist > 0 && <span className="badge accent">{s.wishlist} na lista de compras</span>}
            {s.withFriends > 0 && <span className="badge info">{s.withFriends} de amigos</span>}
            {s.awayFromHome > 0 && <span className="badge warn">{s.awayFromHome} fora de casa</span>}
          </div>
          <div className="progress"><i style={{ width: `${s.known ? (s.owned / s.known) * 100 : 0}%` }} /></div>
          <div className="hint">
            Conta só expansões identificadas e verificadas no BGG.
            {(s.promos > 0 || s.fan > 0 || s.standalone > 0) && ` Fora da conta: ${[s.promos && `${s.promos} promo(s)`, s.fan && `${s.fan} feita(s) por fãs`, s.standalone && `${s.standalone} jogo(s) independente(s)`].filter(Boolean).join(', ')}.`}
            {stubs > 0 && ` ${stubs} ainda sem dados do BGG.`}
          </div>
        </div>
      ) : (
        <div className="notice"><Icon name="info" />{g.bggId ? 'O BGG não lista expansões para este jogo (ou os dados ainda não foram buscados).' : 'Nenhuma expansão registrada. Adicione manualmente.'}</div>
      )}

      <div className="btn-row">
        {g.bggId && (
          <button className="btn" onClick={fetchAll} disabled={busy || !status?.bggConfigured} title={status?.bggConfigured ? '' : 'BGG não configurado'}>
            {busy ? <Spinner /> : <Icon name="refresh" size={14} />}{stubs ? `Buscar dados de ${stubs} expansão(ões)` : 'Atualizar expansões do BGG'}
          </button>
        )}
        <button className="btn" onClick={() => setAdding('menu')}><Icon name="plus" size={14} />Adicionar expansão</button>
      </div>

      {g.expansions.length > 0 && (
        <div className="seg" role="group" aria-label="Filtrar expansões">
          {([['all', 'Todas'], ['owned', 'Possuo'], ['not_owned', 'Não possuo'], ['wishlist', 'Quero comprar'], ['friends', 'De amigos'], ['away', 'Emprestadas/fora']] as [View, string][]).map(([k, l]) => (
            <button key={k} className={view === k ? 'on' : ''} onClick={() => setView(k)}>{l}</button>
          ))}
        </div>
      )}

      <div className="exp-list">
        {list.map((e) => {
          const owner = owners.find((o) => o.id === e.ownerId);
          return (
            <div key={e.id} className={`exp-row${e.ownershipStatus === 'owned' ? ' owned' : ''}`}>
              {e.thumb ? <img src={e.thumb} alt="" loading="lazy" /> : <div className="ph"><Icon name="box" /></div>}
              <div style={{ minWidth: 0 }}>
                <div className="nm" role="link" tabIndex={0} onClick={() => openGame(e.id)} onKeyDown={(k) => { if (k.key === 'Enter') openGame(e.id); }}
                  style={{ color: e.ownershipStatus === 'owned' && owner ? ownerColor(owner) : undefined }}>
                  {e.ownershipStatus === 'owned' && '✓ '}{e.nameEn}
                </div>
                <div className="hint" style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
                  {e.year && <span>{e.year}</span>}
                  {e.expansionType && <span className="badge">{EXPANSION_TYPE_LABELS[e.expansionType]}</span>}
                  {e.standaloneExpansion && <span className="badge warn">Jogo independente</span>}
                  {e.dataStatus === 'stub' && <span className="badge">dados pendentes</span>}
                  {e.dataStatus === 'bgg_error' && <span className="badge danger">erro no BGG</span>}
                  {e.ownershipStatus === 'owned' && <>
                    <span className="owner-line"><span className="owner-dot" style={{ background: owner?.color }} />{owner?.name ?? 'sem proprietário'}</span>
                    <span style={{ color: isWithMe(e) ? undefined : 'var(--warn)' }}>· {locationPhrase(e, owners)}</span>
                  </>}
                </div>
              </div>
              <select className="input" style={{ width: 'auto' }} value={e.ownershipStatus} aria-label={`Status de ${e.nameEn}`}
                onChange={(ev) => setStatus(e, ev.target.value as OwnershipStatus)}>
                {STATUS_OPTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                {!STATUS_OPTIONS.some(([k]) => k === e.ownershipStatus) && <option value={e.ownershipStatus}>{e.ownershipStatus}</option>}
              </select>
            </div>
          );
        })}
        {g.expansions.length > 0 && list.length === 0 && <div className="hint">Nenhuma expansão neste filtro.</div>}
      </div>

      {adding === 'menu' && (
        <Modal title="Adicionar expansão" onClose={() => setAdding(null)}>
          <button className="btn" disabled={!status?.bggConfigured} onClick={() => setAdding('bgg')}><Icon name="search" />Buscar no BGG</button>
          <button className="btn" onClick={() => setAdding('manual')}><Icon name="edit" />Cadastrar manualmente ou associar um jogo já cadastrado</button>
        </Modal>
      )}
      {adding === 'bgg' && (
        <BggPicker title={`Expansão de ${g.nameEn}`} initialQuery={g.nameEn} onClose={() => setAdding(null)} withStatus
          onPick={async (r, st) => {
            try {
              let d = await api.addFromBgg({ bggId: r.bggId, ownershipStatus: st ?? 'owned', ownerId: g.ownerId ?? undefined });
              if (!d.bases.some((b) => b.gameId === g.id)) d = await api.addRelation(d.id, g.id);
              await reload(); await reloadGames(); setAdding(null); toast('Expansão adicionada.');
            } catch (e) { toast((e as Error).message, 'error'); }
          }} />
      )}
      {adding === 'manual' && <ManualExpansion base={g} onClose={() => setAdding(null)} onDone={async () => { await reload(); await reloadGames(); setAdding(null); }} update={update} />}
    </div>
  );
}

function ManualExpansion({ base, onClose, onDone }: { base: GameDetail; onClose: () => void; onDone: () => Promise<void>; update: Update }) {
  const { games, toast } = useStore();
  const [name, setName] = useState('');
  const [existing, setExisting] = useState('');
  const [status, setStatus] = useState<OwnershipStatus>('owned');
  const candidates = games.filter((x) => x.id !== base.id && !base.expansions.some((e) => e.id === x.id)).sort((a, b) => a.nameEn.localeCompare(b.nameEn));
  const save = async () => {
    try {
      if (existing) await api.addRelation(Number(existing), base.id);
      else if (name.trim()) await api.createGame({ nameEn: name.trim(), baseGameId: base.id, kind: 'expansion', ownershipStatus: status, ownerId: base.ownerId, locationType: base.locationType });
      else return;
      toast('Expansão associada.');
      await onDone();
    } catch (e) { toast((e as Error).message, 'error'); }
  };
  return (
    <Modal title={`Expansão de ${base.nameEn}`} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>Cancelar</button><button className="btn primary" onClick={save}>Salvar</button></>}>
      <label className="field"><span>Associar um item já cadastrado</span>
        <select className="input" value={existing} onChange={(e) => setExisting(e.target.value)}>
          <option value="">—</option>
          {candidates.map((c) => <option key={c.id} value={c.id}>{c.nameEn}{c.kind === 'expansion' ? ' (expansão)' : ''}</option>)}
        </select>
      </label>
      <div className="hint">ou</div>
      <div className="grid-2">
        <label className="field"><span>Nome da nova expansão</span><input className="input" value={name} disabled={!!existing} onChange={(e) => setName(e.target.value)} /></label>
        <label className="field"><span>Status</span>
          <select className="input" value={status} disabled={!!existing} onChange={(e) => setStatus(e.target.value as OwnershipStatus)}>
            {STATUS_OPTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
          </select>
        </label>
      </div>
    </Modal>
  );
}

function BasesView({ g, update, openGame }: { g: GameDetail; update: Update; openGame: (id: number) => void }) {
  const { games } = useStore();
  const [baseId, setBaseId] = useState('');
  const bases = games.filter((x) => x.kind === 'base' && x.id !== g.id && !g.bases.some((b) => b.gameId === x.id)).sort((a, b) => a.nameEn.localeCompare(b.nameEn));
  return (
    <div className="section">
      <h3>Jogo(s)-base</h3>
      {g.bases.length === 0 && <div className="notice warn"><Icon name="alert" />Esta expansão não está associada a nenhum jogo-base.</div>}
      <div className="exp-list">
        {g.bases.map((b) => {
          const bg = games.find((x) => x.id === b.gameId);
          return (
            <div key={b.relationId} className="exp-row">
              {bg?.thumb ? <img src={bg.thumb} alt="" /> : <div className="ph"><Cover src={null} name={b.name} /></div>}
              <div>
                <div className="nm" onClick={() => b.gameId && openGame(b.gameId)}>{b.name}</div>
                <div className="hint">{b.source === 'bgg' ? 'Associação vinda do BGG' : 'Associação manual'}{bg ? ` · ${bg.ownershipStatus === 'owned' ? 'na coleção' : 'não possuído / só consulta'}` : ' · não cadastrado'}</div>
              </div>
              <button className="btn small ghost" onClick={() => update(() => api.removeRelation(b.relationId), 'Associação removida.')}>Desfazer associação</button>
            </div>
          );
        })}
      </div>
      <div className="card-panel">
        <div className="label">Associar a um jogo-base cadastrado</div>
        <div className="btn-row">
          <select className="input" style={{ flex: 1 }} value={baseId} onChange={(e) => setBaseId(e.target.value)}>
            <option value="">Escolher…</option>
            {bases.map((b) => <option key={b.id} value={b.id}>{b.nameEn}</option>)}
          </select>
          <button className="btn" disabled={!baseId} onClick={() => update(() => api.addRelation(g.id, Number(baseId)), 'Associação criada.').then(() => setBaseId(''))}>Associar</button>
        </div>
      </div>
    </div>
  );
}
