import { useEffect, useState, type ReactNode } from 'react';
import { Icon } from './Icon';
import { useStore } from '../lib/store';
import { readableOnDark, weightLabel, formatPlayers, typicalTime, isWithMe, locationPhrase } from '../../shared/domain';
import type { GameSummary, Owner } from '../../shared/types';

export function Modal({ title, onClose, children, footer, wide }: { title: ReactNode; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const on = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, [onClose]);
  return (
    <div className="overlay center" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`modal${wide ? ' wide' : ''}`} role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : undefined}>
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="btn ghost icon" onClick={onClose} aria-label="Fechar"><Icon name="x" /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Confirm({ title, text, confirmLabel = 'Confirmar', danger, onConfirm, onClose }: {
  title: string; text: ReactNode; confirmLabel?: string; danger?: boolean; onConfirm: () => Promise<void> | void; onClose: () => void;
}) {
  const [busy, setBusy] = useState(false);
  return (
    <Modal title={title} onClose={onClose} footer={<>
      <button className="btn ghost" onClick={onClose}>Cancelar</button>
      <button className={`btn ${danger ? 'danger' : 'primary'}`} disabled={busy} onClick={async () => { setBusy(true); try { await onConfirm(); onClose(); } finally { setBusy(false); } }}>
        {busy && <span className="spinner" />}{confirmLabel}
      </button>
    </>}>
      <div>{text}</div>
    </Modal>
  );
}

export function Toasts() {
  const { toasts } = useStore();
  return <div className="toasts" role="status">{toasts.map((t) => <div key={t.id} className={`toast ${t.kind}`}>{t.text}</div>)}</div>;
}

export function ownerColor(o: Owner | undefined): string {
  return readableOnDark(o?.color ?? '#f5f1e8');
}

/** Nome do jogo colorido pela cor do proprietário. */
export function GameName({ game, as = 'div' }: { game: Pick<GameSummary, 'nameEn' | 'namePt' | 'ownerId' | 'ownershipStatus'>; as?: 'div' | 'span' }) {
  const { ownerById } = useStore();
  const owner = game.ownershipStatus === 'owned' ? ownerById(game.ownerId) : undefined;
  const Tag = as;
  return <Tag className="game-name" style={{ color: owner ? ownerColor(owner) : 'var(--text-2)' }}>{game.nameEn}</Tag>;
}

export function OwnerTag({ game }: { game: GameSummary }) {
  const { ownerById, owners } = useStore();
  const owner = ownerById(game.ownerId);
  const label = game.ownershipStatus === 'owned' ? (owner?.name ?? 'Sem proprietário')
    : game.ownershipStatus === 'wishlist' ? 'Quero comprar'
    : game.ownershipStatus === 'want_to_try' ? 'Quero experimentar'
    : game.ownershipStatus === 'unverified' ? 'Não verificado'
    : game.ownershipStatus === 'not_owned' ? 'Não possuo' : 'Só consulta';
  return (
    <div className="owner-line" title={game.ownershipStatus === 'owned' ? `Proprietário: ${label} · ${locationPhrase(game, owners)}` : label}>
      <span className="owner-dot" style={{ background: game.ownershipStatus === 'owned' ? owner?.color ?? '#777' : 'transparent', border: game.ownershipStatus === 'owned' ? undefined : '1px dashed var(--muted)' }} />
      <span>{label}</span>
    </div>
  );
}

export function AwayBanner({ game }: { game: GameSummary }) {
  const { owners } = useStore();
  if (game.ownershipStatus !== 'owned' || isWithMe(game)) return null;
  return <div className="away-banner">{locationPhrase(game, owners)}</div>;
}

export function WeightPill({ weight }: { weight: number | null }) {
  const { settings } = useStore();
  if (weight == null) return <span className="unverified">Peso n/d</span>;
  return (
    <span className="weight-pill" title={`Peso médio no BGG: ${weight.toFixed(2)} de 5 (${weightLabel(weight, settings.weightBands)} — rótulo da aplicação)`}>
      <span className="weight-bar"><i style={{ width: `${((weight - 1) / 4) * 100}%` }} /></span>
      {weight.toFixed(1)} · {weightLabel(weight, settings.weightBands)}
    </span>
  );
}

export function BestWith({ game, compact }: { game: GameSummary; compact?: boolean }) {
  if (!game.bestCount1) {
    return <span className="unverified" title="A comunidade do BGG não tem votos suficientes, ou os dados ainda não foram buscados">{compact ? 'Melhor: n/v' : 'Melhor com: não verificado'}</span>;
  }
  const parts = [game.bestCount1, game.bestCount2].filter(Boolean);
  return (
    <span title={`Votação da comunidade do BGG ("Best"): ${game.bestCount1} jogadores (${game.bestVotes1} votos)${game.bestCount2 ? `, ${game.bestCount2} jogadores (${game.bestVotes2} votos)` : ''}`}>
      {compact ? 'Melhor ' : 'Melhor com '}<span className="best">{parts.join(' e ')}</span>
    </span>
  );
}

export function GameStats({ game }: { game: GameSummary }) {
  const t = typicalTime(game);
  return (
    <div className="stats">
      <div className="stat" title="Quantidade oficial de jogadores"><Icon name="users" size={14} />{formatPlayers(game.minPlayers, game.maxPlayers)}</div>
      <div className="stat" title={game.typicalTimeManual ? 'Tempo típico informado por você' : 'Tempo de jogo oficial (BGG)'}><Icon name="clock" size={14} />{t ? `${t} min` : <span className="unverified">n/d</span>}{game.typicalTimeManual ? '*' : ''}</div>
      <div className="stat wide"><Icon name="star" size={14} /><BestWith game={game} /></div>
      <div className="stat wide"><Icon name="weight" size={14} /><WeightPill weight={game.weight} /></div>
    </div>
  );
}

export function Cover({ src, name, className }: { src: string | null; name: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (!src || failed) return <span className={`placeholder ${className ?? ''}`}>{name.slice(0, 1).toUpperCase()}</span>;
  return <img src={src} alt={`Caixa de ${name}`} loading="lazy" onError={() => setFailed(true)} className={className} />;
}

export function Spinner() { return <span className="spinner" aria-label="Carregando" />; }
