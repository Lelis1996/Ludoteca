import { useCallback, useEffect, useState } from 'react';
import { api } from '../lib/api';
import { useStore } from '../lib/store';
import type { GameDetail } from '../../shared/types';
import {
  EXPANSION_TYPE_LABELS, OWNERSHIP_LABELS, formatPlayers, formatTime, locationPhrase, playerTimeTable, typicalTime, weightLabel, isWithMe,
} from '../../shared/domain';
import { Icon } from './Icon';
import { BestWith, Confirm, Cover, ownerColor, Spinner } from './ui';
import { OwnershipForm, DataEditForm } from './GameForms';
import { ExpansionsTab } from './ExpansionsTab';
import { TagsTab } from './TagsTab';
import { BggPicker } from './AddGameDialog';

type Tab = 'overview' | 'players' | 'tags' | 'owner' | 'expansions' | 'sources';

export function GameDrawer({ id, onClose, openGame }: { id: number; onClose: () => void; openGame: (id: number) => void }) {
  const { reloadGames, toast, status } = useStore();
  const [g, setG] = useState<GameDetail | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('overview');
  const [busy, setBusy] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [editing, setEditing] = useState(false);
  const [linking, setLinking] = useState(false);

  const load = useCallback(async () => {
    try { setG(await api.game(id)); setErr(null); } catch (e) { setErr((e as Error).message); }
  }, [id]);
  useEffect(() => { setG(null); setTab('overview'); void load(); }, [id, load]);
  useEffect(() => {
    const on = (e: KeyboardEvent) => { if (e.key === 'Escape' && !editing && !confirmDelete && !linking) onClose(); };
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, [onClose, editing, confirmDelete, linking]);

  /** Aplica uma alteração e atualiza a ficha e a biblioteca. */
  const update = async (fn: () => Promise<GameDetail>, okMsg?: string) => {
    try {
      const d = await fn();
      setG(d);
      await reloadGames();
      if (okMsg) toast(okMsg);
      return true;
    } catch (e) {
      toast((e as Error).message, 'error');
      return false;
    }
  };

  const refresh = async () => {
    setBusy('refresh');
    await update(() => api.refreshGame(id), 'Dados do BGG atualizados (seus dados pessoais foram preservados).');
    setBusy(null);
  };

  return (
    <div className="overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="drawer" role="dialog" aria-modal="true" aria-label={g?.nameEn ?? 'Jogo'}>
        <div className="detail-close">
          <button className="btn ghost" onClick={onClose}><Icon name="x" />Fechar</button>
          {g && (
            <div className="btn-row">
              <button className="btn small" onClick={() => update(() => api.patchGame(g.id, { favorite: !g.favorite }))} aria-pressed={g.favorite}>
                <span style={{ color: g.favorite ? 'var(--accent)' : undefined }}>{g.favorite ? '★' : '☆'}</span>{g.favorite ? 'Favorito' : 'Favoritar'}
              </button>
              {g.bggId ? (
                <button className="btn small" onClick={refresh} disabled={!!busy || !status?.bggConfigured} title={status?.bggConfigured ? 'Buscar dados novos no BGG' : 'BGG não configurado'}>
                  {busy === 'refresh' ? <Spinner /> : <Icon name="refresh" size={14} />}Atualizar do BGG
                </button>
              ) : (
                <button className="btn small" onClick={() => setLinking(true)} disabled={!status?.bggConfigured}><Icon name="search" size={14} />Vincular ao BGG</button>
              )}
              <button className="btn small" onClick={() => setEditing(true)}><Icon name="edit" size={14} />Editar dados</button>
              <button className="btn small danger" onClick={() => setConfirmDelete(true)}><Icon name="trash" size={14} />Excluir</button>
            </div>
          )}
        </div>

        {err && <div className="section"><div className="notice danger">{err}</div></div>}
        {!g && !err && <div className="section"><Spinner /></div>}
        {g && (
          <>
            <Hero g={g} openGame={openGame} />
            <div className="tabs" role="tablist">
              {([
                ['overview', 'Visão geral'], ['players', 'Jogadores e tempo'], ['tags', 'Etiquetas e mecânicas'], ['owner', 'Propriedade e local'],
                ...(g.kind === 'base' || g.expansions.length ? [['expansions', `Expansões${g.expansionStats ? ` (${g.expansionStats.owned}/${g.expansionStats.known})` : ''}`]] : [['expansions', 'Jogo-base']]),
                ['sources', 'Fontes dos dados'],
              ] as [Tab, string][]).map(([k, l]) => (
                <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>
              ))}
            </div>
            {tab === 'overview' && <Overview g={g} />}
            {tab === 'players' && <PlayersTab g={g} update={update} />}
            {tab === 'tags' && <TagsTab g={g} update={update} />}
            {tab === 'owner' && <div className="section"><OwnershipForm g={g} update={update} /></div>}
            {tab === 'expansions' && <ExpansionsTab g={g} update={update} reload={load} openGame={openGame} />}
            {tab === 'sources' && <SourcesTab g={g} update={update} />}
          </>
        )}
      </div>
      {g && editing && <DataEditForm g={g} onClose={() => setEditing(false)} update={update} />}
      {g && linking && (
        <BggPicker title="Vincular ao BoardGameGeek" initialQuery={g.nameEn} onClose={() => setLinking(false)}
          note="Ao vincular, os dados oficiais do BGG substituem os dados do cadastro manual. Proprietário, local, notas e etiquetas manuais são mantidos."
          onPick={async (r) => { if (await update(() => api.linkBgg(g.id, r.bggId), 'Jogo vinculado ao BGG.')) setLinking(false); }} />
      )}
      {g && confirmDelete && (
        <Confirm title="Excluir jogo" danger confirmLabel="Excluir"
          text={<>Excluir <b>{g.nameEn}</b> da coleção? {g.expansions.length > 0 && 'Expansões não possuídas e sem anotações ligadas a ele também serão removidas; as possuídas ficam na coleção.'} Esta ação não pode ser desfeita (faça um backup antes, se quiser).</>}
          onClose={() => setConfirmDelete(false)}
          onConfirm={async () => { await api.deleteGame(g.id); await reloadGames(); toast('Jogo excluído.'); onClose(); }} />
      )}
    </div>
  );
}

function Hero({ g, openGame }: { g: GameDetail; openGame: (id: number) => void }) {
  const { ownerById, owners } = useStore();
  const owner = ownerById(g.ownerId);
  return (
    <div className="detail-hero">
      <div className="cover"><Cover src={g.image} name={g.nameEn} /></div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, minWidth: 0 }}>
        <div className="btn-row">
          {g.kind === 'expansion' && <span className="badge accent">Expansão{g.expansionType ? ` · ${EXPANSION_TYPE_LABELS[g.expansionType]}` : ''}</span>}
          {g.standaloneExpansion && <span className="badge warn">Jogo independente listado como expansão no BGG</span>}
          <span className={`badge ${g.ownershipStatus === 'owned' ? 'ok' : ''}`}>{OWNERSHIP_LABELS[g.ownershipStatus]}</span>
          {g.dataStatus === 'manual' && <span className="badge">Cadastro manual</span>}
          {g.dataStatus === 'stub' && <span className="badge warn">Dados do BGG ainda não buscados</span>}
          {g.bggError && <span className="badge danger" title={g.bggError}>Erro na última consulta ao BGG</span>}
        </div>
        <h2 style={{ color: g.ownershipStatus === 'owned' && owner ? ownerColor(owner) : undefined }}>{g.nameEn}</h2>
        <div className="muted">
          {[g.namePt ? `Em português: ${g.namePt}` : null, g.year, g.designers.join(', ') || null].filter(Boolean).join(' · ')}
        </div>
        {g.bases.length > 0 && (
          <div>Expansão de {g.bases.map((b, i) => (
            <span key={b.relationId}>{i > 0 && ', '}{b.gameId ? <a href="#" onClick={(e) => { e.preventDefault(); openGame(b.gameId!); }}>{b.name}</a> : b.name}</span>
          ))}</div>
        )}
        {g.ownershipStatus === 'owned' && (
          <div className="owner-line" style={{ fontSize: 14 }}>
            <span className="owner-dot" style={{ background: owner?.color }} />
            <span>De <b>{owner?.name ?? '—'}</b></span>
            <span className={isWithMe(g) ? '' : 'badge warn'}>{locationPhrase(g, owners)}</span>
            {g.loanDueDate && <span className="hint">devolução prevista {new Date(g.loanDueDate + 'T12:00').toLocaleDateString('pt-BR')}</span>}
          </div>
        )}
        <div className="btn-row">
          {g.bggId && <a className="btn small" href={`https://boardgamegeek.com/boardgame/${g.bggId}`} target="_blank" rel="noreferrer"><Icon name="external" size={14} />Página no BGG (#{g.bggId})</a>}
        </div>
      </div>
    </div>
  );
}

function SrcBadge({ g, field }: { g: GameDetail; field: string }) {
  const f = g.fieldSources.find((x) => x.field === field);
  if (!f) return null;
  const label = f.status === 'unavailable' ? 'n/d' : f.status === 'unverified' ? 'não verificado' : f.source === 'bgg' ? 'BGG' : f.source === 'manual' ? 'manual' : f.source === 'calculated' ? 'calculado' : 'inferido';
  return <span className={`src ${f.status !== 'verified' ? f.status : f.source}`} title={f.note ?? ''}>{label}</span>;
}

function Overview({ g }: { g: GameDetail }) {
  const { settings } = useStore();
  const t = typicalTime(g);
  return (
    <div className="section">
      <div className="kv">
        <div><div className="k">Jogadores (oficial)<SrcBadge g={g} field="max_players" /></div><div className="v">{formatPlayers(g.minPlayers, g.maxPlayers)}</div>{g.minPlayers === 1 && <div className="s">Tem modo solo</div>}</div>
        <div><div className="k">Melhor com (comunidade)<SrcBadge g={g} field="best_with" /></div><div className="v"><BestWith game={g} compact /></div>
          <div className="s">{g.recommendedCounts?.length ? `Recomendado: ${g.recommendedCounts.join(', ')}` : g.recommendedCounts ? 'Nenhuma quantidade recomendada' : 'Não verificado'}</div></div>
        <div><div className="k">Tempo (oficial)<SrcBadge g={g} field="playing_time" /></div><div className="v">{formatTime(g.minPlaytime, g.maxPlaytime)}</div>
          <div className="s">{g.typicalTimeManual ? `Típico (seu): ${g.typicalTimeManual} min` : t ? `Típico (BGG): ${t} min` : 'Não disponível'}</div></div>
        <div><div className="k">Peso / complexidade<SrcBadge g={g} field="weight" /></div><div className="v">{g.weight != null ? `${g.weight.toFixed(2)} / 5` : <span className="unverified">Não disponível</span>}</div>
          <div className="s">{g.weight != null ? `${weightLabel(g.weight, settings.weightBands)} · ${g.weightVotes ?? 0} votos` : 'Sem votos no BGG'}</div></div>
        <div><div className="k">Ano</div><div className="v">{g.year ?? '—'}</div>{g.minAge && <div className="s">Idade: {g.minAge}+</div>}</div>
        {g.bggRank && <div><div className="k">Ranking BGG</div><div className="v">#{g.bggRank}</div><div className="s">{g.avgRating ? `Nota média ${g.avgRating.toFixed(1)} · ${g.usersRated} avaliações` : ''}</div></div>}
      </div>
      {(g.designers.length > 0 || g.publishers.length > 0) && (
        <div className="grid-2">
          <div><div className="label">Designer(s)</div><div>{g.designers.join(', ') || '—'}</div></div>
          <div><div className="label">Editora(s)</div><div style={{ color: 'var(--text-2)' }}>{g.publishers.slice(0, 8).join(', ')}{g.publishers.length > 8 ? ` e mais ${g.publishers.length - 8}` : ''}</div></div>
        </div>
      )}
      {(g.ptVersions.length > 0 || g.altNames.length > 0) && !g.namePt && (
        <div className="notice info"><Icon name="info" />
          <div>
            {g.ptVersions.length > 0 && <div>O BGG registra {g.ptVersions.length} edição(ões) em português: {g.ptVersions.map((v) => `${v.name}${v.publisher ? ` (${v.publisher}${v.year ? `, ${v.year}` : ''})` : ''}`).join('; ')}.</div>}
            <div>O nome em português não é preenchido automaticamente porque o BGG não indica o idioma dos nomes alternativos. Confirme-o em “Editar dados”.</div>
          </div>
        </div>
      )}
      {g.notes && <div className="card-panel"><div className="label">Suas notas</div><div style={{ whiteSpace: 'pre-line' }}>{g.notes}</div></div>}
      {g.description && <div><div className="label" style={{ marginBottom: 6 }}>Descrição (BGG)</div><div className="desc">{g.description}</div></div>}
    </div>
  );
}

function PlayersTab({ g, update }: { g: GameDetail; update: (fn: () => Promise<GameDetail>, msg?: string) => Promise<boolean> }) {
  const { status } = useStore();
  const [typical, setTypical] = useState(g.typicalTimeManual?.toString() ?? '');
  const [perPlayer, setPerPlayer] = useState(g.timePerPlayerManual?.toString() ?? '');
  const [basePlayers, setBasePlayers] = useState(g.timeBasePlayersManual?.toString() ?? '');
  const [note, setNote] = useState(g.timeNote ?? '');
  const table = playerTimeTable(g);
  const maxVotes = Math.max(1, ...g.poll.map((p) => p.best + p.recommended + p.notRecommended));
  const num = (s: string) => (s.trim() === '' ? null : Number(s));
  return (
    <div className="section">
      <h3>Votação da comunidade (Best With)</h3>
      {g.poll.length === 0 || !g.pollTotalVotes ? (
        <div className="notice warn"><Icon name="alert" />
          <div>Não verificado: {g.bggId ? 'a enquete de número de jogadores não tem votos no BGG' : 'jogo sem vínculo com o BGG'}.
            {g.bggId && <> Confira manualmente em <a href={`https://boardgamegeek.com/boardgame/${g.bggId}`} target="_blank" rel="noreferrer">boardgamegeek.com/boardgame/{g.bggId}</a> (seção Community).</>}</div>
        </div>
      ) : (
        <>
          <table className="poll">
            <thead><tr><th>Jogadores</th><th>Best</th><th>Recommended</th><th>Not Rec.</th><th style={{ width: '35%' }}>Distribuição</th><th>Leitura</th></tr></thead>
            <tbody>
              {g.poll.map((p) => {
                const top = p.numPlayers === g.bestCount1 || p.numPlayers === g.bestCount2;
                const n = parseInt(p.numPlayers, 10);
                const rec = /^\d+$/.test(p.numPlayers) && g.recommendedCounts?.includes(n);
                return (
                  <tr key={p.numPlayers} className={top ? 'top' : ''}>
                    <td>{p.numPlayers}{p.numPlayers.endsWith('+') && <span className="hint"> (acima do máx.)</span>}</td>
                    <td>{p.best}</td><td>{p.recommended}</td><td>{p.notRecommended}</td>
                    <td>
                      <div className="bar" style={{ width: `${((p.best + p.recommended + p.notRecommended) / maxVotes) * 100}%` }}>
                        <i style={{ background: 'var(--ok)', flex: p.best }} /><i style={{ background: '#9bc59d', flex: p.recommended }} /><i style={{ background: 'var(--danger)', flex: p.notRecommended }} />
                      </div>
                    </td>
                    <td>{p.numPlayers === g.bestCount1 ? '1º melhor' : p.numPlayers === g.bestCount2 ? '2º melhor' : rec ? 'Recomendado' : ''}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <div className="hint">
            Total de votantes: {g.pollTotalVotes}. {status?.bestWithMethod}
            {g.pollBestSummary && <> Resumo do próprio BGG: “{g.pollBestSummary}”{g.pollRecSummary ? `, “${g.pollRecSummary}”` : ''}.</>}
            {g.bggId && <> <a href={`https://boardgamegeek.com/boardgame/${g.bggId}`} target="_blank" rel="noreferrer">Conferir no BGG</a>.</>}
          </div>
        </>
      )}

      <h3>Tempo de jogo por número de jogadores</h3>
      <div className="kv">
        <div><div className="k">Mínimo oficial<SrcBadge g={g} field="min_playtime" /></div><div className="v">{g.minPlaytime ? `${g.minPlaytime} min` : '—'}</div></div>
        <div><div className="k">Máximo oficial<SrcBadge g={g} field="max_playtime" /></div><div className="v">{g.maxPlaytime ? `${g.maxPlaytime} min` : '—'}</div></div>
        <div><div className="k">Sessão típica</div><div className="v">{typicalTime(g) ? `${typicalTime(g)} min` : '—'}</div><div className="s">{g.typicalTimeManual ? 'Informado por você' : g.playingTime ? '“Playing time” do BGG' : 'Não disponível'}</div></div>
        <div><div className="k">Minutos por jogador<SrcBadge g={g} field="time_per_player" /></div><div className="v">{g.timePerPlayerManual != null ? `${g.timePerPlayerManual > 0 ? '+' : ''}${g.timePerPlayerManual} min` : <span className="unverified">Não disponível</span>}</div><div className="s">{g.timePerPlayerManual != null ? 'Estimativa sua' : 'O BGG não publica'}</div></div>
      </div>
      {table.length > 0 && (
        <table className="poll">
          <thead><tr><th>Jogadores</th><th>Tempo estimado</th><th style={{ textAlign: 'left' }}>Origem</th></tr></thead>
          <tbody>{table.map((r) => (
            <tr key={r.players}><td>{r.players}</td><td>{r.minutes != null ? `~${r.minutes} min` : <span className="unverified">Não disponível</span>}</td><td style={{ textAlign: 'left' }} className="hint">{r.note}</td></tr>
          ))}</tbody>
        </table>
      )}
      <div className="card-panel">
        <div className="label">Sua estimativa (opcional)</div>
        <div className="hint">O tempo nem sempre cresce de forma linear. Preencha apenas se você tiver uma referência (sua experiência, regra do manual etc.).</div>
        <div className="grid-3">
          <label className="field"><span>Sessão típica (min)</span><input className="input" type="number" min={1} value={typical} onChange={(e) => setTypical(e.target.value)} placeholder={g.playingTime?.toString() ?? ''} /></label>
          <label className="field"><span>Com quantos jogadores</span><input className="input" type="number" min={1} value={basePlayers} onChange={(e) => setBasePlayers(e.target.value)} placeholder="ex.: 2" /></label>
          <label className="field"><span>+ min por jogador extra</span><input className="input" type="number" value={perPlayer} onChange={(e) => setPerPlayer(e.target.value)} placeholder="ex.: 15" /></label>
        </div>
        <label className="field"><span>De onde vem a estimativa</span><input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="ex.: nossas partidas, manual diz 30 min por jogador" /></label>
        <div className="btn-row">
          <button className="btn primary" onClick={() => {
            const pp = num(perPlayer), bp = num(basePlayers);
            if ((pp == null) !== (bp == null)) return void update(() => Promise.reject(new Error('Informe os minutos por jogador e com quantos jogadores vale a sessão típica.')));
            void update(() => api.patchGame(g.id, { typicalTimeManual: num(typical), timePerPlayerManual: pp, timeBasePlayersManual: bp, timeNote: note || null }), 'Estimativa salva.');
          }}>Salvar estimativa</button>
          {(g.typicalTimeManual != null || g.timePerPlayerManual != null) && (
            <button className="btn ghost" onClick={() => {
              setTypical(''); setPerPlayer(''); setBasePlayers(''); setNote('');
              void update(() => api.patchGame(g.id, { typicalTimeManual: null, timePerPlayerManual: null, timeBasePlayersManual: null, timeNote: null }), 'Estimativa removida.');
            }}>Remover estimativa</button>
          )}
        </div>
      </div>
    </div>
  );
}

const FIELD_LABELS: Record<string, string> = {
  name_en: 'Nome', year: 'Ano', min_players: 'Mín. jogadores', max_players: 'Máx. jogadores', playing_time: 'Tempo típico',
  min_playtime: 'Tempo mínimo', max_playtime: 'Tempo máximo', weight: 'Peso', image_url: 'Imagem', best_with: 'Melhor com (comunidade)',
  time_per_player: 'Tempo por jogador', expansion_type: 'Tipo de expansão', description: 'Descrição', min_age: 'Idade mínima',
  thumbnail_url: 'Miniatura',
};
const FIELD_API: Record<string, string> = {
  name_en: 'nameEn', year: 'year', min_players: 'minPlayers', max_players: 'maxPlayers', playing_time: 'playingTime',
  min_playtime: 'minPlaytime', max_playtime: 'maxPlaytime', weight: 'weight', image_url: 'image', expansion_type: 'expansionType',
  description: 'description', min_age: 'minAge', thumbnail_url: 'thumb',
};

function SourcesTab({ g, update }: { g: GameDetail; update: (fn: () => Promise<GameDetail>, msg?: string) => Promise<boolean> }) {
  return (
    <div className="section">
      <div className="notice info"><Icon name="info" />
        <div>
          <b>Legenda:</b> <span className="src bgg">BGG</span> dado oficial do BoardGameGeek · <span className="src calculated">calculado</span> derivado de dados do BGG ·
          {' '}<span className="src inferred">inferido</span> classificação da aplicação · <span className="src manual">manual</span> informado por você ·
          {' '}<span className="src unavailable">n/d</span> não disponível.
        </div>
      </div>
      <div className="kv">
        <div><div className="k">ID do BGG</div><div className="v">{g.bggId ?? '—'}</div><div className="s">{g.bggType === 'boardgameexpansion' ? 'Classificado como expansão' : g.bggType === 'boardgame' ? 'Classificado como jogo' : 'Sem vínculo'}</div></div>
        <div><div className="k">Última busca no BGG</div><div className="v" style={{ fontSize: 15 }}>{g.bggFetchedAt ? new Date(g.bggFetchedAt + 'Z').toLocaleString('pt-BR') : '—'}</div></div>
        <div><div className="k">Cadastrado em</div><div className="v" style={{ fontSize: 15 }}>{new Date(g.createdAt + 'Z').toLocaleDateString('pt-BR')}</div></div>
      </div>
      {g.bggError && <div className="notice danger"><Icon name="alert" />Última consulta ao BGG falhou: {g.bggError}</div>}
      <table className="poll">
        <thead><tr><th>Campo</th><th style={{ textAlign: 'left' }}>Origem</th><th style={{ textAlign: 'left' }}>Observação</th><th style={{ textAlign: 'left' }}>Atualizado</th><th /></tr></thead>
        <tbody>
          {g.fieldSources.map((f) => (
            <tr key={f.field}>
              <td>{FIELD_LABELS[f.field] ?? f.field}</td>
              <td style={{ textAlign: 'left' }}><span className={`src ${f.status !== 'verified' ? f.status : f.source}`}>{f.status === 'unavailable' ? 'não disponível' : f.status === 'unverified' ? 'não verificado' : f.source}</span></td>
              <td style={{ textAlign: 'left' }} className="hint">{f.note}</td>
              <td style={{ textAlign: 'left' }} className="hint">{new Date(f.updatedAt.replace(' ', 'T') + (f.updatedAt.includes('Z') ? '' : 'Z')).toLocaleDateString('pt-BR')}</td>
              <td>{g.bggId && g.manualFields.includes(f.field) && FIELD_API[f.field] && (
                <button className="btn small ghost" onClick={() => update(() => api.restoreField(g.id, FIELD_API[f.field]), 'Valor do BGG restaurado.')}>Usar valor do BGG</button>
              )}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {g.otherRelations.length > 0 && (
        <div><div className="label">Outras relações no BGG</div>
          <ul>{g.otherRelations.map((r) => <li key={r.relationId}>{r.relation === 'implementation_of' ? 'Reimplementa' : r.relation === 'integrates_with' ? 'Integra com' : r.relation}: {r.name}{r.bggId ? <> (<a href={`https://boardgamegeek.com/boardgame/${r.bggId}`} target="_blank" rel="noreferrer">BGG #{r.bggId}</a>)</> : ''}</li>)}</ul>
        </div>
      )}
    </div>
  );
}
