import { useEffect, useRef, useState } from 'react';
import { api, ApiError } from '../lib/api';
import { useStore } from '../lib/store';
import type { BggSearchResult, LocationType, OwnershipStatus } from '../../shared/types';
import { LOCATION_LABELS } from '../../shared/domain';
import { Icon } from './Icon';
import { Modal, Spinner } from './ui';

export function BggResults({ results, onPick, selected }: { results: BggSearchResult[]; onPick: (r: BggSearchResult) => void; selected?: number | null }) {
  return (
    <div className="match-list" role="listbox">
      {results.map((r) => (
        <div key={r.bggId} role="option" aria-selected={selected === r.bggId} tabIndex={0} className={`match${selected === r.bggId ? ' sel' : ''}`}
          onClick={() => onPick(r)} onKeyDown={(e) => { if (e.key === 'Enter') onPick(r); }} style={{ gridTemplateColumns: '38px 1fr auto' }}>
          {r.thumb ? <img src={r.thumb} alt="" loading="lazy" /> : <div className="ph" />}
          <div style={{ minWidth: 0 }}>
            <div style={{ fontWeight: 600 }}>{r.primaryName ?? r.name}{r.year ? <span className="muted"> ({r.year})</span> : ''}</div>
            <div className="hint">
              {r.nameType === 'alternate' && r.primaryName && r.primaryName !== r.name ? `Encontrado como “${r.name}” · ` : ''}
              {r.type === 'boardgameexpansion' ? `Expansão${r.isExpansionOf?.length ? ` de ${r.isExpansionOf.map((b) => b.name).join(', ')}` : ''}` : r.standaloneExpansion ? 'Jogo independente (também listado como expansão)' : 'Jogo'}
              {r.usersRated ? ` · ${r.usersRated.toLocaleString('pt-BR')} avaliações` : ''} · BGG #{r.bggId}
            </div>
          </div>
          {r.inCollectionGameId ? <span className="badge warn">Já cadastrado</span> : <a className="btn ghost small" href={`https://boardgamegeek.com/boardgame/${r.bggId}`} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} aria-label="Abrir no BGG"><Icon name="external" size={13} /></a>}
        </div>
      ))}
    </div>
  );
}

export function BggPicker({ title, initialQuery = '', onPick, onClose, note, withStatus }: {
  title: string; initialQuery?: string; onPick: (r: BggSearchResult, status?: OwnershipStatus) => Promise<void> | void; onClose: () => void; note?: string; withStatus?: boolean;
}) {
  const [q, setQ] = useState(initialQuery);
  const [results, setResults] = useState<BggSearchResult[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [status, setStatus] = useState<OwnershipStatus>('owned');
  const [busy, setBusy] = useState(false);
  const search = async (query = q) => {
    if (query.trim().length < 2) return;
    setLoading(true); setErr(null);
    try { setResults(await api.bggSearch(query.trim())); } catch (e) { setErr((e as Error).message); setResults(null); } finally { setLoading(false); }
  };
  useEffect(() => { if (initialQuery) void search(initialQuery); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <Modal title={title} onClose={onClose} wide>
      {note && <div className="hint">{note}</div>}
      <form className="btn-row" onSubmit={(e) => { e.preventDefault(); void search(); }}>
        <input className="input" style={{ flex: 1 }} autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Nome do jogo (inglês ou português)" aria-label="Buscar no BGG" />
        {withStatus && (
          <select className="input" style={{ width: 'auto' }} value={status} onChange={(e) => setStatus(e.target.value as OwnershipStatus)} aria-label="Status">
            <option value="owned">Possuo</option><option value="wishlist">Quero comprar</option>
          </select>
        )}
        <button className="btn primary" disabled={loading}>{loading ? <Spinner /> : <Icon name="search" />}Buscar</button>
      </form>
      {err && <div className="notice danger"><Icon name="alert" />{err}</div>}
      {results && results.length === 0 && <div className="hint">Nenhum resultado. Tente o nome em inglês ou outra grafia.</div>}
      {results && results.length > 0 && <BggResults results={results} onPick={async (r) => { if (busy) return; setBusy(true); try { await onPick(r, status); } finally { setBusy(false); } }} />}
      {busy && <div className="hint"><Spinner /> Buscando dados no BGG…</div>}
    </Modal>
  );
}

export function AddGameDialog({ onClose, openGame }: { onClose: () => void; openGame: (id: number) => void }) {
  const { status, owners, games, reloadGames, toast } = useStore();
  const me = owners.find((o) => o.isMe);
  const [mode, setMode] = useState<'bgg' | 'manual'>(status?.bggConfigured ? 'bgg' : 'manual');
  const [q, setQ] = useState('');
  const [results, setResults] = useState<BggSearchResult[] | null>(null);
  const [picked, setPicked] = useState<BggSearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [own, setOwn] = useState({ ownershipStatus: 'owned' as OwnershipStatus, ownerId: me?.id ?? null as number | null, locationType: 'with_me' as LocationType, locationPerson: '' });
  const [man, setMan] = useState({ nameEn: '', namePt: '', year: '', minPlayers: '', maxPlayers: '', playingTime: '', weight: '', kind: 'base', baseGameId: '' });
  const inputRef = useRef<HTMLInputElement>(null);

  const search = async () => {
    if (q.trim().length < 2) return;
    setLoading(true); setErr(null); setPicked(null);
    try { setResults(await api.bggSearch(q.trim())); } catch (e) { setErr((e as Error).message); } finally { setLoading(false); }
  };

  const ownership = {
    ownershipStatus: own.ownershipStatus, ownerId: own.ownerId, locationType: own.locationType,
    locationPerson: ['with_friend', 'lent_out', 'borrowed'].includes(own.locationType) ? own.locationPerson || null : null,
  };

  const addBgg = async () => {
    if (!picked) return;
    setLoading(true); setErr(null);
    try {
      const g = await api.addFromBgg({ bggId: picked.bggId, ...ownership, ownershipStatus: own.ownershipStatus === 'not_owned' || own.ownershipStatus === 'unverified' ? 'reference' : own.ownershipStatus });
      await reloadGames();
      toast(`${g.nameEn} adicionado.`);
      onClose(); openGame(g.id);
    } catch (e) {
      if (e instanceof ApiError && e.body?.duplicateId) { toast('Este jogo já está cadastrado.', 'error'); onClose(); openGame(e.body.duplicateId); }
      else setErr((e as Error).message);
    } finally { setLoading(false); }
  };

  const n = (s: string) => (s.trim() === '' ? null : Number(s.replace(',', '.')));
  const addManual = async () => {
    if (!man.nameEn.trim()) return setErr('Informe o nome.');
    setLoading(true); setErr(null);
    try {
      const g = await api.createGame({
        nameEn: man.nameEn.trim(), namePt: man.namePt.trim() || null, year: n(man.year), minPlayers: n(man.minPlayers), maxPlayers: n(man.maxPlayers),
        playingTime: n(man.playingTime), weight: n(man.weight), kind: man.kind, baseGameId: man.kind === 'expansion' && man.baseGameId ? Number(man.baseGameId) : null,
        ...ownership,
      });
      await reloadGames();
      toast(`${g.nameEn} cadastrado.`);
      onClose(); openGame(g.id);
    } catch (e) {
      if (e instanceof ApiError && e.body?.duplicateId) setErr(`${e.message} Abra-o pela biblioteca ou mude o nome.`);
      else setErr((e as Error).message);
    } finally { setLoading(false); }
  };

  const ownershipFields = (
    <div className="card-panel" style={{ marginBottom: 0 }}>
      <div className="grid-2">
        <label className="field"><span>Status</span>
          <select className="input" value={own.ownershipStatus} onChange={(e) => setOwn({ ...own, ownershipStatus: e.target.value as OwnershipStatus })}>
            <option value="owned">Possuo (coleção física)</option><option value="wishlist">Quero comprar</option>
            <option value="want_to_try">Quero experimentar</option><option value="reference">Só consulta</option>
          </select>
        </label>
        <label className="field"><span>Proprietário</span>
          <select className="input" value={own.ownerId ?? ''} onChange={(e) => setOwn({ ...own, ownerId: e.target.value ? Number(e.target.value) : null })}>
            {owners.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
        </label>
        <label className="field"><span>Onde está</span>
          <select className="input" value={own.locationType} onChange={(e) => setOwn({ ...own, locationType: e.target.value as LocationType })}>
            {(Object.keys(LOCATION_LABELS) as LocationType[]).map((k) => <option key={k} value={k}>{LOCATION_LABELS[k]}</option>)}
          </select>
        </label>
        {['with_friend', 'lent_out', 'borrowed'].includes(own.locationType) && (
          <label className="field"><span>Com quem</span><input className="input" value={own.locationPerson} onChange={(e) => setOwn({ ...own, locationPerson: e.target.value })} /></label>
        )}
      </div>
    </div>
  );

  return (
    <Modal title="Adicionar jogo" onClose={onClose} wide footer={<>
      <button className="btn ghost" onClick={onClose}>Cancelar</button>
      {mode === 'bgg'
        ? <button className="btn primary" disabled={!picked || loading} onClick={addBgg}>{loading && <Spinner />}Adicionar à coleção</button>
        : <button className="btn primary" disabled={loading} onClick={addManual}>{loading && <Spinner />}Cadastrar</button>}
    </>}>
      <div className="seg">
        <button className={mode === 'bgg' ? 'on' : ''} onClick={() => setMode('bgg')}>Buscar no BGG</button>
        <button className={mode === 'manual' ? 'on' : ''} onClick={() => setMode('manual')}>Cadastro manual</button>
      </div>
      {err && <div className="notice danger"><Icon name="alert" />{err}</div>}
      {mode === 'bgg' ? (
        <>
          {!status?.bggConfigured && <div className="notice warn"><Icon name="info" />O BGG não está configurado neste servidor (falta BGG_API_TOKEN). Use o cadastro manual ou veja as Configurações.</div>}
          <form className="btn-row" onSubmit={(e) => { e.preventDefault(); void search(); }}>
            <input ref={inputRef} className="input" style={{ flex: 1 }} autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ex.: Catan, Pandemia, Wingspan" aria-label="Nome do jogo" />
            <button className="btn" disabled={loading || q.trim().length < 2}>{loading && !picked ? <Spinner /> : <Icon name="search" />}Buscar</button>
          </form>
          {results && results.length === 0 && <div className="hint">Nenhum resultado no BGG.</div>}
          {results && results.length > 0 && <BggResults results={results} selected={picked?.bggId} onPick={setPicked} />}
          {picked && (
            <>
              {picked.inCollectionGameId && <div className="notice warn"><Icon name="alert" />Este item já está cadastrado. Se estiver como “não verificado/só consulta”, ele será atualizado com o status abaixo.</div>}
              {picked.type === 'boardgameexpansion' && <div className="hint">É uma expansão: o jogo-base será cadastrado como “Só consulta” se ainda não estiver na coleção.</div>}
              {ownershipFields}
            </>
          )}
        </>
      ) : (
        <>
          <div className="grid-2">
            <label className="field"><span>Nome *</span><input className="input" autoFocus value={man.nameEn} onChange={(e) => setMan({ ...man, nameEn: e.target.value })} /></label>
            <label className="field"><span>Nome em português</span><input className="input" value={man.namePt} onChange={(e) => setMan({ ...man, namePt: e.target.value })} /></label>
          </div>
          <div className="grid-4">
            <label className="field"><span>Ano</span><input className="input" type="number" value={man.year} onChange={(e) => setMan({ ...man, year: e.target.value })} /></label>
            <label className="field"><span>Mín. jogadores</span><input className="input" type="number" min={1} value={man.minPlayers} onChange={(e) => setMan({ ...man, minPlayers: e.target.value })} /></label>
            <label className="field"><span>Máx. jogadores</span><input className="input" type="number" min={1} value={man.maxPlayers} onChange={(e) => setMan({ ...man, maxPlayers: e.target.value })} /></label>
            <label className="field"><span>Tempo (min)</span><input className="input" type="number" min={1} value={man.playingTime} onChange={(e) => setMan({ ...man, playingTime: e.target.value })} /></label>
            <label className="field"><span>Peso (1–5)</span><input className="input" inputMode="decimal" value={man.weight} onChange={(e) => setMan({ ...man, weight: e.target.value })} /></label>
            <label className="field"><span>Tipo</span>
              <select className="input" value={man.kind} onChange={(e) => setMan({ ...man, kind: e.target.value })}><option value="base">Jogo</option><option value="expansion">Expansão</option></select>
            </label>
            {man.kind === 'expansion' && (
              <label className="field" style={{ gridColumn: 'span 2' }}><span>Jogo-base</span>
                <select className="input" value={man.baseGameId} onChange={(e) => setMan({ ...man, baseGameId: e.target.value })}>
                  <option value="">—</option>
                  {games.filter((x) => x.kind === 'base').sort((a, b) => a.nameEn.localeCompare(b.nameEn)).map((x) => <option key={x.id} value={x.id}>{x.nameEn}</option>)}
                </select>
              </label>
            )}
          </div>
          <div className="hint">Dados informados aqui ficam marcados como “manual”. Depois você pode vincular o jogo ao BGG na ficha dele.</div>
          {ownershipFields}
        </>
      )}
    </Modal>
  );
}
