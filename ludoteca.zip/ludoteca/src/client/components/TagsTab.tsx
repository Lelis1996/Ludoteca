import { useState } from 'react';
import { api } from '../lib/api';
import { useStore } from '../lib/store';
import type { GameDetail, GameTag } from '../../shared/types';
import { Icon } from './Icon';

type Update = (fn: () => Promise<GameDetail>, msg?: string) => Promise<boolean>;

const SOURCE_LABEL: Record<string, string> = {
  bgg_derived: 'Derivada de dado oficial do BGG',
  inferred: 'Inferida pela aplicação — confira',
  manual: 'Adicionada por você',
};

export function TagsTab({ g, update }: { g: GameDetail; update: Update }) {
  const { tags, reloadTags } = useStore();
  const [newTag, setNewTag] = useState('');
  const has = new Set(g.tags.map((t) => t.id));
  const groups: [string, GameTag[]][] = [
    ['Derivadas de dados oficiais do BGG', g.tags.filter((t) => t.source === 'bgg_derived')],
    ['Inferidas pela aplicação', g.tags.filter((t) => t.source === 'inferred')],
    ['Adicionadas por você', g.tags.filter((t) => t.source === 'manual')],
  ];
  const add = async (input: { tagId?: number; name?: string }) => {
    if (await update(() => api.addTag(g.id, input), 'Etiqueta adicionada.')) { setNewTag(''); await reloadTags(); }
  };
  const available = tags.filter((t) => !has.has(t.id));
  return (
    <div className="section">
      {groups.map(([label, list]) => (
        <div key={label}>
          <div className="label" style={{ marginBottom: 6 }}>{label}</div>
          {list.length === 0 ? <div className="hint">Nenhuma.</div> : (
            <div className="chips">
              {list.map((t) => (
                <span key={t.id} className={`chip src-${t.source}`} title={`${SOURCE_LABEL[t.source]}${t.detail ? ` — ${t.detail}` : ''}`}>
                  {t.name}
                  <button className="btn ghost small" style={{ padding: '0 2px' }} aria-label={`Remover ${t.name}`}
                    onClick={() => update(() => api.removeTag(g.id, t.id), t.source === 'manual' ? 'Etiqueta removida.' : 'Etiqueta removida — não voltará nas próximas atualizações.')}><Icon name="x" size={12} /></button>
                </span>
              ))}
            </div>
          )}
          {list.some((t) => t.detail) && (
            <ul className="hint" style={{ margin: '6px 0 0', paddingLeft: 18 }}>
              {list.filter((t) => t.detail).map((t) => <li key={t.id}><b>{t.name}</b>: {t.detail}</li>)}
            </ul>
          )}
        </div>
      ))}
      {g.rejectedTags.length > 0 && (
        <div>
          <div className="label" style={{ marginBottom: 6 }}>Removidas por você (não voltam ao atualizar)</div>
          <div className="chips">{g.rejectedTags.map((t) => (
            <button key={t.id} className="chip exclude" title="Clique para restaurar" onClick={() => update(() => api.restoreTag(g.id, t.id), 'Etiqueta restaurada.')}>{t.name}</button>
          ))}</div>
        </div>
      )}
      <div className="card-panel">
        <div className="label">Adicionar etiqueta</div>
        <div className="btn-row">
          <select className="input" style={{ flex: 1, minWidth: 180 }} value="" onChange={(e) => e.target.value && add({ tagId: Number(e.target.value) })} aria-label="Etiqueta existente">
            <option value="">Escolher etiqueta existente…</option>
            {['style', 'mechanic', 'interaction', 'luck', 'duration', 'custom'].map((grp) => (
              <optgroup key={grp} label={{ style: 'Estilo', mechanic: 'Mecânicas', interaction: 'Interação', luck: 'Sorte', duration: 'Duração', custom: 'Minhas' }[grp]}>
                {available.filter((t) => t.grp === grp).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
              </optgroup>
            ))}
          </select>
          <input className="input" style={{ flex: 1, minWidth: 160 }} placeholder="ou crie uma nova" value={newTag} onChange={(e) => setNewTag(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && newTag.trim()) void add({ name: newTag }); }} />
          <button className="btn" disabled={!newTag.trim()} onClick={() => add({ name: newTag })}><Icon name="plus" size={14} />Criar</button>
        </div>
      </div>
      <div className="grid-2">
        <TermList title="Mecânicas oficiais (BGG)" items={g.mechanics} />
        <TermList title="Categorias oficiais (BGG)" items={g.categories} />
        <TermList title="Classificação do BGG (subdomínios)" items={g.subdomains} />
        <TermList title="Famílias (BGG)" items={g.families} />
      </div>
    </div>
  );
}

function TermList({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <div className="label" style={{ marginBottom: 6 }}>{title}</div>
      {items.length ? <div className="chips">{items.map((m) => <span key={m} className="chip">{m}</span>)}</div> : <div className="hint">Nenhuma registrada.</div>}
    </div>
  );
}
