import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['tests/unit/**/*.test.ts', 'tests/api/**/*.test.ts'],
    environment: 'node',
    testTimeout: 60000,
    env: { LUDOTECA_SKIP_ENV_FILE: '1', SEED_COLLECTION: '0' },
  },
});
