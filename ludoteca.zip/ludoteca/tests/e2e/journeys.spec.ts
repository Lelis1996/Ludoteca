import { test, expect, type Page } from '@playwright/test';
import sharp from 'sharp';
import os from 'node:os';
import path from 'node:path';

/**
 * Jornadas principais pela interface, contra um BGG simulado (dados ilustrativos)
 * e um banco temporário.
 */
test.describe.serial('jornadas principais', () => {
  let page: Page;
  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    page.on('pageerror', (e) => { throw e; });
  });

  test('biblioteca vazia oferece formas de adicionar', async () => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Sua ludoteca está vazia' })).toBeVisible();
  });

  test('adiciona jogo buscando no BGG e mostra dados oficiais e da comunidade', async () => {
    await page.getByRole('button', { name: 'Adicionar jogo' }).first().click();
    await page.getByLabel('Nome do jogo').fill('Catan');
    await page.getByRole('button', { name: 'Buscar', exact: true }).click();
    await page.getByRole('option', { name: /CATAN \(1995\)/ }).click();
    await page.getByRole('button', { name: 'Adicionar à coleção' }).click();
    const drawer = page.getByRole('dialog', { name: 'CATAN' });
    await expect(drawer.getByRole('heading', { name: 'CATAN' })).toBeVisible();
    await expect(drawer.getByText('Melhor 4 e 3')).toBeVisible();
    await expect(drawer.getByText('2.28 / 5')).toBeVisible();
    await drawer.getByRole('tab', { name: 'Jogadores e tempo' }).click();
    await expect(drawer.getByText('1º melhor')).toBeVisible();
    await expect(drawer.getByText('Não disponível').first()).toBeVisible(); // minutos por jogador
  });

  test('expansões: busca no BGG, marca uma como possuída e mostra o resumo', async () => {
    const drawer = page.getByRole('dialog', { name: 'CATAN' });
    await drawer.getByRole('tab', { name: /Expansões/ }).click();
    await drawer.getByRole('button', { name: /Buscar dados de 5 expansão/ }).click();
    await expect(drawer.getByText('Possuo 0 de 2 expansões conhecidas')).toBeVisible();
    await drawer.getByLabel('Status de CATAN: Seafarers').selectOption('owned');
    await expect(drawer.getByText('Possuo 1 de 2 expansões conhecidas')).toBeVisible();
    await drawer.getByRole('button', { name: 'Não possuo' }).click();
    await expect(drawer.getByText('CATAN: Cities & Knights')).toBeVisible();
    await expect(drawer.getByText('CATAN: Seafarers')).toHaveCount(0);
    await drawer.getByRole('button', { name: 'Fechar' }).click();
  });

  test('cadastra amigo com cor e empresta jogo; aviso de localização aparece', async () => {
    await page.getByRole('link', { name: /Proprietários/ }).click();
    await page.getByLabel('Nome do proprietário').fill('Fulano');
    await page.getByRole('button', { name: 'Adicionar', exact: true }).click();
    await expect(page.getByText('Proprietário adicionado.')).toBeVisible();
    await page.getByRole('link', { name: /Biblioteca/ }).click();

    // jogo de Fulano que está na casa dele
    await page.getByRole('button', { name: 'Adicionar jogo' }).first().click();
    await page.getByLabel('Nome do jogo').fill('Pandemic');
    await page.getByRole('button', { name: 'Buscar', exact: true }).click();
    await page.getByRole('option', { name: /^Pandemic \(2008\)/ }).click();
    await page.getByRole('dialog', { name: 'Adicionar jogo' }).locator('label:has-text("Proprietário") select').selectOption({ label: 'Fulano' });
    await page.getByRole('dialog', { name: 'Adicionar jogo' }).locator('label:has-text("Onde está") select').selectOption('with_friend');
    await page.getByRole('dialog', { name: 'Adicionar jogo' }).locator('label:has-text("Com quem") input').fill('Fulano');
    await page.getByRole('button', { name: 'Adicionar à coleção' }).click();
    await page.getByRole('dialog', { name: 'Pandemic' }).getByRole('button', { name: 'Fechar' }).click();

    const card = page.getByRole('button', { name: 'Abrir Pandemic' });
    await expect(card.getByText('Com Fulano — não está comigo')).toBeVisible();
    const color = await card.locator('.game-name').evaluate((el) => getComputedStyle(el).color);
    expect(color).not.toBe('rgb(245, 241, 232)'); // diferente da cor de "Meus jogos"
  });

  test('filtros combinados: jogadores (suporta x comunidade), peso, proprietário e etiqueta', async () => {
    await expect(page.locator('.toolbar .count b')).toHaveText('2');
    await page.getByRole('group', { name: 'Número de jogadores' }).getByRole('button', { name: '2', exact: true }).click();
    await expect(page.locator('.toolbar .count b')).toHaveText('1'); // Catan é 3–4
    await page.getByRole('group', { name: 'Número de jogadores' }).getByRole('button', { name: '3', exact: true }).click();
    await page.getByRole('button', { name: 'Melhor com', exact: true }).click();
    await expect(page.locator('.toolbar .count b')).toHaveText('1'); // só Catan tem 3 entre os 2 melhores
    await page.getByRole('button', { name: 'Recomendado', exact: true }).click();
    await expect(page.locator('.toolbar .count b')).toHaveText('2');
    await page.getByRole('button', { name: 'Cooperativo', exact: true }).click();
    await expect(page.locator('.toolbar .count b')).toHaveText('1');
    await page.locator('.sidebar').getByRole('button', { name: /Fulano/ }).click();
    await page.locator('.sidebar').getByRole('button', { name: 'Médio' }).click();
    await page.getByRole('button', { name: 'Fora da minha casa' }).click();
    await expect(page.locator('.toolbar .count b')).toHaveText('1');
    await expect(page.getByRole('button', { name: 'Abrir Pandemic' })).toBeVisible();
    await page.getByRole('button', { name: /Limpar filtros/ }).click();
    await expect(page.locator('.toolbar .count b')).toHaveText('2');
    // visualização em lista com ordenação
    await page.getByRole('button', { name: 'Lista' }).click();
    await expect(page.locator('table.games tbody tr')).toHaveCount(2);
    await page.locator('table.games th button', { hasText: 'Peso' }).click();
    await expect(page.locator('table.games tbody tr').first()).toContainText('CATAN');
    await page.getByRole('button', { name: 'Grade' }).click();
  });

  test('importação por fotos (OCR local): revisão e confirmação antes de salvar', async () => {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="700">
      <rect width="1000" height="700" fill="#f4f1ea"/>
      <rect x="40" y="60" width="440" height="560" fill="#1d4ed8"/><text x="70" y="330" font-family="DejaVu Sans" font-weight="bold" font-size="60" fill="#ffffff">WINGSPAN</text>
      <rect x="520" y="60" width="440" height="560" fill="#ffffff" stroke="#000" stroke-width="4"/><text x="560" y="330" font-family="DejaVu Sans" font-weight="bold" font-size="60" fill="#111">Pandemic</text>
    </svg>`;
    const file = path.join(os.tmpdir(), `estante-${Date.now()}.png`);
    await sharp(Buffer.from(svg)).png().toFile(file);

    await page.getByRole('link', { name: /Importar fotos/ }).click();
    await page.getByTestId('photo-input').setInputFiles(file);
    await page.getByRole('button', { name: /Analisar 1 foto/ }).click();
    await expect(page.getByRole('heading', { name: /Revisão da importação/ })).toBeVisible();
    await expect(page.getByText('Analisando fotos…')).toHaveCount(0, { timeout: 90_000 });

    const wing = page.locator('.cand', { has: page.locator('input[value="WINGSPAN"]') });
    await expect(wing.getByRole('radio', { name: /Wingspan \(2019\)/ })).toHaveAttribute('aria-checked', 'true');
    const pan = page.locator('.cand', { has: page.locator('input[value="Pandemic"]') });
    await expect(pan.getByText(/Possível duplicata/)).toBeVisible();

    // nada entra na coleção antes da confirmação
    expect((await (await page.request.get('/api/games')).json()).some((g: any) => g.bggId === 266192)).toBe(false);

    await wing.getByRole('button', { name: 'Confirmar' }).click();
    await pan.getByRole('button', { name: 'Ignorar' }).click();
    await page.getByRole('button', { name: /Adicionar 1 à coleção/ }).click();
    await expect(page.getByText(/1 adicionado\(s\)/)).toBeVisible();
    await page.getByRole('link', { name: 'Ver biblioteca' }).click();
    await expect(page.getByRole('button', { name: 'Abrir Wingspan' })).toBeVisible();
  });

  test('pesquisa textual encontra o jogo-base pelo nome da expansão', async () => {
    await page.getByLabel('Pesquisar na coleção').fill('seafarers');
    await expect(page.getByRole('button', { name: 'Abrir CATAN' })).toBeVisible();
    await expect(page.getByText('Expansão encontrada: CATAN: Seafarers')).toBeVisible();
    await page.getByLabel('Pesquisar na coleção').fill('Leacock'); // designer
    await expect(page.getByRole('button', { name: 'Abrir Pandemic' })).toBeVisible();
    await page.getByLabel('Pesquisar na coleção').fill('');
  });

  test('exportação JSON e CSV disponíveis', async () => {
    const json = await (await page.request.get('/api/export.json')).json();
    expect(json.format).toBe('ludoteca-backup');
    expect(json.games.length).toBeGreaterThanOrEqual(3);
    const csv = await (await page.request.get('/api/export.csv')).text();
    expect(csv).toContain('Wingspan');
    await page.getByRole('link', { name: /Configurações/ }).click();
    const dl = page.waitForEvent('download');
    await page.getByRole('button', { name: /Backup JSON/ }).click();
    expect((await dl).suggestedFilename()).toMatch(/^ludoteca-.*\.json$/);
  });
});
