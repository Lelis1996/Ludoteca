import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import request from 'supertest';
import sharp from 'sharp';
import { createApp } from '../../src/server/app';
import { loadConfig } from '../../src/server/config';
import type { VisionProvider, DetectedBox } from '../../src/server/vision/core';
import { fakeBggFetch } from '../fixtures/bgg';

export function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'ludoteca-test-'));
}

export class FakeVision implements VisionProvider {
  name = 'fake' as const;
  label = 'Visão simulada';
  constructor(public boxes: DetectedBox[]) {}
  async analyze() { return { boxes: this.boxes, raw: { fake: true } }; }
}

export function makeApp(opts: { dataDir?: string; token?: string | null; vision?: VisionProvider | null; log?: string[] } = {}) {
  const dataDir = opts.dataDir ?? tmpDir();
  const config = loadConfig({
    dataDir, dbPath: path.join(dataDir, 'test.db'), bggToken: opts.token === undefined ? 'test-token' : opts.token,
    bggBaseUrl: 'https://boardgamegeek.com', bggMinIntervalMs: 1, downloadImages: false, visionProvider: 'none',
  });
  const ctx = createApp({ config, fetchImpl: fakeBggFetch({ log: opts.log }), sleep: async () => {}, visionProvider: opts.vision ?? null });
  return { ...ctx, dataDir, http: request(ctx.app) };
}

export async function photo(): Promise<Buffer> {
  return sharp({ create: { width: 800, height: 600, channels: 3, background: '#335577' } }).jpeg().toBuffer();
}
