import { afterEach, describe, expect, it } from 'vitest';
import { FakeVision, makeApp, photo } from './helpers';
import type { GameDetail, GameSummary, Owner } from '../../src/shared/types';
import { createApp } from '../../src/server/app';
import { loadConfig } from '../../src/server/config';
import path from 'node:path';
import request from 'supertest';

const apps: { close: () => Promise<void> }[] = [];
function app(opts?: Parameters<typeof makeApp>[0]) {
  const a = makeApp(opts);
  apps.push(a);
  return a;
}
afterEach(async () => { while (apps.length) await apps.pop()!.close(); });

async function addCatan(http: ReturnType<typeof makeApp>['http']) {
  const r = await http.post('/api/games/from-bgg').send({ bggId: 13 });
  expect(r.status).toBe(201);
  return r.body as GameDetail;
}

describe('proprietários', () => {
  it('cria "Meus jogos" e permite amigos com cores', async () => {
    const { http } = app();
    const owners = (await http.get('/api/owners')).body as Owner[];
    expect(owners).toHaveLength(1);
    expect(owners[0]).toMatchObject({ name: 'Meus jogos', isMe: true });
    const r = await http.post('/api/owners').send({ name: 'Fulano', color: '#3b82f6' });
    expect(r.status).toBe(201);
    expect((await http.post('/api/owners').send({ name: 'fulano', color: '#000000' })).status).toBe(409);
    expect((await http.post('/api/owners').send({ name: 'X', color: 'azul' })).status).toBe(400);
    expect((await http.delete(`/api/owners/${owners[0].id}`)).status).toBe(400);
  });
});

describe('cadastro manual', () => {
  it('cria, edita, valida e exclui', async () => {
    const { http } = app({ token: null });
    const r = await http.post('/api/games').send({ nameEn: 'Jogo Caseiro', minPlayers: 2, maxPlayers: 5, playingTime: 40, weight: 1.8 });
    expect(r.status).toBe(201);
    const g = r.body as GameDetail;
    expect(g.dataStatus).toBe('manual');
    expect(g.tags.map((t) => t.name)).toContain('Duração curta');
    expect((await http.post('/api/games').send({ nameEn: 'Jogo Caseiro' })).status).toBe(409);
    expect((await http.patch(`/api/games/${g.id}`).send({ minPlayers: 6 })).status).toBe(400);
    const p = await http.patch(`/api/games/${g.id}`).send({ namePt: 'Jogo da Casa', favorite: true, notes: 'presente' });
    expect(p.body).toMatchObject({ namePt: 'Jogo da Casa', favorite: true, notes: 'presente' });
    expect((await http.delete(`/api/games/${g.id}`)).status).toBe(200);
    expect((await http.get(`/api/games/${g.id}`)).status).toBe(404);
  });
});

describe('integração com o BGG', () => {
  it('adiciona jogo com dados oficiais, Best With e fontes', async () => {
    const { http } = app();
    const g = await addCatan(http);
    expect(g).toMatchObject({ bggId: 13, nameEn: 'CATAN', minPlayers: 3, maxPlayers: 4, weight: 2.28, weightVotes: 7000, year: 1995 });
    expect(g.bestCount1).toBe('4');
    expect(g.bestVotes1).toBe(520);
    expect(g.bestCount2).toBe('3');
    expect(g.recommendedCounts).toEqual([3, 4]);
    expect(g.ptVersions[0]).toMatchObject({ publisher: 'Devir' });
    expect(g.namePt).toBeNull(); // nunca preenchido automaticamente
    expect(g.mechanics).toContain('Dice Rolling');
    expect(g.designers).toEqual(['Klaus Teuber']);
    const bw = g.fieldSources.find((f) => f.field === 'best_with');
    expect(bw?.status).toBe('verified');
    expect(g.fieldSources.find((f) => f.field === 'time_per_player')?.status).toBe('unavailable');
    expect(g.tags.find((t) => t.name === 'Competitivo')?.source).toBe('inferred');
    expect(g.tags.find((t) => t.name === 'Dice rolling')?.source).toBe('bgg_derived');
  });

  it('jogo sem votos fica "não verificado"', async () => {
    const { http } = app();
    const g = (await http.post('/api/games/from-bgg').send({ bggId: 400000 })).body as GameDetail;
    expect(g.bestCount1).toBeNull();
    expect(g.recommendedCounts).toBeNull();
    expect(g.weight).toBeNull();
    expect(g.fieldSources.find((f) => f.field === 'best_with')?.status).toBe('unverified');
    expect(g.fieldSources.find((f) => f.field === 'weight')?.status).toBe('unavailable');
  });

  it('impede duplicatas pelo ID do BGG', async () => {
    const { http } = app();
    await addCatan(http);
    const r = await http.post('/api/games/from-bgg').send({ bggId: 13 });
    expect(r.status).toBe(409);
  });

  it('sem token, explica o que falta', async () => {
    const { http } = app({ token: null });
    const r = await http.get('/api/bgg/search?q=catan');
    expect(r.status).toBe(503);
    expect(r.body.error).toContain('BGG_API_TOKEN');
  });

  it('busca devolve correspondências com tipo e marcação de já cadastrado', async () => {
    const { http } = app();
    await addCatan(http);
    const r = await http.get('/api/bgg/search?q=catan');
    expect(r.body[0]).toMatchObject({ bggId: 13, type: 'boardgame', inCollectionGameId: expect.any(Number) });
    const exp = r.body.find((x: any) => x.bggId === 926);
    expect(exp.type).toBe('boardgameexpansion');
    expect(exp.isExpansionOf).toEqual([{ bggId: 13, name: 'CATAN' }]);
  });

  it('atualização do BGG preserva dados pessoais e edições manuais', async () => {
    const { http } = app();
    const g = await addCatan(http);
    const friend = (await http.post('/api/owners').send({ name: 'Fulano', color: '#22c55e' })).body as Owner;
    const tag = g.tags.find((t) => t.name === 'Competitivo')!;
    await http.patch(`/api/games/${g.id}`).send({
      ownerId: friend.id, locationType: 'borrowed', locationPerson: 'Fulano', notes: 'Caixa amassada',
      namePt: 'Catan', maxPlayers: 6, timePerPlayerManual: 20, timeBasePlayersManual: 4, favorite: true,
    });
    await http.delete(`/api/games/${g.id}/tags/${tag.id}`);
    await http.post(`/api/games/${g.id}/tags`).send({ name: 'Clássico' });
    const after = (await http.post(`/api/games/${g.id}/refresh`)).body as GameDetail;
    expect(after).toMatchObject({ ownerId: friend.id, locationType: 'borrowed', notes: 'Caixa amassada', namePt: 'Catan', maxPlayers: 6, favorite: true, timePerPlayerManual: 20 });
    expect(after.manualFields).toContain('max_players');
    expect(after.tags.map((t) => t.name)).toContain('Clássico');
    expect(after.tags.map((t) => t.name)).not.toContain('Competitivo');
    expect(after.rejectedTags.map((t) => t.name)).toContain('Competitivo');
    // restaurar o campo volta ao valor oficial
    const restored = (await http.post(`/api/games/${g.id}/restore-field`).send({ field: 'maxPlayers' })).body as GameDetail;
    expect(restored.maxPlayers).toBe(4);
  });
});

describe('expansões', () => {
  it('registra expansões como "não verificado", busca detalhes e conta só as verificadas', async () => {
    const { http } = app();
    const g = await addCatan(http);
    let d = (await http.get(`/api/games/${g.id}`)).body as GameDetail;
    expect(d.expansions).toHaveLength(5);
    expect(d.expansions.every((e) => e.ownershipStatus === 'unverified')).toBe(true);
    expect(d.expansions.every((e) => e.dataStatus === 'stub')).toBe(true);
    const r = await http.post(`/api/games/${g.id}/expansions/refresh`).send({});
    expect(r.body.updated).toBe(5);
    expect(r.body.notExpansion).toBe(1);
    d = r.body.game;
    const stats = d.expansionStats!;
    expect(stats.known).toBe(2); // promo, fã e jogo independente não contam
    expect(stats.promos).toBe(1);
    expect(stats.fan).toBe(1);
    expect(stats.standalone).toBe(1);
    expect(stats.owned).toBe(0);
    const ck = d.expansions.find((e) => e.bggId === 926)!;
    const friend = (await http.post('/api/owners').send({ name: 'Ciclano', color: '#a855f7' })).body as Owner;
    await http.patch(`/api/games/${ck.id}`).send({ ownershipStatus: 'owned', ownerId: friend.id, locationType: 'with_friend', locationPerson: 'Ciclano', pricePaid: 150 });
    const sea = d.expansions.find((e) => e.bggId === 325)!;
    await http.patch(`/api/games/${sea.id}`).send({ ownershipStatus: 'wishlist' });
    // atualizar de novo não mexe no status/proprietário
    d = (await http.post(`/api/games/${g.id}/expansions/refresh`).send({})).body.game;
    const ck2 = d.expansions.find((e) => e.bggId === 926)!;
    expect(ck2).toMatchObject({ ownershipStatus: 'owned', ownerId: friend.id, locationType: 'with_friend' });
    expect((await http.get(`/api/games/${ck.id}`)).body.pricePaid).toBe(150);
    expect(d.expansionStats).toMatchObject({ known: 2, owned: 1, wishlist: 1, withFriends: 1 });
  });

  it('adicionar uma expansão cadastra o jogo-base como "só consulta"', async () => {
    const { http } = app();
    const e = (await http.post('/api/games/from-bgg').send({ bggId: 926 })).body as GameDetail;
    expect(e.kind).toBe('expansion');
    expect(e.ownershipStatus).toBe('owned');
    expect(e.bases[0].name).toBe('CATAN');
    const base = (await http.get(`/api/games/${e.bases[0].gameId}`)).body as GameDetail;
    expect(base.ownershipStatus).toBe('reference');
    const all = (await http.get('/api/games')).body as GameSummary[];
    expect(all.find((x) => x.id === base.id)!.expansionStats!.ownedWithMeBaseAway).toBe(true);
  });

  it('associação manual e correção de associação', async () => {
    const { http } = app({ token: null });
    const base = (await http.post('/api/games').send({ nameEn: 'Base X' })).body as GameDetail;
    const exp = (await http.post('/api/games').send({ nameEn: 'Expansão Y', baseGameId: base.id })).body as GameDetail;
    expect(exp.kind).toBe('expansion');
    expect(exp.bases[0].gameId).toBe(base.id);
    const fixed = (await http.delete(`/api/relations/${exp.bases[0].relationId}`)).body as GameDetail;
    expect(fixed.bases).toHaveLength(0);
  });
});

describe('localização e empréstimos', () => {
  it('registra empréstimo e devolução no histórico', async () => {
    const { http } = app({ token: null });
    const g = (await http.post('/api/games').send({ nameEn: 'Azul' })).body as GameDetail;
    let d = (await http.patch(`/api/games/${g.id}`).send({ locationType: 'lent_out', locationPerson: 'Beltrano', loanDate: '2026-10-01', loanDueDate: '2026-11-01' })).body as GameDetail;
    expect(d.loans).toHaveLength(1);
    expect(d.loans[0]).toMatchObject({ direction: 'lent_out', person: 'Beltrano', returnedAt: null, dueDate: '2026-11-01' });
    d = (await http.post(`/api/games/${g.id}/return`)).body as GameDetail;
    expect(d.locationType).toBe('with_me');
    expect(d.loans[0].returnedAt).not.toBeNull();
  });
});

describe('backup', () => {
  it('exporta JSON/CSV e restaura em banco vazio sem duplicar', async () => {
    const a = app();
    await addCatan(a.http);
    const friend = (await a.http.post('/api/owners').send({ name: 'Fulano', color: '#3b82f6' })).body as Owner;
    const m = (await a.http.post('/api/games').send({ nameEn: 'Manual Game', ownerId: friend.id, locationType: 'with_friend', notes: 'nota' })).body as GameDetail;
    await a.http.post(`/api/games/${m.id}/tags`).send({ name: 'Favorito da família' });
    const json = (await a.http.get('/api/export.json')).body;
    expect(json.format).toBe('ludoteca-backup');
    const csv = (await a.http.get('/api/export.csv')).text;
    expect(csv).toContain('CATAN');
    expect(csv).toContain('Fulano');

    const b = app({ token: null });
    const rep = (await b.http.post('/api/import-backup').send(json)).body;
    expect(rep.added).toBe(json.games.length);
    const games = (await b.http.get('/api/games')).body as GameSummary[];
    const mg = games.find((g) => g.nameEn === 'Manual Game')!;
    const owners = (await b.http.get('/api/owners')).body as Owner[];
    expect(owners.find((o) => o.id === mg.ownerId)?.name).toBe('Fulano');
    const detail = (await b.http.get(`/api/games/${mg.id}`)).body as GameDetail;
    expect(detail.tags.map((t) => t.name)).toContain('Favorito da família');
    const catan = games.find((g) => g.bggId === 13)!;
    expect(catan.bestCount1).toBe('4');
    expect(catan.expansionStats).not.toBeNull();
    // reimportar não duplica
    const rep2 = (await b.http.post('/api/import-backup').send(json)).body;
    expect(rep2.added).toBe(0);
    expect(rep2.skippedDuplicates).toBe(json.games.length);
    // arquivo inválido é recusado
    expect((await b.http.post('/api/import-backup').send({ foo: 1 })).status).toBe(400);
  });

  it('dados persistem após reiniciar a aplicação', async () => {
    const a = makeApp({ token: null });
    await a.http.post('/api/games').send({ nameEn: 'Persistente' });
    await a.close();
    const config = loadConfig({ dataDir: a.dataDir, dbPath: path.join(a.dataDir, 'test.db'), bggToken: null, downloadImages: false });
    const again = createApp({ config, visionProvider: null });
    apps.push(again);
    const games = (await request(again.app).get('/api/games')).body as GameSummary[];
    expect(games.map((g) => g.nameEn)).toContain('Persistente');
  });
});

describe('importação por fotos', () => {
  it('detecta, sugere, avisa duplicatas e só adiciona após confirmação', async () => {
    const vision = new FakeVision([
      { title: 'Catan', confidence: 0.95, bbox: [0.1, 0.1, 0.3, 0.4] },
      { title: 'Pandemia', text: 'Pandemia', confidence: 0.9, bbox: [0.5, 0.1, 0.3, 0.4], notes: 'Edição em português' },
      { title: 'Catan Cities Knights', confidence: 0.8, isExpansion: true, baseGame: 'Catan', bbox: [0.1, 0.6, 0.3, 0.3] },
      { title: 'Xyzzy Inexistente', confidence: 0.4 },
    ]);
    const { http, imports } = app({ vision });
    const existing = await addCatan(http);
    const r = await http.post('/api/imports').attach('photos', await photo(), 'estante.jpg').field('ownershipStatus', 'owned');
    expect(r.status).toBe(201);
    const batchId = r.body.id;
    await imports.wait(batchId);
    let b = (await http.get(`/api/imports/${batchId}`)).body;
    expect(b.status).toBe('review');
    const cands = b.photos[0].candidates;
    expect(cands).toHaveLength(4);
    const [cat, pan, ck, none] = cands;
    expect(cat.selectedBggId).toBe(13);
    expect(cat.warnings.join(' ')).toContain('duplicata');
    expect(cat.crop).toMatch(/^\/uploads\//);
    expect(pan.selectedBggId).toBe(30549);
    expect(ck.selectedBggId).toBe(926);
    expect(none.matches).toHaveLength(0);
    // nada foi adicionado ainda
    expect(((await http.get('/api/games')).body as GameSummary[]).some((g) => g.bggId === 30549)).toBe(false);

    for (const c of [cat, pan, ck]) await http.patch(`/api/import-candidates/${c.id}`).send({ status: 'confirmed' });
    await http.patch(`/api/import-candidates/${none.id}`).send({ status: 'ignored' });
    const res = (await http.post(`/api/imports/${batchId}/commit`).send({})).body;
    expect(res.added).toBe(1);   // Pandemic
    expect(res.updated).toBe(1); // expansão que estava "não verificada" vira possuída
    expect(res.duplicates).toBe(1); // Catan já existia
    const games = (await http.get('/api/games')).body as GameSummary[];
    expect(games.filter((g) => g.bggId === 13)).toHaveLength(1);
    expect(games.find((g) => g.bggId === 30549)?.ownershipStatus).toBe('owned');
    expect(games.find((g) => g.bggId === 926)?.ownershipStatus).toBe('owned');
    expect(games.find((g) => g.bggId === 325)?.ownershipStatus).toBe('unverified'); // não presume posse
    b = (await http.get(`/api/imports/${batchId}`)).body;
    expect(b.status).toBe('done');
    void existing;
  });

  it('busca manual e inclusão manual na revisão', async () => {
    const { http, imports } = app({ vision: new FakeVision([{ title: 'Wngspn', confidence: 0.3 }]) });
    const r = await http.post('/api/imports').attach('photos', await photo(), 'a.jpg');
    await imports.wait(r.body.id);
    let b = (await http.get(`/api/imports/${r.body.id}`)).body;
    const c = b.photos[0].candidates[0];
    expect(c.selectedBggId).toBeNull();
    await http.post(`/api/import-candidates/${c.id}/search`).send({ query: 'Wingspan' });
    await http.post(`/api/import-photos/${b.photos[0].id}/candidates`).send({ title: 'Pandemic' });
    b = (await http.get(`/api/imports/${r.body.id}`)).body;
    expect(b.photos[0].candidates.map((x: any) => x.selectedBggId)).toEqual([266192, 30549]);
  });

  it('sem reconhecimento disponível, permite cadastro manual a partir da foto', async () => {
    const { http, imports } = app({ token: null, vision: null });
    const r = await http.post('/api/imports').attach('photos', await photo(), 'a.jpg');
    await imports.wait(r.body.id);
    let b = (await http.get(`/api/imports/${r.body.id}`)).body;
    expect(b.photos[0].error).toContain('manualmente');
    const { body } = await http.post(`/api/import-photos/${b.photos[0].id}/candidates`).send({ title: 'Jogo da Foto' });
    await http.patch(`/api/import-candidates/${body.id}`).send({ status: 'confirmed' });
    const res = (await http.post(`/api/imports/${r.body.id}/commit`).send({})).body;
    expect(res.added).toBe(1);
    b = (await http.get(`/api/imports/${r.body.id}`)).body;
    expect(b.photos[0].candidates[0].status).toBe('added');
  });

  it('recusa arquivo que não é imagem', async () => {
    const { http } = app({ vision: null });
    const r = await http.post('/api/imports').attach('photos', Buffer.from('nao sou imagem'), 'x.jpg');
    expect(r.status).toBe(400);
  });
});

describe('coleção inicial, cópias e vínculo em lote', () => {
  it('cadastra a coleção das fotos com os proprietários e cores', async () => {
    const { http } = app();
    const r = (await http.post('/api/seed-collection')).body;
    expect(r.added).toBeGreaterThan(70);
    const owners = (await http.get('/api/owners')).body as Owner[];
    expect(owners.find((o) => o.name === 'Arthur Bunte')?.color).toBe('#1b2a6b');
    expect(owners.find((o) => o.name === 'André Salim')?.color).toBe('#22c55e');
    const games = (await http.get('/api/games')).body as GameSummary[];
    const me = owners.find((o) => o.isMe)!;
    expect(games.some((g) => g.nameEn === 'Azul Mini' && g.ownerId === me.id)).toBe(true);
    // mesmo jogo, proprietários diferentes = cópias diferentes
    expect(games.filter((g) => g.nameEn === 'Dixit')).toHaveLength(2);
    const wingspan = games.find((g) => g.nameEn === 'Wingspan')!;
    const exps = games.filter((g) => g.baseIds.includes(wingspan.id));
    expect(exps).toHaveLength(2);
    const arthurs = games.filter((g) => g.ownerId === owners.find((o) => o.name === 'Arthur Bunte')!.id);
    expect(arthurs.every((g) => g.locationType === 'with_friend' && g.locationPerson === 'Arthur Bunte')).toBe(true);
    // rodar de novo não duplica
    expect((await http.post('/api/seed-collection')).body.added).toBe(0);
  });

  it('vincula em lote ao BGG mantendo dados pessoais e mescla expansões', async () => {
    const { http, imports } = app();
    const fulano = (await http.post('/api/owners').send({ name: 'Fulano', color: '#3b82f6' })).body as Owner;
    const catan = (await http.post('/api/games').send({ nameEn: 'Catan', notes: 'minha caixa' })).body as GameDetail;
    const ck = (await http.post('/api/games').send({ nameEn: 'Catan: Cities & Knights', baseGameId: catan.id, kind: 'expansion' })).body as GameDetail;
    const pandemic = (await http.post('/api/games').send({ nameEn: 'Pandemic', ownerId: fulano.id, locationType: 'with_friend', locationPerson: 'Fulano' })).body as GameDetail;
    // o mesmo Pandemic também é meu: cópia separada
    const pan2 = (await http.post('/api/games').send({ nameEn: 'Pandemic' })).body as GameDetail;
    const batch = (await http.post('/api/imports/link-bgg').send({})).body;
    expect(batch.source).toBe('list');
    await imports.wait(batch.id);
    const b = (await http.get(`/api/imports/${batch.id}`)).body;
    const cands = b.photos[0].candidates as any[];
    expect(cands).toHaveLength(4);
    for (const c of cands) {
      expect(c.selectedBggId).not.toBeNull();
      await http.patch(`/api/import-candidates/${c.id}`).send({ status: 'confirmed' });
    }
    const res = (await http.post(`/api/imports/${batch.id}/commit`).send({})).body;
    expect(res.errors).toEqual([]);
    expect(res.updated).toBe(4);
    const all = (await http.get('/api/games')).body as GameSummary[];
    expect(all.filter((g) => g.bggId === 30549)).toHaveLength(2); // duas cópias do Pandemic
    expect(all.find((g) => g.id === pandemic.id)).toMatchObject({ ownerId: fulano.id, locationType: 'with_friend', bestCount1: '4' });
    expect(all.find((g) => g.id === pan2.id)?.bggId).toBe(30549);
    const c = (await http.get(`/api/games/${catan.id}`)).body as GameDetail;
    expect(c).toMatchObject({ bggId: 13, notes: 'minha caixa', minPlayers: 3 });
    // a expansão manual foi vinculada sem duplicar o registro automático
    expect(c.expansions.filter((e) => e.bggId === 926)).toHaveLength(1);
    expect(c.expansions.find((e) => e.bggId === 926)!.id).toBe(ck.id);
    expect(c.expansions.find((e) => e.id === ck.id)!.ownershipStatus).toBe('owned');
  });

  it('adicionar pelo BGG um jogo que um amigo já tem cria outra cópia', async () => {
    const { http } = app();
    const fulano = (await http.post('/api/owners').send({ name: 'Fulano', color: '#3b82f6' })).body as Owner;
    await http.post('/api/games/from-bgg').send({ bggId: 266192, ownerId: fulano.id });
    const mine = await http.post('/api/games/from-bgg').send({ bggId: 266192 });
    expect(mine.status).toBe(201);
    expect((await http.post('/api/games/from-bgg').send({ bggId: 266192 })).status).toBe(409);
    const all = (await http.get('/api/games')).body as GameSummary[];
    expect(all.filter((g) => g.bggId === 266192)).toHaveLength(2);
  });
});
