import { describe, expect, it } from 'vitest';
import { applyFilters, DEFAULT_FILTERS, type Filters } from '../../src/shared/filter';
import { locationPhrase, playerTimeTable, readableOnDark, weightLabel, weightBandRange } from '../../src/shared/domain';
import type { GameSummary, Owner, Tag } from '../../src/shared/types';
import { parseVisionJson, AnthropicVision } from '../../src/server/vision/core';
import { nodeVisionOps } from '../../src/server/vision/node';
import sharp from 'sharp';

const owners: Owner[] = [
  { id: 1, name: 'Meus jogos', color: '#ffffff', isMe: true },
  { id: 2, name: 'Fulano', color: '#3b82f6', isMe: false },
  { id: 3, name: 'Ciclano', color: '#22c55e', isMe: false },
];
const tags: Tag[] = [
  { id: 1, name: 'Cooperativo', grp: 'style', description: null, sort: 1 },
  { id: 2, name: 'Worker placement', grp: 'mechanic', description: null, sort: 2 },
  { id: 3, name: 'Deck building', grp: 'mechanic', description: null, sort: 3 },
];

let nextId = 1;
function game(p: Partial<GameSummary>): GameSummary {
  return {
    id: nextId++, bggId: null, kind: 'base', standaloneExpansion: false, expansionType: null, nameEn: 'X', namePt: null, year: 2020,
    thumb: null, minPlayers: 2, maxPlayers: 4, playingTime: 60, minPlaytime: 45, maxPlaytime: 60, typicalTimeManual: null,
    weight: 2.5, weightVotes: 100, bestCount1: null, bestVotes1: null, bestCount2: null, bestVotes2: null, recommendedCounts: null,
    pollTotalVotes: null, ownershipStatus: 'owned', ownerId: 1, locationType: 'with_me', locationPerson: null, locationCustom: null,
    loanDate: null, loanDueDate: null, favorite: false, dataStatus: 'bgg_ok', tags: [], mechanics: [], categories: [], designers: [],
    publishers: [], baseIds: [], baseNames: [], expansionStats: null, ...p,
  };
}

const games = [
  game({ nameEn: 'Agricola', minPlayers: 1, maxPlayers: 4, bestCount1: '3', bestVotes1: 500, bestCount2: '4', bestVotes2: 300, recommendedCounts: [2, 3, 4], weight: 3.6, playingTime: 120, tags: [{ id: 2, source: 'bgg_derived' }], designers: ['Uwe Rosenberg'] }),
  game({ nameEn: 'Pandemic', bestCount1: '4', bestVotes1: 500, bestCount2: '2', bestVotes2: 300, recommendedCounts: [2, 3, 4], weight: 2.4, playingTime: 45, tags: [{ id: 1, source: 'bgg_derived' }], ownerId: 2, locationType: 'with_friend', locationPerson: 'Fulano' }),
  game({ nameEn: 'Dominion', minPlayers: 2, maxPlayers: 4, weight: 2.3, playingTime: 30, tags: [{ id: 3, source: 'bgg_derived' }], ownerId: 3, locationType: 'borrowed', locationPerson: 'Ciclano' }),
  game({ nameEn: 'Azul', weight: 1.8, playingTime: 40, locationType: 'lent_out', locationPerson: 'Beltrano', recommendedCounts: null }),
  game({ nameEn: 'Gloomhaven', ownershipStatus: 'wishlist', ownerId: null, weight: 3.9, playingTime: 120 }),
  game({ nameEn: 'Sem Peso', weight: null, playingTime: null, maxPlaytime: null, minPlaytime: null }),
];
const base = games[0];
games.push(game({ nameEn: 'Agricola: Farmers of the Moor', kind: 'expansion', baseIds: [base.id], baseNames: ['Agricola'], ownerId: 2, locationType: 'with_friend' }));
base.expansionStats = { known: 3, owned: 1, wishlist: 1, unverified: 0, promos: 0, fan: 0, standalone: 0, withFriends: 1, awayFromHome: 1, ownedWithMeBaseAway: false };

const run = (f: Partial<Filters>) => applyFilters(games, { ...DEFAULT_FILTERS, ...f }, { owners, tags }).items.map((g) => g.nameEn);

describe('filtros combináveis', () => {
  it('padrão mostra a coleção física sem expansões', () => {
    expect(run({}).sort()).toEqual(['Agricola', 'Azul', 'Dominion', 'Pandemic', 'Sem Peso'].sort());
  });
  it('jogadores: suportado é diferente de recomendado e de "melhor com"', () => {
    expect(run({ players: 1 })).toEqual(['Agricola']);
    expect(run({ players: 3, playersMode: 'recommended' }).sort()).toEqual(['Agricola', 'Pandemic']);
    expect(run({ players: 3, playersMode: 'best' })).toEqual(['Agricola']);
    expect(run({ players: 2, playersMode: 'best' })).toEqual(['Pandemic']);
  });
  it('duração, peso e dados ausentes', () => {
    expect(run({ timeMax: 45 }).sort()).toEqual(['Azul', 'Dominion', 'Pandemic']);
    expect(run({ weightMin: 3, weightMax: 5 })).toEqual(['Agricola']);
    expect(run({ weightMin: 1, weightMax: 1.99 })).toEqual(['Azul']); // jogo sem peso não entra em filtro de peso
  });
  it('proprietário, localização e empréstimos', () => {
    expect(run({ collection: 'mine' }).sort()).toEqual(['Agricola', 'Azul', 'Sem Peso']);
    expect(run({ collection: 'friends' }).sort()).toEqual(['Dominion', 'Pandemic']);
    expect(run({ ownerIds: [2], location: 'with_me' })).toEqual([]);
    expect(run({ ownerIds: [3], location: 'with_me' })).toEqual(['Dominion']); // "jogos de Ciclano que estão comigo"
    expect(run({ ownerIds: [2], location: 'away' })).toEqual(['Pandemic']);
    expect(run({ location: 'loaned' }).sort()).toEqual(['Azul', 'Dominion']);
    expect(run({ collection: 'wishlist' })).toEqual(['Gloomhaven']);
  });
  it('etiquetas incluídas e excluídas', () => {
    expect(run({ tagInclude: [1] })).toEqual(['Pandemic']);
    expect(run({ tagExclude: [3], timeMax: 45 }).sort()).toEqual(['Azul', 'Pandemic']);
  });
  it('pesquisa por designer, etiqueta e nome de expansão', () => {
    expect(run({ q: 'rosenberg' })).toEqual(['Agricola']);
    expect(run({ q: 'deck building' })).toEqual(['Dominion']);
    const r = applyFilters(games, { ...DEFAULT_FILTERS, q: 'moor' }, { owners, tags });
    expect(r.items.map((g) => g.nameEn)).toEqual(['Agricola']);
    expect(r.matchedViaExpansion.get(base.id)).toEqual(['Agricola: Farmers of the Moor']);
  });
  it('filtros de expansão', () => {
    expect(run({ expansionFilter: 'missing' })).toEqual(['Agricola']);
    expect(run({ expansionFilter: 'complete' })).toEqual([]);
    expect(run({ expansionFilter: 'exp_with_friends' })).toEqual(['Agricola: Farmers of the Moor']);
    expect(run({ expansions: 'only' })).toEqual(['Agricola: Farmers of the Moor']);
  });
  it('ordenação', () => {
    expect(run({ sort: 'weight', sortDir: 'desc' })[0]).toBe('Agricola');
    expect(run({ sort: 'weight', sortDir: 'asc' }).at(-1)).toBe('Sem Peso'); // nulos por último
  });
});

describe('regras de domínio', () => {
  it('rótulos de peso configuráveis', () => {
    expect(weightLabel(1.2)).toBe('Muito leve');
    expect(weightLabel(1.5)).toBe('Leve');
    expect(weightLabel(2.99)).toBe('Médio');
    expect(weightLabel(4.5)).toBe('Muito pesado');
    expect(weightLabel(null)).toBeNull();
    expect(weightBandRange('Pesado')).toEqual([3, 4]);
  });
  it('frases de localização', () => {
    expect(locationPhrase({ locationType: 'with_friend', locationPerson: 'Fulano', locationCustom: null, ownerId: 2 }, owners)).toBe('Com Fulano — não está comigo');
    expect(locationPhrase({ locationType: 'borrowed', locationPerson: null, locationCustom: null, ownerId: 3 }, owners)).toBe('Comigo — emprestado por Ciclano');
  });
  it('tempo por jogador só é calculado com estimativa informada', () => {
    const g = { minPlayers: 2, maxPlayers: 5, minPlaytime: 30, maxPlaytime: 90, playingTime: 60, typicalTimeManual: null, timePerPlayerManual: null, timeBasePlayersManual: null };
    expect(playerTimeTable(g).every((r) => r.kind === 'unavailable' && r.minutes === null)).toBe(true);
    const t = playerTimeTable({ ...g, timePerPlayerManual: 15, timeBasePlayersManual: 2 });
    expect(t.map((r) => r.minutes)).toEqual([60, 75, 90, 105]);
    expect(t.every((r) => r.kind === 'manual_estimate')).toBe(true);
  });
  it('cor do proprietário legível no fundo escuro', () => {
    expect(readableOnDark('#ffffff')).toBe('#ffffff');
    expect(readableOnDark('#000080')).not.toBe('#000080');
  });
});

describe('serviço de visão (Claude)', () => {
  it('interpreta JSON da resposta, inclusive com texto ao redor', () => {
    const boxes = parseVisionJson('Aqui está:\n{"games":[{"title":"Pandemia","english_title":"Pandemic","is_expansion":false,"confidence":0.9,"bbox":[0.1,0.2,0.3,0.4]},{"title":""}]}');
    expect(boxes).toHaveLength(1);
    expect(boxes[0]).toMatchObject({ title: 'Pandemic', text: 'Pandemia', confidence: 0.9, bbox: [0.1, 0.2, 0.3, 0.4] });
    expect(() => parseVisionJson('sem json')).toThrow();
  });
  it('envia a imagem com a chave apenas no servidor e trata erro HTTP', async () => {
    const calls: any[] = [];
    const ok = new AnthropicVision('sk-test', 'modelo-x', nodeVisionOps, (async (url: string, init: any) => {
      calls.push({ url, headers: init.headers, body: JSON.parse(init.body) });
      return new Response(JSON.stringify({ content: [{ type: 'text', text: '{"games":[{"title":"Azul","confidence":0.8}]}' }] }), { status: 200 });
    }) as any);
    const img = await sharp({ create: { width: 50, height: 50, channels: 3, background: '#fff' } }).png().toBuffer();
    const r = await ok.analyze(img);
    expect(r.boxes[0].title).toBe('Azul');
    expect(calls[0].headers['x-api-key']).toBe('sk-test');
    expect(calls[0].body.model).toBe('modelo-x');
    expect(calls[0].body.messages[0].content[0].type).toBe('image');
    const bad = new AnthropicVision('sk-test', 'm', nodeVisionOps, (async () => new Response(JSON.stringify({ error: { message: 'invalid x-api-key' } }), { status: 401 })) as any);
    await expect(bad.analyze(img)).rejects.toThrow(/401/);
  });
});
