import { defineConfig } from '@playwright/test';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';

// Banco temporário: os testes de interface nunca tocam na sua coleção real.
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ludoteca-e2e-'));

export default defineConfig({
  testDir: 'tests/e2e',
  timeout: 120_000,
  workers: 1,
  reporter: [['list']],
  use: { baseURL: 'http://127.0.0.1:5175', viewport: { width: 1400, height: 900 }, screenshot: 'only-on-failure' },
  webServer: [
    { command: 'npx tsx scripts/fake-bgg.ts', env: { FAKE_BGG_PORT: '5998' }, url: 'http://127.0.0.1:5998/xmlapi2/none', reuseExistingServer: false, ignoreHTTPSErrors: true, timeout: 30_000 },
    {
      command: 'npx vite build && npx tsx src/server/index.ts',
      url: 'http://127.0.0.1:5175/api/status',
      reuseExistingServer: false,
      timeout: 120_000,
      env: {
        PORT: '5175', DATA_DIR: dataDir, BGG_BASE_URL: 'http://127.0.0.1:5998', BGG_API_TOKEN: 'dev-token',
        BGG_MIN_INTERVAL_MS: '100', VISION_PROVIDER: 'ocr', LUDOTECA_SKIP_ENV_FILE: '1', SEED_COLLECTION: '0',
      },
    },
  ],
});
